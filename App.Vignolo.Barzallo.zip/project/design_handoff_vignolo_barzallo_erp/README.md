# Handoff: Vignolo Barzallo — ERP jurídico

## Overview
ERP interno **mono-inquilino** para el estudio jurídico Vignolo Barzallo, operado por el Abg. Paúl Romo T. (rol Administrador). Centraliza la operación del estudio: casos, clientes, agenda, tareas, documentos y honorarios (facturación), con autenticación, roles/permisos y registro de auditoría.

Alcance del primer bloque (implementado en el prototipo):
- Inicio (dashboard)
- Clientes (con ficha lateral)
- Casos (con detalle: etapas procesales, cronología, equipo, documentos, riesgos)
- Agenda (calendario mensual)
- Tareas (tablero por estado)
- Documentos (repositorio + subida)
- Honorarios (facturación con lógica de comprobante electrónico SRI)
- Configuración (Usuarios, Roles y permisos, Catálogos, Abogados, General)
- Inicio de sesión + cierre de sesión

Fuera de alcance por ahora: Plantillas, integración con la Función Judicial (SATJE), firma electrónica real, emisión real de comprobantes al SRI.

## About the Design Files
El archivo `Vignolo Barzallo ERP.dc.html` de este bundle es una **referencia de diseño creada en HTML** — un prototipo de alta fidelidad que muestra el aspecto y el comportamiento previstos, **no código de producción para copiar directamente**. Fue construido con un runtime propietario de componentes (`support.js`) del entorno de diseño; **no lo reutilices en el proyecto real**.

La tarea es **recrear estos diseños en el entorno del codebase objetivo** usando sus patrones y librerías establecidos. Si aún no existe un codebase, la recomendación (ver más abajo) es un stack moderno tipo React + TypeScript en el frontend y una API tipada con base de datos relacional en el backend. Este prototipo es el frontend/diseño; **el backend real (BD, API, auth, cifrado, SRI) debe construirse**, no existe aquí.

## Fidelity
**Alta fidelidad (hifi).** Colores, tipografía, espaciado, estados e interacciones son definitivos. Recrear la UI de forma fiel usando las librerías del codebase. El prototipo NO persiste datos (los cambios como marcar tareas viven solo en memoria de sesión) y el login acepta cualquier credencial: eso es andamiaje de prototipo, no comportamiento deseado.

---

## Design Tokens

### Colores
| Token | Hex | Uso |
|---|---|---|
| `--bg-app` | `#F6F5F2` | Fondo general de la app |
| `--surface` | `#FFFFFF` | Tarjetas, tablas, topbar |
| `--surface-alt` | `#FAF9F6` | Hover de filas |
| `--surface-muted` | `#F3F2EE` / `#F1EFEA` | Inputs, chips de tabs, columnas de tablero |
| `--text` | `#1C1B18` | Texto principal |
| `--text-2` | `#33312C` | Texto de párrafo |
| `--text-3` | `#57544E` | Texto secundario |
| `--text-muted` | `#8A857C` | Etiquetas, subtítulos |
| `--text-faint` | `#9B978F` | Metadatos, placeholders |
| `--border` | `#E7E4DD` | Bordes de tarjeta |
| `--border-2` | `#E1DED6` / `#EDEBE5` / `#F0EEE9` | Bordes de input / divisores de fila |
| `--sidebar-dark-bg` | `#1B1A17` | Barra lateral (tema oscuro, por defecto) |
| `--sidebar-dark-fg` | `#F5F4F1` | Texto en barra oscura |
| `--accent` (default) | `#2F5D50` | Acento primario (verde bosque) |
| `--accent-soft` | `#E7F0EB` | Fondo suave del acento |

Acentos alternativos (tweak de apariencia) y su "soft":
- `#2F5D50` → `#E7F0EB` (verde, por defecto)
- `#3A4B7A` → `#E9ECF5` (azul)
- `#6E3B4E` → `#F3E9ED` (vino)
- `#454440` → `#ECEBE7` (grafito)

Colores semánticos (estados y prioridades):
| Significado | Fondo | Texto |
|---|---|---|
| Éxito / Pagada / Activo | `#E7F0EB` | `#2F5D50` |
| Advertencia / Media / Pendiente / Potencial | `#FCF3E1` | `#8A6218` |
| Peligro / Alta / Vencida | `#FBEAE7` | `#A23A2E` |
| Neutro / Baja / Inactivo | `#EEEDE9` | `#75726B` |
| VIP (badge oscuro) | `#1B1A17` | `#E7C67C` |

Colores de avatar de abogados: PR `#2F5D50`, MB `#3A4B7A`, MV `#6E3B4E`, ES `#8A6218`.

### Tipografía
- **Serif — `'Spectral'`** (Google Fonts, pesos 500/600/700): títulos, cifras grandes (KPIs), encabezados de página, nombres en fichas.
- **Sans — `'Hanken Grotesk'`** (Google Fonts, pesos 400/500/600/700): todo el resto de la UI.
- Escala observada: título de página 18px/600; H1 detalle 26px/600 (Spectral); cifra KPI 28–34px/600 (Spectral); cuerpo 13.5–15px; etiquetas de tabla 11.5px/600 uppercase con `letter-spacing:.4px`; metadatos 11.5–12px.
- Números tabulares (`font-variant-numeric: tabular-nums`) en documentos, montos, RUC/CI y códigos de caso.

### Espaciado y forma
- Radio: inputs/botones 9–10px; tarjetas 14px; chips/badges 20px (pill) o 6–7px (etiqueta cuadrada); avatares 50% o 8–10px.
- Padding de tarjeta: `20px` en densidad Cómoda, `15px` en Compacta (token `--cardPad`).
- Padding de fila de tabla: `13px 16px` Cómoda, `9px 14px` Compacta (token `--rowPad`).
- Sin sombras pesadas; separación por bordes de 1px. Única sombra: tab activo `0 1px 3px rgba(0,0,0,.08)` y drawer `-8px 0 30px rgba(0,0,0,.12)`.
- Iconografía: SVG stroke, `stroke-width` 1.7–1.8, `stroke-linecap/linejoin: round`, tamaño 16–21px.

### Tweaks de apariencia (preferencias globales)
- `accent`: color de acento (4 opciones de arriba).
- `sidebarTheme`: `Oscuro` (default) | `Claro`.
- `density`: `Cómoda` (default) | `Compacta` — afecta `--cardPad` y `--rowPad`.

---

## Layout general (shell)
- **Grid de dos columnas**: barra lateral fija de `252px` + columna principal flexible.
- **Barra lateral** (oscura por defecto): logo VB en chip + nombre del estudio; grupo "PRINCIPAL" (Inicio, Clientes, Casos, Agenda, Tareas, Documentos, Honorarios); grupo "SISTEMA" (Configuración); al pie, tarjeta de usuario con avatar, nombre, rol y botón de cerrar sesión. Ítem activo: fondo `rgba(255,255,255,0.10)` (oscuro) o `--accent-soft` (claro), texto blanco/acento.
- **Topbar** (`62px`, fondo blanco, borde inferior): título + subtítulo de la vista a la izquierda; buscador centrado (máx 440px, atajo ⌘K); a la derecha botón primario contextual ("Nuevo …") + campana de notificaciones con punto rojo.
- **Main**: scroll vertical, `max-width: 1240px` centrado, padding fluido `clamp(16px,3vw,32px)`.
- **Responsive**: bajo `max-width: 900px` la barra lateral se oculta y aparece una **barra inferior fija** (`62px`) con 5 accesos: Inicio, Clientes, Casos, Agenda, Tareas. (Documentos/Honorarios quedan solo en escritorio en esta versión.)

---

## Screens / Views

### 1. Inicio de sesión (Login)
- **Propósito**: autenticar al usuario antes de entrar a la app.
- **Layout**: dos paneles. Izquierdo (flex:1, fondo `#1B1A17`): logo + nombre arriba, titular serif grande al centro ("La operación de su estudio, centralizada y segura.") con párrafo de apoyo, © al pie. Derecho (ancho `min(500px,100%)`, fondo `#F6F5F2`): formulario centrado, máx 352px.
- **Componentes del formulario**: título "Iniciar sesión" (Spectral 26/600); campos Correo (email) y Contraseña (password) con label 12.5px/600; fila con checkbox "Recordar dispositivo" y enlace "¿Olvidó su contraseña?"; botón primario full-width "Ingresar" (44px, fondo acento); separador "SEGURIDAD"; aviso con icono candado: verificación en dos pasos activa.
- **Responsive**: bajo 900px el panel izquierdo se oculta; solo el formulario.
- **Comportamiento real esperado**: validar credenciales contra el backend, hash de contraseña (bcrypt/argon2), 2FA (TOTP o código enviado), sesión segura (cookie httpOnly/JWT).

### 2. Inicio (Dashboard)
- **Propósito**: resumen operativo del día para el abogado.
- **Título/subtítulo**: "Buenos días, Dr. Romo" / "Jueves 9 de julio, 2026".
- **Layout**: fila de 4 **KPI cards** (grid auto-fit min 200px), luego grid auto-fit min 320px con tarjetas.
- **KPIs**: Casos activos `7` (+2 este mes), Audiencias esta semana `3` (1 hoy), Tareas pendientes `5` (2 vencen hoy), Clientes activos `6` (8 totales). Cifra en Spectral 34px; delta en color semántico.
- **Tarjetas**:
  - *Agenda de hoy*: lista de eventos con barra de color a la izquierda, hora (46px), título + subtítulo, tipo a la derecha. Enlace "Ver agenda →".
  - *Próximos vencimientos*: icono reloj, texto + caso, badge de "cuándo" con color semántico.
  - *Casos por materia*: barras de progreso horizontales (track `#F0EEE9`, relleno acento).
  - *Casos por abogado*: avatar + barra con color del abogado.
  - *Actividad reciente* (grid-column 1/-1): "registro de auditoría"; filas con avatar, `<autor> <acción> <objeto> <extra>` y "hace X".

### 3. Clientes
- **Propósito**: gestionar la cartera de clientes.
- **Layout**: fila de **filtros pill** (Todos, Activo, VIP, Potencial, Inactivo) — el activo usa fondo acento/blanco; tabla en tarjeta.
- **Columnas**: Cliente (avatar con iniciales + nombre), Tipo, Identificación (RUC/CI, tabular), Ciudad, Casos (conteo), Estado (badge), Resp. (avatar del abogado).
- **Interacción**: clic en fila abre **drawer lateral** (ver abajo). Hover de fila `#FAF9F6`.

### 4. Ficha de cliente (Drawer)
- **Layout**: panel derecho `min(420px,92vw)`, overlay `rgba(28,27,24,0.32)`. Cabecera blanca con avatar grande, nombre (Spectral), tipo y badge de estado; botón cerrar (X).
- **Secciones**: *Contacto* (Identificación, Teléfono, Ciudad, Creado — nota: el correo se eliminó por decisión del cliente); *Casos asociados* (lista clicable que navega al detalle del caso, o estado vacío "Sin casos registrados aún.").

### 5. Casos (lista)
- **Columnas**: Código (`VB-AAAA-NNN`, acento, tabular), Cliente, Materia (etiqueta), Etapa actual, Prioridad (badge), Equipo (avatares solapados -7px), Próxima actuación.
- **Interacción**: clic en fila → detalle del caso.

### 6. Detalle de caso
- **Cabecera**: botón "‹ Todos los casos"; título = código (Spectral 26); badges de prioridad y materia; línea "Cliente · Juzgado".
- **Etapa procesal**: tira de 11 chips (Consulta inicial, Documentación, Análisis, Demanda, Contestación, Prueba, Audiencia, Sentencia, Recursos, Ejecución, Archivado). Etapas pasadas = fondo acento-soft + check; etapa actual = fondo acento sólido + número; futuras = gris. **No usar barra de progreso** — el estudio pidió explícitamente etapas discretas.
- **Columna izquierda**: tarjeta Descripción + Estrategia jurídica + bloque Riesgos (fondo `#FCF3E1`, borde `#F0E4C4`, icono triángulo). Tarjeta Cronología de actuaciones: timeline vertical (punto acento + línea), cada ítem con badge de tipo (Etapa/Documento/Actuación/Creación), fecha · autor, y texto.
- **Columna derecha**: Detalle (N.º de proceso, Contraparte, Inicio, Cierre est.); Equipo asignado (avatar + nombre + rol); Documentos (lista con icono por extensión + "Subir").

### 7. Agenda
- **Layout**: calendario mensual (julio 2026). Fila de días (Lun…Dom). Grid 7×6 de celdas `aspect-ratio:1.15`. Día de hoy (9) resaltado con borde/fondo acento. Eventos = puntos de color dentro de la celda (rojo audiencia, acento reunión, ámbar plazo, azul otros). Días fuera de mes atenuados.
- **Comportamiento real esperado**: vistas mes/semana/día, crear/editar eventos, recordatorios, sincronización de plazos procesales.

### 8. Tareas
- **Layout**: tablero (kanban) de 3 columnas por estado: Pendiente (ámbar), En progreso (azul), Completada (verde). Cada columna: encabezado con punto de color, nombre y conteo; tarjetas con checkbox (redondeado, se llena de acento al completar), título (tachado si completada), badge de prioridad, caso y fecha de vencimiento (roja si "Hoy" y no completada).
- **Interacción**: clic en checkbox alterna la tarea entre Pendiente y Completada (mueve de columna).

### 9. Documentos
- **Layout**: 3 KPIs (Documentos, Espacio usado, Subidos este mes); zona de **subida** (borde punteado, icono upload, texto "Arrastre archivos aquí o haga clic para subir", nota de formatos/límite, botón "Subir documento"); tabla.
- **Columnas**: Documento (chip por extensión PDF/DOCX/XLSX con color + nombre), Caso, Cliente, Tamaño, Fecha, Subido por (avatar).
- **Colores de extensión**: PDF `#FBEAE7`/`#A23A2E`, DOCX `#E9ECF5`/`#3A4B7A`, XLSX `#E7F0EB`/`#2F5D50`.
- **Comportamiento real esperado**: almacenamiento de archivos (S3 o equivalente), vinculación obligatoria a un caso, control de versiones, registro de auditoría, permisos por rol.

### 10. Honorarios (facturación / cobros)
- **Layout**: 4 KPIs — Facturado (2025), Cobrado (verde), Por cobrar (ámbar), Vencido (rojo), con subtexto; aviso informativo (fondo acento-soft) sobre **comprobante electrónico SRI** (RIDE + XML, secuenciales correlativos por punto de emisión); tabla de comprobantes.
- **Columnas**: Comprobante (número `001-001-000000NNN` + caso), Cliente, Concepto, Monto (bold, alineado a la derecha, tabular, formato `$#,###.00`), Vence, SRI (check verde "Autorizado"), Estado (badge Pagada/Pendiente/Vencida).
- **Comportamiento real esperado**: emisión de comprobantes electrónicos firmados y autorizados por el SRI de Ecuador, secuenciales por establecimiento/punto de emisión, generación de RIDE (PDF) y XML, registro de pagos, cuentas por cobrar, conciliación.

### 11. Configuración
Tabs (segmented control): **Usuarios** (por defecto), **Roles y permisos**, **Catálogos**, **Abogados**, **General**.

- **Usuarios**: botón "Nuevo usuario" abre formulario inline (Nombre, Correo, Rol [select], Contraseña temporal + Confirmar, checkbox "Exigir cambio de contraseña en el primer ingreso"). Tabla de usuarios: avatar + nombre (badge "Tu cuenta" para PR), Rol, estado de Contraseña (badge "Contraseña establecida" verde / "Invitación pendiente" ámbar), Último acceso, acción "Restablecer contraseña" / "Reenviar invitación".
  - Sembrado: PR (Administrador, tu cuenta), MB (Socia), MV (Socia), ES (Abogado), María José Torres (Pasante, invitación pendiente), Recepción (Administrativo).
  - **Comportamiento real esperado**: contraseñas cifradas (nunca en claro; el admin solo restablece, no lee), invitaciones por correo, forzar rotación, bloqueo por intentos.
- **Roles y permisos**: matriz Permiso × Rol. Roles: Admin, Socio, Abogado, Pasante, Administr.(ativo). `✓` = permitido (color acento), `·` = denegado (`#CFCBC2`). Matriz vigente:

  | Permiso | Admin | Socio | Abogado | Pasante | Administr. |
  |---|:-:|:-:|:-:|:-:|:-:|
  | Ver todos los casos | ✓ | ✓ | · | · | · |
  | Ver casos asignados | ✓ | ✓ | ✓ | ✓ | · |
  | Crear / editar casos | ✓ | ✓ | ✓ | · | · |
  | Crear tareas | ✓ | ✓ | ✓ | ✓ | · |
  | Subir documentos | ✓ | ✓ | ✓ | ✓ | ✓ |
  | Eliminación lógica | ✓ | ✓ | · | · | · |
  | Gestionar clientes | ✓ | ✓ | ✓ | · | ✓ |
  | Ver honorarios | ✓ | ✓ | · | · | ✓ |
  | Administrar usuarios | ✓ | · | · | · | · |
  | Configurar sistema | ✓ | · | · | · | · |
  | Ver registro de auditoría | ✓ | ✓ | · | · | · |

  **Regla clave**: los permisos se administran en datos/BD, no hardcodeados. El Pasante ve solo casos asignados, crea tareas y sube documentos; sin eliminar, sin honorarios, sin configuración.
- **Catálogos**: tarjetas editables con chips — Materias (Laboral, Tributario, Familia, Societario, Civil, Mercantil, Administrativo, Constitucional, Penal, Propiedad Intelectual), Etapas procesales (las 11 de arriba), Prioridades (Alta/Media/Baja), Tipos de cliente (Potencial, Activo, Inactivo, VIP, Empresa, Persona natural). Botón "+ Añadir" por catálogo.
- **Abogados**: lista con avatar, nombre, cargo y badge Activo; botón "+ Nuevo abogado". (Los correos se eliminaron de la vista.)
- **General**: Nombre del estudio, Zona horaria ((GMT-5) Ecuador), Moneda (USD $), toggles: 2FA (off en el mock), Eliminación lógica / soft delete (on).

---

## Interacciones y comportamiento
- Navegación por estado de vista (`view`): dashboard | clientes | casos | caso | agenda | tareas | documentos | honorarios | config. En la app real, usar router (rutas con URL).
- Login → setea `authed=true` y muestra el shell; logout → vuelve al login y resetea la vista a dashboard.
- Filtros de clientes: cambian `cliFiltro` y filtran la tabla.
- Fila de cliente → abre drawer (`drawerId`); clic en caso dentro del drawer → navega al detalle y cierra drawer.
- Fila de caso → detalle (`casoId`).
- Checkbox de tarea → alterna estado (Pendiente ↔ Completada).
- Tabs de configuración → cambian `configTab`.
- "Nuevo usuario" → alterna formulario inline (`showNewUser`).
- Hover de filas de tabla: fondo `#FAF9F6`. Hover de botones primarios: `filter:brightness(1.07)`.

## State Management
Estado del prototipo (React class component): `view`, `casoId`, `cliFiltro`, `drawerId`, `configTab`, `isNarrow` (media query 900px), `tasks` (override en memoria del sembrado), `authed`, `showNewUser`.

En la app real se necesitará, además: sesión/usuario autenticado y su rol/permisos; datos remotos de clientes, casos, actuaciones, eventos de agenda, tareas, documentos, facturas y usuarios; estado de carga y error por recurso; formularios controlados con validación.

## Data model (sugerido para el backend)
Entidades núcleo y relaciones (mono-inquilino, no requiere columna tenant):
- **Usuario** (id, nombre, email, rol_id, password_hash, must_reset, last_login, activo, 2fa_secret).
- **Rol** (id, nombre) + **Permiso** (clave) + **RolPermiso** (rol_id, permiso_clave) — matriz configurable.
- **Abogado** (puede ser un Usuario con rol Abogado/Socio) — id, nombre, cargo, color, activo.
- **Cliente** (id, nombre, tipo [Empresa|Persona natural], estado [Potencial|Activo|Inactivo|VIP], identificacion [RUC/CI], telefono, ciudad, responsable_id, creado_en, deleted_at).
- **Caso** (id/código `VB-AAAA-NNN`, cliente_id, materia, etapa, prioridad, juzgado, n_proceso, contraparte, inicio, cierre_est, descripcion, estrategia, riesgos, deleted_at) + **CasoResponsable** (caso_id, abogado_id).
- **Actuacion** (id, caso_id, tipo [Etapa|Documento|Actuación|Creación], fecha, autor_id, texto) — alimenta cronología y auditoría.
- **Documento** (id, caso_id, cliente_id, nombre, extension, tamaño, url/storage_key, subido_por, subido_en).
- **EventoAgenda** (id, caso_id, fecha, hora, titulo, tipo [Audiencia|Reunión|Plazo|Llamada], color).
- **Tarea** (id, caso_id, titulo, responsable_id, prioridad, vence, estado [Pendiente|En progreso|Completada]).
- **Factura/Comprobante** (id, secuencial `EST-PTO-NNNNNNNNN`, cliente_id, caso_id, concepto, monto, estado [Pagada|Pendiente|Vencida], emision, vence, sri_estado, sri_autorizacion, xml, ride_pdf).
- **AuditLog** (id, actor_id, accion, entidad, entidad_id, cuando, metadata) — soft delete global (nada se borra físicamente).

## Catálogos (valores)
- **Materias**: Laboral, Tributario, Familia, Societario, Civil, Mercantil, Administrativo, Constitucional, Penal, Propiedad Intelectual.
- **Etapas procesales** (ordenadas): Consulta inicial, Documentación, Análisis, Demanda, Contestación, Prueba, Audiencia, Sentencia, Recursos, Ejecución, Archivado.
- **Prioridades**: Alta, Media, Baja.
- **Estados de cliente**: Potencial, Activo, Inactivo, VIP.
- **Roles**: Administrador, Socio, Abogado, Pasante, Administrativo.

## Assets
- `assets/logo-vb.png` — logo del estudio (monograma "VB" cursivo, negro sobre transparente, 888×888). Provisto por el cliente.
- `assets/logo-vb-white.png` — versión blanca del mismo logo (para fondos oscuros, p. ej. barra lateral en tema oscuro). Generada a partir del original.
- Iconos: SVG inline (no librería externa en el prototipo). En la app real, usar la librería de iconos del codebase (p. ej. Lucide, que coincide con el estilo stroke usado).
- Fuentes: Google Fonts — Spectral y Hanken Grotesk.

## Recomendación de stack (si no existe codebase)
- **Frontend**: React + TypeScript (tipado estricto), router, componentes reutilizables; librería de UI headless + estilos propios respetando los tokens de arriba; TanStack Query para datos.
- **Backend**: API tipada (Node/TS o similar) + PostgreSQL; auth con sesión segura + 2FA; RBAC leído de BD (matriz de permisos); soft delete y AuditLog transversal.
- **Seguridad (OWASP)**: hash de contraseñas (argon2/bcrypt), control de acceso por permiso en cada endpoint, validación de entrada, cifrado en tránsito, minimización de datos personales (LOPDP — Ecuador), retención y derechos ARCO.
- **Facturación**: integrar con el flujo de comprobantes electrónicos del SRI (firma electrónica, generación XML, autorización, RIDE).

## Files
- `Vignolo Barzallo ERP.dc.html` — prototipo de alta fidelidad (referencia de diseño; runtime propietario, no reutilizar el `.dc.html` ni `support.js` en producción).
- `assets/logo-vb.png`, `assets/logo-vb-white.png` — logos.
- Este `README.md` — especificación de implementación (autosuficiente).
