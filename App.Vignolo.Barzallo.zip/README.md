# Vignolo Barzallo — ERP

Internal, mono-tenant practice-management system for the Vignolo Barzallo law
firm (Cuenca, Ecuador). Implements the design in
`project/design_handoff_vignolo_barzallo_erp/` as a real full-stack
application: React/TypeScript frontend, Fastify/TypeScript/PostgreSQL
backend, session-based auth, and role-based access control read from the
database (not hardcoded).

> The `project/` and `chats/` folders are the original Claude Design handoff
> bundle (visual reference + the conversation that shaped the spec). They are
> kept for history; they are **not** part of the running application.

## Stack

- **Frontend**: React 19 + TypeScript + Vite, React Router, TanStack Query.
  Styling matches the design tokens directly (no CSS framework) to stay
  pixel-faithful to the handoff.
- **Backend**: Fastify + TypeScript + Prisma + PostgreSQL. Argon2id password
  hashing, opaque server-side sessions in an httpOnly cookie, permissions
  matrix stored in the database and enforced per-route.
- **Dev database**: `docker-compose.yml` provisions Postgres 16 for local
  dev. If Docker/Docker Hub isn't available in your environment, point
  `DATABASE_URL` at any local Postgres 16+ instance instead.

## Getting started

```bash
# 1. Start Postgres (or point DATABASE_URL at your own instance)
docker compose up -d postgres

# 2. Install all workspace dependencies
npm install

# 3. Configure the backend
cp backend/.env.example backend/.env
# edit backend/.env if your DB isn't the docker-compose default

# 4. Migrate + seed the database
npm run db:migrate --workspace backend
npm run db:seed --workspace backend

# 5. Run both apps (in separate terminals)
npm run dev:backend    # http://localhost:4000
npm run dev:frontend   # http://localhost:5173 (proxies /api to the backend)
```

Seeded login (all active users share this password in dev):

```
email:    paul.romo@vignolobarzallo.ec   (Administrador)
password: VignoloBarzallo2026!
```

Other seeded accounts (same password): `ma.barzallo@…` (Socio),
`magu.vignolo@…` (Socio), `eugenio.s@…` (Abogado, scoped to his own cases),
`recepcion@…` (Administrativo, no case visibility). `maria.jose.torres@…`
(Pasante) is seeded with **no password** — "Invitación pendiente" — to
exercise that state in Configuración → Usuarios.

## Repository layout

```
backend/    Fastify API, Prisma schema/migrations, seed script
frontend/   React app (pages, components, contexts, API client)
chats/      Original design-handoff conversation (reference only)
project/    Original .dc.html design prototype + assets (reference only)
```

## Backend architecture notes

- **Auth**: `POST /api/auth/login` verifies the password with Argon2id,
  creates a `Session` row (token hash stored, raw token only in the signed
  httpOnly cookie), and updates `lastLoginAt`. Every request resolves the
  session via `src/plugins/auth.ts`, attaching `request.user` with the
  caller's permission set.
- **RBAC**: permissions are rows in `Permiso`/`RolPermiso`
  (`backend/src/lib/permissions.ts` only defines the seed values and stable
  slugs — routes check `request.user.permisos.has(clave)`, never role names).
  Configuración → Roles y permisos edits this matrix live.
- **Case visibility scoping**: users with `ver_todos_casos` see every case;
  users with only `ver_casos_asignados` see cases where they're on the
  `CasoResponsable` team (see `backend/src/modules/casos/service.ts`). Tasks,
  agenda, and the dashboard reuse the same scope.
- **Audit log**: every mutation (login, case/client/task/document/invoice
  changes, permission edits) writes an `AuditLog` row; Configuración and the
  dashboard's "Actividad reciente" read from it for users with
  `ver_auditoria`.
- **Soft delete**: clients and cases use `deletedAt`; nothing is physically
  removed. Deleting requires the `eliminacion_logica` permission.
- **Documents**: uploaded via `@fastify/multipart`, stored on disk under
  `backend/uploads/` (git-ignored), 25 MB limit, linked to a case/client and
  attributed to the uploader for the audit trail.
- **SRI e-invoicing / 2FA**: intentionally scaffolded, not real. Invoices
  store `sriAutorizado`/`sriAutorizacion` fields but never call the real SRI
  web service; `Usuario.dosFactoresActivo` and the General settings toggle
  exist but aren't enforced at login. Wiring either up for real is future
  work explicitly called out in the original design handoff.

## Testing

```bash
npm run test --workspace backend   # vitest: password hashing, lockout, permission matrix
```

End-to-end (requires the backend, migrated + seeded, and the frontend dev
server both already running — see "Getting started" above):

```bash
cd frontend && npm run test:e2e   # Playwright: login, every screen, RBAC, mobile nav
```

`playwright.config.ts` points at the environment's pre-installed Chromium
(`/opt/pw-browsers/chromium`); override with `PLAYWRIGHT_CHROMIUM_PATH` if
running elsewhere. If the frontend isn't on the default port, set
`E2E_BASE_URL`.

Frontend and backend both typecheck in CI-friendly commands:

```bash
npm run build --workspace backend    # tsc
npm run build --workspace frontend   # tsc -b && vite build
```

## Known limitations / next steps

- No email delivery: "Reenviar invitación" and password resets are
  admin-set temporary passwords communicated out of band, since there's no
  mail transport configured.
- Login lockout (5 failed attempts → 15 min lock, see
  `backend/src/lib/lockout.ts`) is per-account and in the database, not yet
  paired with IP-based throttling — fine for an internal tool, worth adding
  before exposing this beyond the local network.
