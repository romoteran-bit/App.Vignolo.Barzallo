# Proceso de desarrollo empresarial

_Started 2026-07-09 13:48 UTC_

---

## User

# MODO DE TRABAJO



No eres un generador de código. Eres el arquitecto principal, CTO, ingeniero de software principal, ingeniero DevOps, ingeniero de seguridad, diseñador UX/UI, administrador de bases de datos y revisor de calidad del proyecto.



Tu objetivo no es escribir código rápido, sino diseñar y construir una aplicación de calidad empresarial, preparada para producción, priorizando mantenibilidad, escalabilidad, seguridad y rendimiento.



No valides automáticamente mis ideas. Cuestiona cualquier decisión que pueda generar deuda técnica, riesgos de seguridad, problemas de escalabilidad o una mala experiencia de usuario. Si existe una alternativa superior, explícala y justifica por qué la recomiendas.



No asumas requisitos. Si falta información crítica, detente, formula preguntas concretas y explica cómo cada respuesta afectará la arquitectura.



---



# PROCESO OBLIGATORIO



No escribas código hasta completar y obtener mi aprobación de cada una de estas etapas.



## Etapa 1: Descubrimiento



Analiza profundamente el problema.



Identifica:



* Objetivos del negocio.

* Usuarios.

* Casos de uso.

* Casos límite.

* Riesgos.

* Restricciones.

* Escenarios futuros.

* Requisitos funcionales.

* Requisitos no funcionales.

* Posibles problemas legales o regulatorios cuando correspondan.



Cuestiona cualquier supuesto que consideres incorrecto.



---



## Etapa 2: Arquitectura



Diseña varias alternativas arquitectónicas.



Para cada una explica:



* Ventajas.

* Desventajas.

* Costos.

* Escalabilidad.

* Complejidad.

* Riesgos.



Finalmente recomienda una y justifica técnicamente la elección.



---



## Etapa 3: Diseño técnico



Define completamente:



* Arquitectura.

* Módulos.

* Responsabilidades.

* Flujo de datos.

* Base de datos.

* APIs.

* Eventos.

* Permisos.

* Autenticación.

* Autorización.

* Auditoría.

* Logging.

* Manejo de errores.

* Caché.

* Rendimiento.

* Escalabilidad.

* Observabilidad.

* Recuperación ante fallos.



---



## Etapa 4: Experiencia de usuario



Diseña la experiencia completa.



Describe:



* Navegación.

* Wireframes textuales.

* Flujo de cada pantalla.

* Estados vacíos.

* Estados de error.

* Estados de carga.

* Accesibilidad.

* Responsive Design.



Justifica cada decisión desde la perspectiva del usuario.



---



## Etapa 5: Planificación



Divide el proyecto en módulos pequeños.



Para cada módulo indica:



* Objetivo.

* Dependencias.

* Riesgos.

* Tiempo estimado.

* Criterios de aceptación.

* Estrategia de pruebas.



---



## Etapa 6: Implementación



Solo después de aprobar la planificación comienza a escribir código.



Antes de modificar cualquier archivo explica:



* Qué cambiarás.

* Por qué.

* Qué impacto tendrá.



Cuando termines un módulo:



* Compila.

* Ejecuta pruebas.

* Corrige errores.

* Refactoriza.

* Verifica rendimiento.

* Espera mi aprobación antes de continuar.



---



# ESTÁNDARES



Todo el código debe cumplir:



* Clean Architecture.

* SOLID.

* DRY.

* KISS.

* YAGNI.

* Principios OWASP.

* Seguridad por defecto.

* Tipado estricto.

* Código legible.

* Componentes reutilizables.

* Bajo acoplamiento.

* Alta cohesión.



---



# CALIDAD



Antes de dar cualquier tarea por terminada verifica:



* Errores de compilación.

* Errores de lint.

* Errores de tipado.

* Rendimiento.

* Accesibilidad.

* Seguridad.

* Cobertura de pruebas.

* Código duplicado.

* Complejidad innecesaria.



Si detectas una mejora importante, impleméntala o justifica por qué no conviene.



---



# DOCUMENTACIÓN



Mantén actualizados durante todo el proyecto:



* README.

* Arquitectura.

* ADR (Architecture Decision Records).

* Modelo de datos.

* Variables de entorno.

* Guía de despliegue.

* Guía para desarrolladores.

* Registro de decisiones técnicas.



---



# INTERACCIÓN



Sé crítico y preciso.



No busques complacerme.



Si una decisión es técnicamente deficiente, indícalo.



Si una idea no escala, explícalo.



Si detectas deuda técnica, cuantifica su impacto.



Si una funcionalidad aumenta la complejidad sin aportar valor suficiente, propón eliminarla.



No avances a la siguiente etapa sin mi aprobación explícita.



El objetivo final es entregar una aplicación que un equipo senior pueda mantener durante años con un costo operativo bajo, una arquitectura sólida y calidad apta para producción.

## Assistant

Entiendo el modo de trabajo, y lo respeto. Pero siendo directo desde el principio —como me pides— hay un desajuste importante que debo señalar antes de que avancemos, porque callarlo sería exactamente el tipo de complacencia que me pides evitar:

**Qué soy realmente en este entorno.** No soy un agente full-stack de producción. No ejecuto compiladores, no corro suites de pruebas, no aprovisiono infraestructura, no me conecto a bases de datos reales ni ejecuto escáneres de seguridad OWASP. Mi medio es **diseño en HTML**: prototipos interactivos de alta fidelidad, interfaces, decks, documentos y mockups, construidos como componentes que se ven y se prueban en el navegador.

Eso significa que buena parte de tu proceso —Etapa 3 (BD, APIs, caché, observabilidad, recuperación ante fallos), la parte de DevOps/seguridad ejecutable, cobertura de pruebas real, ADRs de infraestructura— **no puedo entregarla como artefacto funcionando**. Prometerte lo contrario sería deuda técnica desde la primera línea.

**Lo que sí puedo hacer con rigor**, aplicando el espíritu de tu modo de trabajo:
- **Etapa 1 (Descubrimiento):** cuestionar supuestos, mapear usuarios, casos de uso, casos límite y riesgos.
- **Etapa 2 (Arquitectura), pero de producto/UX:** varias alternativas de flujo e IA, con pros/contras.
- **Etapa 4 (Experiencia):** navegación, wireframes, todos los estados (vacío, error, carga), accesibilidad, responsive — y **construirlos como prototipo real e interactivo** que puedes clicar.
- Diseño técnico *sobre papel* (contratos de API, modelo de datos, diagramas) como documentación entregable — sin ejecutarlo.

Dos preguntas antes de cualquier otra cosa:

1. **¿Qué vamos a construir?** Tu mensaje define *cómo* trabajar, pero no *qué*. No hay producto todavía. Descríbeme la aplicación o el problema.

2. **¿Este entorno es el correcto para ti?** Si lo que buscas es código de backend de producción ejecutable con CI/CD, este no es el lugar. Si lo que buscas es **diseñar y prototipar el producto con calidad senior antes de que un equipo lo construya**, estás exactamente donde debes estar — y ahí puedo aplicar tu proceso con seriedad.

Dime qué quieres construir y arrancamos por la Etapa 1. Si además quieres que guarde tu modo de trabajo para todas las conversaciones de este proyecto, lo dejo en un `CLAUDE.md` y lo respeto en adelante.

## User

listo hazlo, vamos a construir esto:

## Assistant

Antes de construir, cumplo tu propia regla: análisis crítico primero, y encuadre honesto de qué te voy a entregar.

**Qué te voy a entregar aquí.** Un **prototipo interactivo de alta fidelidad** del ERP — pantallas reales, navegables, con estado, que se sienten como la app final (al estilo Linear/Notion). Es el artefacto de diseño y producto que va *antes* del código de producción. No es el backend ejecutable: no hay Postgres real, ni facturación SRI conectada, ni CI/CD. Eso lo construye un equipo después, usando este prototipo como especificación viva. Fingir lo contrario sería la deuda técnica que me pides evitar.

**Ahora, lo que me pediste: dónde tu spec tiene huecos o riesgos reales.**

1. **"SaaS empresarial" vs. "un estudio".** Contradicción de fondo. ¿Es **mono-inquilino** (solo tu estudio) o **multi-tenant** (venderlo a otros estudios)? Cambia todo: modelo de datos, aislamiento de datos, precios, seguridad. La UI también difiere. Hay que decidirlo ya.

2. **Facturación = SRI.** En Ecuador facturar implica **comprobantes electrónicos firmados (XML/RIDE), autorización del SRI, secuenciales**. No es un módulo de "cobros" genérico. O lo diseñamos con esa realidad, o el módulo nace inútil.

3. **Falta el corazón de la facturación legal: registro de horas (time tracking / billable hours).** Pediste honorarios pero no tiempo facturable. Sin él no hay rentabilidad real por caso ni por abogado. Lo considero un módulo faltante.

4. **Falta control de conflictos de interés.** Al abrir un caso, un estudio serio debe verificar que la **contraparte** no sea ya cliente. Es una obligación ética, no un extra. Debería estar en el alta de casos.

5. **Datos personales sensibles → LOPDP (Ley Orgánica de Protección de Datos, Ecuador).** Datos de clientes + secreto profesional. Esto impone auditoría, minimización, derechos ARCO. Afecta el diseño de permisos y del log de auditoría que ya pediste (bien).

6. **Integración con la Función Judicial (SATJE/eSATJE).** Tu mayor palanca de valor sería jalar automáticamente el estado de procesos por número. No lo mencionaste. ¿Lo contemplamos en la arquitectura aunque no se implemente ya?

7. **Alcance vs. calidad.** Son ~13 módulos. Construir los 13 de golpe produce relleno mediocre. Propongo prototipar primero la **columna vertebral** con excelencia, y expandir por módulos — como tú mismo pides ("módulos pequeños").

Necesito fijar dirección antes de diseñar. Responde esto y arranco con el prototipo:

_[tool: questions_v2]_

## User

Questions answered:
- tenancy: Solo mi estudio (mono-inquilino)
- scope_first: Dashboard, Clientes, Agenda / Calendario, Tareas, Casos, Configuración (roles y permisos), Decide tú por mí
- design_vibe: Mezcla — decide tú
- theme: Decide tú
- conflicts: No por ahora
- satje: Decide tú
- sri: Decide tú
- density: Decide tú
- logo: El estudio se llama Vignolo Barzallo, pero se trabaja por cada abogado, la app es mia como abogado Paúl Romo T
- platform_priority: A la par

## Assistant

¡Vamos! Voy a construir el **prototipo interactivo de alta fidelidad** de la columna vertebral (Inicio, Clientes, Casos + ficha de caso, Agenda, Tareas, Configuración con roles/permisos). Es navegable, con datos sembrados realistas del estudio y de tus casos, responsive escritorio/móvil.

Decisiones que tomé por ti (las marcaste como "decide tú"), justificadas:
- **Visual:** blend Linear (densidad/velocidad) + Stripe (limpieza corporativa) + Notion (calidez editorial). Tipografía Hanken Grotesk + Spectral (serif para gravedad jurídica).
- **Tema:** claro con barra lateral oscura (más confianza/legibilidad para uso diario); conmutable por tweak.
- **Facturación/SATJE:** fuera del primer bloque; reservo el patrón sin implementar.

_[tool: update_todos]_

_[tool: dc_write]_

## Assistant

_[tool: dc_write]_

_[tool: show_html]_

_[tool: ready_for_verification]_

Listo — el prototipo interactivo está en tu pantalla. **Vignolo Barzallo ERP**, navegable y responsive (barra lateral en escritorio, nav inferior en móvil).

Qué puedes tocar ahora mismo:
- **Inicio** — KPIs, agenda del día, vencimientos, carga por materia y por abogado, y actividad reciente (registro de auditoría).
- **Clientes** — tabla con filtros por estado; clic en una fila abre la ficha completa con sus casos.
- **Casos** — tabla → clic abre el detalle con **etapas procesales** (no barra de progreso), cronología de actuaciones, equipo, documentos y riesgos.
- **Agenda** — calendario mensual (julio 2026) con eventos marcados.
- **Tareas** — tablero por estado; marca/desmarca para mover entre Pendiente y Completada.
- **Configuración** — matriz de roles/permisos, catálogos editables (materias, etapas…), abogados (en BD, no en código) y ajustes generales (2FA, soft delete).
- **Tweaks** (panel de la app): color de acento, barra lateral clara/oscura y densidad.

Notas honestas:
- Es diseño de producto de alta fidelidad, no backend ejecutable. Sirve como **especificación viva** para que un equipo lo construya.
- Datos sembrados son de muestra; el guardado no persiste (es prototipo).

Siguientes pasos que sugiero: (1) revisar el detalle de un caso y ajustar campos/orden; (2) definir bloque 2 — **Documentos, Honorarios (con lógica SRI) y Plantillas**; (3) volver sobre los huecos que marqué (conflictos de interés, registro de horas). Dime por dónde seguimos.

## User

elimina el apartado de los mails añade el inicio de sesión

## Assistant

_[tool: read_file]_

Preservo tus ediciones (Abg. Paúl Romo, Dra. Vignolo). Ahora: quito los correos de las fichas y añado pantalla de inicio de sesión.

_[tool: dc_js_str_replace]_

_[tool: dc_js_str_replace]_

Ahora los cambios de plantilla — pantalla de login, envolver la app, y quitar los correos:

_[tool: dc_html_str_replace]_

_[tool: dc_html_str_replace]_

Ahora quito los correos y añado cerrar sesión al perfil:

_[tool: dc_html_str_replace]_

_[tool: dc_html_str_replace]_

_[tool: dc_html_str_replace]_

Ahora el correo en el drawer y en abogados:

_[tool: dc_html_str_replace]_

_[tool: dc_html_str_replace]_

_[tool: ready_for_verification]_

Listo. Cambios aplicados:

- **Pantalla de inicio de sesión** al abrir la app: panel de marca a la izquierda + formulario (correo, contraseña, recordar dispositivo, olvidó contraseña, aviso de verificación en dos pasos). El botón **Ingresar** entra al sistema; añadí **Cerrar sesión** en el perfil de la barra lateral. Se apila en móvil.
- **Correos eliminados** de la tabla de clientes, la ficha (drawer) y la lista de abogados.

Nota: el login es de prototipo (cualquier credencial entra; no valida ni persiste). Cuando quieras, el siguiente bloque puede ser Documentos + Honorarios + Plantillas.

## User

no hemos establecido aun contraseñas ni el usuario de administración para editar todo, el de pasantes para lo que te dije y el mio como abogado

## Assistant

Buen punto — y aquí va la nota honesta primero: este es un **prototipo de diseño**, así que no puedo crear cuentas ni contraseñas reales (eso lo hace el sistema real con hash/BD cuando un equipo lo construya). Lo que sí puedo —y debo— diseñar es **la pantalla donde tú administras usuarios, roles y contraseñas**. Voy a añadir un módulo **Usuarios** en Configuración con: crear usuario, asignar rol, establecer contraseña temporal y restablecer/invitar.

Antes de fijar los permisos exactos, una duda concreta: **¿qué debe poder hacer un Pasante?** Mi propuesta por defecto es — ver solo los casos asignados, crear tareas y subir documentos, sin eliminar, sin ver honorarios y sin configuración. Y para tu cuenta: te dejo como **Administrador** (edita todo) operando también como abogado. Dime si ajusto algo. Mientras, lo construyo:

_[tool: dc_js_str_replace]_

_[tool: dc_js_str_replace]_

_[tool: dc_js_str_replace]_

_[tool: dc_js_str_replace]_

Ahora la pantalla de Usuarios en la plantilla:

_[tool: dc_html_str_replace]_

_[tool: update_todos]_

_[tool: ready_for_verification]_

Añadí el módulo **Configuración → Usuarios** (es la primera pestaña):

- **Lista de usuarios** con rol, estado de contraseña (Establecida / Invitación pendiente), último acceso y acción **Restablecer contraseña / Reenviar invitación**.
- **Crear usuario** (botón "Nuevo usuario"): nombre, correo, **rol**, contraseña temporal + confirmar, y "exigir cambio en el primer ingreso".
- Sembré: tu cuenta como **Administrador** ("Tu cuenta"), los socios y abogado, un **Pasante** con invitación pendiente, y Administrativo.

Recordatorio honesto: es prototipo — las contraseñas no se guardan ni cifran de verdad aquí; el diseño ya define cómo se administrarán en el sistema real.

Queda **pendiente tu confirmación**: los permisos exactos del **Pasante** (mi propuesta: ver solo casos asignados, crear tareas y subir documentos; sin eliminar, sin honorarios, sin configuración). Dime si lo dejo así y lo reflejo en la matriz de permisos. Después seguimos con Documentos / Honorarios / Plantillas.

## User

si perfecto lo de documentos, y plantillas no lo pongas honorarios si

## Assistant

Entendido: **sin** Documentos ni Plantillas; **sí** Honorarios. Y dejo los permisos del Pasante como propuse. Registro el plan:

_[tool: update_todos]_

## User

Añade este como logo, añade un sistema de pago y la opción de poner documentos

## Assistant

_[tool: image_metadata]_

_[tool: read_file]_

The logo is black on transparent — it'll vanish on the dark sidebar. I'll copy it in and also generate a white version for dark surfaces.

_[tool: run_script]_

Logos generated. Now let me read the nav and view structure to wire everything.

_[tool: read_file]_

Now the edits — logos, two nav items, and the two new modules.

_[tool: dc_html_str_replace]_

_[tool: dc_html_str_replace]_

Now add the two nav items in the sidebar (after Tareas):

_[tool: dc_html_str_replace]_

Now the JS logic — new views, nav entries, logo vars, and data for both modules:

_[tool: dc_js_str_replace]_

_[tool: dc_js_str_replace]_

_[tool: dc_js_str_replace]_

Now the data, handlers, logo vars, and view flags in the return block:

_[tool: dc_js_str_replace]_

Now wire the flags, handlers and logo vars into the return block:

_[tool: dc_js_str_replace]_

_[tool: dc_js_str_replace]_

Now the two view templates. Let me insert them before the Configuración view:

_[tool: dc_html_str_replace]_

Let me verify the two new views and the logo render.

_[tool: show_html]_

_[tool: save_screenshot]_

_[tool: save_screenshot]_

_[tool: show_to_user]_

_[tool: save_screenshot]_

Todo funciona. Limpio los screenshots temporales y finalizo.

_[tool: delete_file]_

_[tool: update_todos]_

_[tool: ready_for_verification]_

Listo, las tres cosas:

- **Logo VB** — reemplacé el monograma de texto por tu logo real, en el login y en la barra lateral. Genera automáticamente una versión blanca cuando la barra está en tema oscuro, para que se vea bien en ambos.
- **Honorarios** (sistema de pago) — KPIs de facturado / cobrado / por cobrar / vencido, tabla de comprobantes con cliente, caso, concepto, monto, vencimiento, autorización **SRI** y estado (Pagada/Pendiente/Vencida). Botón "Nueva factura".
- **Documentos** — repositorio con zona de subida (arrastrar/soltar), y tabla por documento con caso, cliente, tamaño, fecha y quién lo subió; iconos por tipo (PDF/Word/Excel).

Ambos aparecen en el menú lateral bajo PRINCIPAL.

Notas honestas:
- Sigue siendo prototipo: subir/facturar no persiste ni emite comprobantes reales al SRI; el diseño define cómo funcionaría.
- En **móvil** la barra inferior mantiene los 5 accesos principales; Documentos y Honorarios quedan por ahora solo en escritorio. Si los quieres también en móvil, agrego un botón "Más".
- Queda pendiente reflejar los **permisos del Pasante** en la matriz (ver casos asignados, crear tareas, subir documentos; sin eliminar/honorarios/config). ¿Lo aplico?

## User

Found issues — fixing…

## Assistant

The `{{ }}` hole in `img src` doesn't resolve in this runtime. I'll use two literal-src images toggled by theme instead.

_[tool: dc_js_str_replace]_

_[tool: dc_html_str_replace]_

_[tool: save_screenshot]_

Logo confirmado. Ahora aplico los permisos del Pasante en la matriz:

_[tool: dc_js_str_replace]_

_[tool: delete_file]_

_[tool: update_todos]_

_[tool: ready_for_verification]_

Hecho. Corregido el logo (ahora carga bien en la barra lateral, con versión blanca en tema oscuro) y aplicados los permisos del **Pasante** en la matriz (Configuración → Roles y permisos):

- ✓ Ver casos asignados
- ✓ Crear tareas
- ✓ Subir documentos
- ✗ Ver todos los casos, eliminar, gestionar clientes, ver honorarios, configurar sistema

Todo listo y verificado. Cuando quieras seguimos afinando cualquier módulo.

## User

exporta el contenido de la presente aprobacion via zip para tener el contenido integro de la aplicacion para trabajar desde terminal con la construccion de la aplicacion

## Assistant

_[tool: read_skill_prompt]_

I'll build a developer handoff package — the design file, assets, and a complete README a developer can implement from — then zip it.

_[tool: write_file]_

_[tool: copy_files]_

_[tool: present_fs_item_for_download]_

Listo — arriba tienes el ZIP para descargar.

**Contiene:**
- `README.md` — especificación completa y autosuficiente: tokens de diseño (colores, tipografía, espaciado), cada pantalla con layout y componentes, interacciones, estado, **modelo de datos sugerido**, matriz de permisos, catálogos y recomendación de stack.
- `Vignolo Barzallo ERP.dc.html` + `support.js` — el prototipo tal cual, para abrirlo y consultarlo como referencia visual.
- `assets/` — tus dos logos.

**Importante para trabajar en terminal:** el `.dc.html` es **referencia de diseño**, no el código base de producción — usa un runtime propietario que no debes reutilizar. El README está escrito para que Claude Code (o cualquier dev) **recree** la app en un stack real y construya el backend que aquí no existe (BD, API, auth con cifrado, permisos desde BD, SRI). Ábrelo con Claude Code apuntando a la carpeta y pídele que implemente siguiendo el README.

