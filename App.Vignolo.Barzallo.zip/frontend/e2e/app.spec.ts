import { expect, test } from '@playwright/test';
import { login, USERS } from './fixtures';

test.describe('Login', () => {
  test('rejects bad credentials with a visible error', async ({ page }) => {
    await page.goto('/');
    await page.fill('input[type=email]', USERS.admin);
    await page.fill('input[type=password]', 'wrong-password');
    await page.click('button[type=submit]');
    await expect(page.getByText('Correo o contraseña incorrectos')).toBeVisible();
  });

  test('logs in and reaches the dashboard', async ({ page }) => {
    await login(page, USERS.admin);
    await expect(page.getByText(/Buenos días|Buenas tardes|Buenas noches/)).toBeVisible();
    await expect(page.getByText('Casos activos')).toBeVisible();
  });
});

test.describe('Navigation (as Administrador)', () => {
  test.beforeEach(async ({ page }) => {
    await login(page, USERS.admin);
  });

  test('walks every primary screen without console errors', async ({ page }) => {
    const errors: string[] = [];
    page.on('pageerror', (err) => errors.push(String(err)));

    for (const href of ['/clientes', '/casos', '/agenda', '/tareas', '/documentos', '/honorarios', '/configuracion']) {
      await page.click(`a[href="${href}"]`);
      await expect(page).toHaveURL(new RegExp(href.replace('/', '\\/')));
    }

    expect(errors).toEqual([]);
  });

  test('opens a client drawer and navigates to a linked case', async ({ page }) => {
    await page.click('a[href="/clientes"]');
    await page.click('table tbody tr:first-child');
    await expect(page.getByText('CASOS ASOCIADOS')).toBeVisible();
    await page.click('[aria-label="Cerrar"]');
    await expect(page.locator('[aria-label="Cerrar"]')).toHaveCount(0);
  });

  test('opens a case detail with etapa chips and cronología', async ({ page }) => {
    await page.click('a[href="/casos"]');
    await page.click('table tbody tr:first-child');
    await expect(page.getByText('ETAPA PROCESAL')).toBeVisible();
    await expect(page.getByText('CRONOLOGÍA DE ACTUACIONES')).toBeVisible();
  });

  test('toggles a task between Pendiente and Completada', async ({ page }) => {
    await page.click('a[href="/tareas"]');
    const checkbox = page.locator('button[aria-label*="Preparar alegato"]');
    await checkbox.click();
    await expect(page.getByText('Preparar alegato para la audiencia única')).toHaveCSS(
      'text-decoration-line',
      'line-through',
    );
    await checkbox.click(); // restore original state for other tests
  });
});

test.describe('RBAC', () => {
  test('Abogado only sees their own assigned cases', async ({ page }) => {
    await login(page, USERS.abogado);
    await page.click('a[href="/casos"]');
    const rows = page.locator('table tbody tr');
    await expect(rows).toHaveCount(1);
    await expect(page.locator('a[href="/honorarios"]')).toHaveCount(0);
  });

  test('Administrativo has no case/agenda/tareas/config nav and is denied direct access', async ({ page }) => {
    await login(page, USERS.administrativo);
    await expect(page.locator('a[href="/casos"]')).toHaveCount(0);
    await expect(page.locator('a[href="/agenda"]')).toHaveCount(0);
    await expect(page.locator('a[href="/tareas"]')).toHaveCount(0);
    await expect(page.locator('a[href="/configuracion"]')).toHaveCount(0);

    await page.goto('/casos');
    await expect(page.getByText('No tiene permisos para ver esta sección')).toBeVisible();
  });
});

test.describe('Logout', () => {
  test('returns to the login screen', async ({ page }) => {
    await login(page, USERS.admin);
    await page.click('button[title="Cerrar sesión"]');
    await expect(page.getByText('Iniciar sesión')).toBeVisible();
  });
});

test.describe('Responsive', () => {
  test('shows bottom nav on a narrow viewport', async ({ page }) => {
    await page.setViewportSize({ width: 420, height: 900 });
    await login(page, USERS.admin);
    await expect(page.locator('nav a[href="/"]')).toBeVisible();
    await expect(page.locator('aside')).toHaveCount(0);
  });
});
