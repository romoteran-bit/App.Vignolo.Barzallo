import type { Page } from '@playwright/test';

export const DEV_PASSWORD = 'VignoloBarzallo2026!';

export const USERS = {
  admin: 'paul.romo@vignolobarzallo.ec',
  abogado: 'eugenio.s@vignolobarzallo.ec',
  administrativo: 'recepcion@vignolobarzallo.ec',
} as const;

export async function login(page: Page, email: string, password = DEV_PASSWORD) {
  await page.goto('/');
  await page.fill('input[type=email]', email);
  await page.fill('input[type=password]', password);
  await Promise.all([
    // Login and the dashboard both live at "/", so there's no URL change to
    // wait on — wait for the authenticated shell (sidebar logout button)
    // instead, otherwise later assertions can race the session cookie.
    page.waitForResponse((res) => res.url().includes('/api/auth/me') && res.request().method() === 'GET'),
    page.click('button[type=submit]'),
  ]);
  // "Cerrar sesión" only exists in the desktop sidebar; on narrow viewports
  // the bottom nav has no logout button, so key off the login form instead
  // — it's the one element guaranteed to disappear on successful auth.
  await page.getByRole('heading', { name: 'Iniciar sesión' }).waitFor({ state: 'hidden' });
}
