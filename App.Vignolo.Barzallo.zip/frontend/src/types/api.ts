export type Rol = 'Administrador' | 'Socio' | 'Abogado' | 'Pasante' | 'Administrativo';

export interface MeResponse {
  id: string;
  nombre: string;
  email: string;
  rol: Rol;
  abogadoId: string | null;
  mustReset: boolean;
  permisos: string[];
}

export interface Abogado {
  id: string;
  nombre: string;
  iniciales: string;
  cargo: string;
  color: string;
  activo: boolean;
}

export type EstadoCliente = 'POTENCIAL' | 'ACTIVO' | 'INACTIVO' | 'VIP';

export interface ClienteListItem {
  id: string;
  nombre: string;
  tipo: string;
  estado: EstadoCliente;
  identificacion: string;
  telefono: string;
  ciudad: string;
  casos: number;
  responsable: { id: string; ini: string; color: string };
  creadoEn: string;
}

export interface ClienteDetalle {
  id: string;
  nombre: string;
  tipo: string;
  estado: EstadoCliente;
  identificacion: string;
  telefono: string;
  ciudad: string;
  creadoEn: string;
  responsable: { id: string; nombre: string };
  casos: { id: string; materia: string; etapa: string }[];
}

export type Prioridad = 'ALTA' | 'MEDIA' | 'BAJA';

export interface CasoListItem {
  id: string;
  cliente: string;
  materia: string;
  etapa: string;
  prioridad: Prioridad;
  equipo: { id: string; ini: string; color: string }[];
  proxima: string;
}

export type TipoActuacion = 'ETAPA' | 'DOCUMENTO' | 'ACTUACION' | 'CREACION';

export interface CasoDetalle {
  id: string;
  cliente: string;
  clienteId: string;
  materia: string;
  etapa: string;
  etapaIdx: number;
  etapas: string[];
  prioridad: Prioridad;
  juzgado: string;
  numeroProceso: string;
  contraparte: string;
  inicio: string;
  cierreEstimado: string;
  descripcion: string;
  estrategia: string;
  riesgos: string;
  equipo: { id: string; nombre: string; cargo: string; color: string; ini: string }[];
  cronologia: { tipo: TipoActuacion; fecha: string; autor: string; texto: string }[];
  documentos: { id: string; nombre: string; extension: string; tamanoBytes: number; subidoEn: string }[];
}

export type TipoEvento = 'AUDIENCIA' | 'REUNION' | 'PLAZO' | 'LLAMADA';

export interface EventoAgenda {
  id: string;
  casoId: string | null;
  fecha: string;
  titulo: string;
  subtitulo: string;
  tipo: TipoEvento;
  color: string;
}

export type EstadoTarea = 'PENDIENTE' | 'EN_PROGRESO' | 'COMPLETADA';

export interface Tarea {
  id: string;
  titulo: string;
  caso: string;
  prioridad: Prioridad;
  vence: string;
  estado: EstadoTarea;
}

export interface Documento {
  id: string;
  nombre: string;
  extension: string;
  caso: string;
  cliente: string;
  tamanoBytes: number;
  subidoEn: string;
  subidoPor: { ini: string; color: string };
}

export type EstadoFactura = 'PAGADA' | 'PENDIENTE' | 'VENCIDA';

export interface Factura {
  id: string;
  secuencial: string;
  caso: string;
  cliente: string;
  concepto: string;
  monto: number;
  emision: string;
  vence: string;
  sriAutorizado: boolean;
  estado: EstadoFactura;
}

export interface DashboardResponse {
  kpis: {
    casosActivos: number;
    casosNuevosMes: number;
    audienciasSemana: number;
    audienciasHoy: number;
    tareasPendientes: number;
    tareasVencenHoy: number;
    clientesActivos: number;
    clientesTotales: number;
  };
  eventosHoy: { hora: string; titulo: string; sub: string; tipo: TipoEvento; color: string }[];
  vencimientos: { texto: string; caso: string; cuando: string; color: string; bg: string }[];
  materiaStats: { m: string; n: number; pct: string }[];
  abogadoStats: { ini: string; a: string; color: string; n: number; pct: string }[];
  actividad: { autor: string; accion: string; obj: string; cuando: string }[];
}

export interface UsuarioListItem {
  id: string;
  nombre: string;
  email: string;
  rol: Rol;
  activo: boolean;
  passwordEstablecida: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  ini: string;
  color: string;
}

export interface RolOpcion {
  id: string;
  nombre: string;
}

export interface RolesMatrixResponse {
  permisos: { clave: string; etiqueta: string }[];
  roles: { id: string; nombre: string; permisos: string[] }[];
}

export type CategoriaCatalogo = 'MATERIA' | 'ETAPA_PROCESAL' | 'PRIORIDAD' | 'TIPO_CLIENTE';

export interface CatalogosResponse {
  MATERIA?: string[];
  ETAPA_PROCESAL?: string[];
  PRIORIDAD?: string[];
  TIPO_CLIENTE?: string[];
}

export interface ConfiguracionGeneral {
  id: number;
  nombreEstudio: string;
  zonaHoraria: string;
  moneda: string;
  dosFactoresHabilitado: boolean;
  eliminacionLogicaActiva: boolean;
}
