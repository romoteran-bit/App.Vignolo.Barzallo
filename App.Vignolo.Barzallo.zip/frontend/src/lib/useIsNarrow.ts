import { useEffect, useState } from 'react';

export function useIsNarrow(breakpointPx = 900): boolean {
  const query = `(max-width: ${breakpointPx}px)`;
  const [isNarrow, setIsNarrow] = useState(() => window.matchMedia(query).matches);

  useEffect(() => {
    const mq = window.matchMedia(query);
    const onChange = () => setIsNarrow(mq.matches);
    onChange();
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, [query]);

  return isNarrow;
}
