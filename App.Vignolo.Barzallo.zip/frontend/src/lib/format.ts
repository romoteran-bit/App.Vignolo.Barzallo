export function formatMoney(n: number): string {
  return '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function formatDateShort(iso: string): string {
  return new Date(iso).toLocaleDateString('es-EC', { day: '2-digit', month: 'short' });
}

export function formatDateLong(iso: string): string {
  return new Date(iso).toLocaleDateString('es-EC', { day: '2-digit', month: 'long', year: 'numeric' });
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function formatLastLogin(iso: string | null): string {
  if (!iso) return 'Nunca';
  const d = new Date(iso);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const hora = d.toLocaleTimeString('es-EC', { hour: '2-digit', minute: '2-digit', hour12: false });
  if (sameDay) return `Hoy, ${hora}`;
  if (d.toDateString() === yesterday.toDateString()) return `Ayer, ${hora}`;
  return `${formatDateShort(iso)}, ${hora}`;
}

export function timeAgo(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 1) return 'ahora';
  if (mins < 60) return `hace ${mins} min`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `hace ${hours} h`;
  const days = Math.round(hours / 24);
  if (days === 1) return 'ayer';
  return `hace ${days} días`;
}

/** Mirrors the backend's clientes/routes.ts `initials()` helper for client-side display. */
export function clienteIniciales(nombre: string): string {
  return nombre
    .replace(/[^A-Za-zÁÉÍÓÚÑáéíóúñ ]/g, '')
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('');
}

const HONORIFICOS = /^(abg|dr|dra|lic|lcdo|lcda|ing|sr|sra)\.?$/i;

/** Best-effort 2-letter initials for a person's display name, skipping titles. */
export function personaIniciales(nombre: string): string {
  const words = nombre
    .replace(/[^A-Za-zÁÉÍÓÚÑáéíóúñ. ]/g, '')
    .split(/\s+/)
    .filter((w) => w && !HONORIFICOS.test(w));
  return words
    .slice(0, 2)
    .map((w) => w.replace('.', '')[0]?.toUpperCase() ?? '')
    .join('');
}
