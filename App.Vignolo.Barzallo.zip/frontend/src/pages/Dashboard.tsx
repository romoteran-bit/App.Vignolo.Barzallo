import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api';
import type { DashboardResponse } from '../types/api';
import { useAuth } from '../context/AuthContext';
import { usePageHeader } from '../context/PageHeaderContext';
import { Card } from '../components/ui/Card';
import { KpiCard } from '../components/ui/KpiCard';
import { timeAgo, personaIniciales } from '../lib/format';
import { useNavigate } from 'react-router-dom';

function greeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Buenos días';
  if (h < 19) return 'Buenas tardes';
  return 'Buenas noches';
}

function apellidoCorto(nombre: string): string {
  const sinTitulo = nombre.replace(/^(Abg\.|Dr\.|Dra\.|Lic\.)\s*/i, '');
  return sinTitulo.split(' ')[0] ?? sinTitulo;
}

export function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({
    queryKey: ['dashboard'],
    queryFn: () => api.get<DashboardResponse>('/api/dashboard'),
  });

  const hoy = new Date().toLocaleDateString('es-EC', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  usePageHeader({
    title: `${greeting()}, ${apellidoCorto(user?.nombre ?? '')}`,
    subtitle: hoy.charAt(0).toUpperCase() + hoy.slice(1),
  });

  if (isLoading || !data) return <div style={{ color: '#8A857C', fontSize: 14 }}>Cargando panel…</div>;

  const kpis = [
    { label: 'Casos activos', val: String(data.kpis.casosActivos), delta: `+${data.kpis.casosNuevosMes} este mes`, deltaColor: '#2F5D50' },
    { label: 'Audiencias esta semana', val: String(data.kpis.audienciasSemana), delta: `${data.kpis.audienciasHoy} hoy`, deltaColor: '#A23A2E' },
    { label: 'Tareas pendientes', val: String(data.kpis.tareasPendientes), delta: `${data.kpis.tareasVencenHoy} vencen hoy`, deltaColor: '#8A6218' },
    { label: 'Clientes activos', val: String(data.kpis.clientesActivos), delta: `${data.kpis.clientesTotales} totales`, deltaColor: '#8A857C' },
  ];

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: 16, marginBottom: 22 }}>
        {kpis.map((k) => (
          <KpiCard key={k.label} label={k.label} value={k.val} delta={k.delta} deltaColor={k.deltaColor} />
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))', gap: 16, alignItems: 'start' }}>
        <Card noPad>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px var(--card-pad) 12px' }}>
            <div style={{ fontWeight: 600, fontSize: 15 }}>Agenda de hoy</div>
            <button onClick={() => navigate('/agenda')} style={{ fontSize: 12.5, color: 'var(--ac)', fontWeight: 600 }}>
              Ver agenda →
            </button>
          </div>
          {data.eventosHoy.length === 0 && <EmptyRow texto="Sin eventos para hoy." />}
          {data.eventosHoy.map((e, i) => (
            <div key={i} style={{ display: 'flex', gap: 13, padding: '11px var(--card-pad)', borderTop: '1px solid #F0EEE9' }}>
              <div style={{ width: 3, borderRadius: 3, background: e.color, flexShrink: 0 }} />
              <div style={{ width: 46, flexShrink: 0, fontSize: 13, fontWeight: 600, color: '#57544E' }}>{e.hora}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 600 }}>{e.titulo}</div>
                <div style={{ fontSize: 12, color: '#8A857C' }}>{e.sub}</div>
              </div>
              <div style={{ fontSize: 11, fontWeight: 600, color: e.color, alignSelf: 'center' }}>{tipoLabel(e.tipo)}</div>
            </div>
          ))}
        </Card>

        <Card noPad>
          <div style={{ padding: '16px var(--card-pad) 12px', fontWeight: 600, fontSize: 15 }}>Próximos vencimientos</div>
          {data.vencimientos.length === 0 && <EmptyRow texto="Sin vencimientos próximos." />}
          {data.vencimientos.map((v, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px var(--card-pad)', borderTop: '1px solid #F0EEE9' }}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke={v.color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
                <circle cx="12" cy="12" r="9" />
                <path d="M12 7v5l3 2" />
              </svg>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 500 }}>{v.texto}</div>
                <div style={{ fontSize: 12, color: '#8A857C' }}>{v.caso}</div>
              </div>
              <div style={{ fontSize: 12, fontWeight: 600, color: v.color, background: v.bg, padding: '3px 9px', borderRadius: 7 }}>{v.cuando}</div>
            </div>
          ))}
        </Card>

        <Card>
          <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 14 }}>Casos por materia</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {data.materiaStats.length === 0 && <EmptyText texto="Sin casos registrados." />}
            {data.materiaStats.map((m) => (
              <div key={m.m}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 5 }}>
                  <span style={{ fontWeight: 500 }}>{m.m}</span>
                  <span style={{ color: '#8A857C' }}>{m.n}</span>
                </div>
                <div style={{ height: 7, background: '#F0EEE9', borderRadius: 4, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: m.pct, background: 'var(--ac)', borderRadius: 4 }} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 14 }}>Casos por abogado</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 13 }}>
            {data.abogadoStats.length === 0 && <EmptyText texto="Sin casos asignados." />}
            {data.abogadoStats.map((a) => (
              <div key={a.a} style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                <div style={{ width: 30, height: 30, borderRadius: '50%', background: a.color, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11.5, fontWeight: 600, flexShrink: 0 }}>
                  {a.ini}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4 }}>
                    <span style={{ fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.a}</span>
                    <span style={{ color: '#8A857C', paddingLeft: 8 }}>{a.n}</span>
                  </div>
                  <div style={{ height: 7, background: '#F0EEE9', borderRadius: 4, overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: a.pct, background: a.color, borderRadius: 4 }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {user?.permisos.includes('ver_auditoria') && (
          <Card noPad style={{ gridColumn: '1/-1' }}>
            <div style={{ padding: '16px var(--card-pad) 12px', fontWeight: 600, fontSize: 15 }}>
              Actividad reciente <span style={{ fontWeight: 400, color: '#9B978F', fontSize: 12.5 }}>· registro de auditoría</span>
            </div>
            {data.actividad.length === 0 && <EmptyRow texto="Sin actividad registrada aún." />}
            {data.actividad.map((a, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px var(--card-pad)', borderTop: '1px solid #F0EEE9' }}>
                <div style={{ width: 28, height: 28, borderRadius: '50%', background: '#57544E', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600, flexShrink: 0 }}>
                  {personaIniciales(a.autor)}
                </div>
                <div style={{ flex: 1, fontSize: 13.5, color: '#46443E' }}>
                  <strong style={{ fontWeight: 600, color: '#1C1B18' }}>{a.autor}</strong> {a.accion}{' '}
                  {a.obj && <strong style={{ fontWeight: 600, color: 'var(--ac)' }}>{a.obj}</strong>}
                </div>
                <div style={{ fontSize: 12, color: '#9B978F', flexShrink: 0 }}>{timeAgo(a.cuando)}</div>
              </div>
            ))}
          </Card>
        )}
      </div>
    </div>
  );
}

function tipoLabel(tipo: string): string {
  const map: Record<string, string> = { AUDIENCIA: 'Audiencia', REUNION: 'Reunión', PLAZO: 'Plazo', LLAMADA: 'Llamada' };
  return map[tipo] ?? tipo;
}

function EmptyRow({ texto }: { texto: string }) {
  return <div style={{ padding: '20px var(--card-pad)', fontSize: 13, color: '#9B978F', textAlign: 'center' }}>{texto}</div>;
}
function EmptyText({ texto }: { texto: string }) {
  return <div style={{ fontSize: 13, color: '#9B978F' }}>{texto}</div>;
}
