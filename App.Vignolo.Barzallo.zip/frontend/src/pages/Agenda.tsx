import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api';
import type { EventoAgenda } from '../types/api';
import { usePageHeader } from '../context/PageHeaderContext';
import { Card } from '../components/ui/Card';

const WEEKDAYS = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
const MESES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre',
];

export function AgendaPage() {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1); // 1-12

  const { data: eventos } = useQuery({
    queryKey: ['agenda', year, month],
    queryFn: () => api.get<EventoAgenda[]>(`/api/agenda?year=${year}&month=${month}`),
  });

  usePageHeader({ title: 'Agenda', subtitle: `${MESES[month - 1]} ${year}` });

  const eventosPorDia = useMemo(() => {
    const map = new Map<number, EventoAgenda[]>();
    for (const e of eventos ?? []) {
      const d = new Date(e.fecha).getDate();
      const arr = map.get(d) ?? [];
      arr.push(e);
      map.set(d, arr);
    }
    return map;
  }, [eventos]);

  const first = new Date(year, month - 1, 1);
  const startDow = (first.getDay() + 6) % 7;
  const daysInMonth = new Date(year, month, 0).getDate();
  const prevMonthDays = new Date(year, month - 1, 0).getDate();

  const cells = [];
  for (let i = 0; i < 42; i++) {
    const dayNum = i - startDow + 1;
    const inMonth = dayNum >= 1 && dayNum <= daysInMonth;
    const label = inMonth ? dayNum : dayNum < 1 ? prevMonthDays + dayNum : dayNum - daysInMonth;
    const isToday = inMonth && dayNum === now.getDate() && month === now.getMonth() + 1 && year === now.getFullYear();
    const dots = inMonth ? eventosPorDia.get(dayNum) ?? [] : [];
    cells.push({ label, inMonth, isToday, dots });
  }

  function shiftMonth(delta: number) {
    let m = month + delta;
    let y = year;
    if (m < 1) { m = 12; y -= 1; }
    if (m > 12) { m = 1; y += 1; }
    setMonth(m);
    setYear(y);
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: 16, alignItems: 'start' }}>
      <Card style={{ gridColumn: '1/-1', maxWidth: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <div style={{ fontFamily: "'Spectral',serif", fontSize: 16, fontWeight: 600 }}>
            {MESES[month - 1]} {year}
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <NavButton onClick={() => shiftMonth(-1)} dir="prev" />
            <button
              onClick={() => {
                setMonth(now.getMonth() + 1);
                setYear(now.getFullYear());
              }}
              className="hover-surface"
              style={{ fontSize: 12.5, fontWeight: 600, color: '#57544E', padding: '0 12px', height: 30, borderRadius: 8, background: '#F3F2EE' }}
            >
              Hoy
            </button>
            <NavButton onClick={() => shiftMonth(1)} dir="next" />
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 6, marginBottom: 8 }}>
          {WEEKDAYS.map((w) => (
            <div key={w} style={{ textAlign: 'center', fontSize: 11.5, fontWeight: 600, color: '#9B978F' }}>
              {w}
            </div>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 6 }}>
          {cells.map((c, i) => (
            <div
              key={i}
              style={{
                aspectRatio: '1.15',
                borderRadius: 9,
                border: `1px solid ${c.isToday ? 'var(--ac)' : '#EDEBE5'}`,
                background: c.isToday ? 'var(--acSoft)' : c.inMonth ? '#fff' : '#FAF9F6',
                padding: '6px 7px',
                display: 'flex',
                flexDirection: 'column',
                gap: 4,
                minHeight: 52,
              }}
            >
              <div style={{ fontSize: 12.5, fontWeight: c.isToday ? 700 : 500, color: c.isToday ? 'var(--ac)' : c.inMonth ? '#33312C' : '#C4C0B7' }}>
                {c.label}
              </div>
              <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
                {c.dots.map((d) => (
                  <span key={d.id} title={d.titulo} style={{ width: 6, height: 6, borderRadius: '50%', background: d.color }} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function NavButton({ onClick, dir }: { onClick: () => void; dir: 'prev' | 'next' }) {
  return (
    <button
      onClick={onClick}
      className="hover-surface"
      style={{ width: 30, height: 30, borderRadius: 8, background: '#F3F2EE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
    >
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#57544E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        {dir === 'prev' ? <path d="M15 6l-6 6 6 6" /> : <path d="M9 6l6 6-6 6" />}
      </svg>
    </button>
  );
}
