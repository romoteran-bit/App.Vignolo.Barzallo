import { useState, type FormEvent } from 'react';
import { useAppearance } from '../context/AppearanceContext';
import { useAuth } from '../context/AuthContext';
import { useIsNarrow } from '../lib/useIsNarrow';
import { ApiError } from '../lib/api';

export function LoginPage() {
  const { login } = useAuth();
  const { cssVars, ac } = useAppearance();
  const isNarrow = useIsNarrow();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [recordar, setRecordar] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await login(email, password);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'No se pudo iniciar sesión.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      style={{
        ...cssVars,
        display: 'flex',
        height: '100vh',
        width: '100%',
        overflow: 'hidden',
        background: '#F6F5F2',
        color: '#1C1B18',
        fontFamily: "'Hanken Grotesk',system-ui,sans-serif",
      }}
    >
      {!isNarrow && (
        <div
          style={{
            flex: 1,
            background: '#1B1A17',
            color: '#F5F4F1',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            padding: '46px 44px',
            minWidth: 0,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div
              style={{
                width: 42,
                height: 42,
                borderRadius: 11,
                background: '#fff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
              }}
            >
              <img src="/assets/logo-vb.png" alt="Vignolo Barzallo" style={{ width: 30, height: 30, objectFit: 'contain' }} />
            </div>
            <div>
              <div style={{ fontFamily: "'Spectral',serif", fontWeight: 600, fontSize: 17, lineHeight: 1.1 }}>
                Vignolo Barzallo
              </div>
              <div style={{ fontSize: 11.5, color: 'rgba(245,244,241,0.55)', letterSpacing: 0.3 }}>Estudio Jurídico</div>
            </div>
          </div>
          <div>
            <div
              style={{
                fontFamily: "'Spectral',serif",
                fontSize: 'clamp(26px,3.4vw,38px)',
                lineHeight: 1.15,
                fontWeight: 600,
                maxWidth: 460,
              }}
            >
              La operación de su estudio, centralizada y segura.
            </div>
            <p style={{ margin: '18px 0 0', fontSize: 15, lineHeight: 1.6, color: 'rgba(245,244,241,0.62)', maxWidth: 420 }}>
              Casos, clientes, agenda, tareas y documentos en una sola plataforma. Acceso conforme a los permisos de su rol.
            </p>
          </div>
          <div style={{ fontSize: 12, color: 'rgba(245,244,241,0.4)' }}>© 2026 Vignolo Barzallo · Acceso restringido y auditado</div>
        </div>
      )}

      <div
        style={{
          width: 'min(500px,100%)',
          flexShrink: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: 32,
          background: '#F6F5F2',
        }}
      >
        <form onSubmit={onSubmit} style={{ width: '100%', maxWidth: 352 }}>
          <h1 style={{ fontFamily: "'Spectral',serif", fontSize: 26, fontWeight: 600, margin: '0 0 6px' }}>Iniciar sesión</h1>
          <p style={{ margin: '0 0 28px', fontSize: 14, color: '#8A857C' }}>Ingrese con sus credenciales del estudio.</p>

          <label style={{ display: 'block', fontSize: 12.5, fontWeight: 600, color: '#57544E', marginBottom: 7 }}>
            Correo electrónico
          </label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="usuario@vignolobarzallo.ec"
            className="focus-accent"
            style={inputStyle}
          />

          <label style={{ display: 'block', fontSize: 12.5, fontWeight: 600, color: '#57544E', marginBottom: 7 }}>
            Contraseña
          </label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            className="focus-accent"
            style={{ ...inputStyle, marginBottom: 14 }}
          />

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: '#57544E', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={recordar}
                onChange={(e) => setRecordar(e.target.checked)}
                style={{ width: 15, height: 15, accentColor: ac }}
              />
              Recordar dispositivo
            </label>
            <span style={{ fontSize: 13, color: ac, fontWeight: 600, cursor: 'pointer' }}>¿Olvidó su contraseña?</span>
          </div>

          {error && (
            <div
              style={{
                marginBottom: 16,
                padding: '10px 13px',
                borderRadius: 9,
                background: '#FBEAE7',
                color: '#A23A2E',
                fontSize: 13,
              }}
            >
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="hover-brighten"
            style={{
              width: '100%',
              height: 46,
              borderRadius: 10,
              background: ac,
              color: '#fff',
              fontSize: 14.5,
              fontWeight: 600,
              opacity: submitting ? 0.7 : 1,
            }}
          >
            {submitting ? 'Ingresando…' : 'Ingresar'}
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '18px 0' }}>
            <div style={{ flex: 1, height: 1, background: '#E7E4DD' }} />
            <span style={{ fontSize: 11.5, color: '#9B978F' }}>SEGURIDAD</span>
            <div style={{ flex: 1, height: 1, background: '#E7E4DD' }} />
          </div>

          <div style={{ display: 'flex', gap: 10, padding: '12px 14px', border: '1px solid #EDEBE5', borderRadius: 10, background: '#fff' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={ac} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: 1 }}>
              <rect x="4" y="10" width="16" height="10" rx="2" />
              <path d="M8 10V7a4 4 0 0 1 8 0v3" />
            </svg>
            <div style={{ fontSize: 12.5, color: '#57544E', lineHeight: 1.5 }}>
              Verificación en dos pasos activa. Se enviará un código a su dispositivo registrado.
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

const inputStyle = {
  width: '100%',
  height: 44,
  padding: '0 13px',
  border: '1px solid #E1DED6',
  borderRadius: 10,
  fontSize: 14,
  outline: 'none',
  marginBottom: 16,
  background: '#fff',
} as const;
