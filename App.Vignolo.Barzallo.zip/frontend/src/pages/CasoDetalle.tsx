import { useRef, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../lib/api';
import type { CasoDetalle } from '../types/api';
import { usePageHeader } from '../context/PageHeaderContext';
import { useAuth } from '../context/AuthContext';
import { Card } from '../components/ui/Card';
import { formatBytes, formatDateLong } from '../lib/format';
import { documentoExtColor } from '../theme/tokens';

const PRIORIDAD_LABEL: Record<string, string> = { ALTA: 'Alta', MEDIA: 'Media', BAJA: 'Baja' };
const TIPO_ACTUACION_LABEL: Record<string, string> = { ETAPA: 'Etapa', DOCUMENTO: 'Documento', ACTUACION: 'Actuación', CREACION: 'Creación' };

export function CasoDetallePage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { hasPermission } = useAuth();
  const queryClient = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const { data: caso, isLoading } = useQuery({
    queryKey: ['caso', id],
    queryFn: () => api.get<CasoDetalle>(`/api/casos/${id}`),
    enabled: !!id,
  });

  usePageHeader({ title: caso?.id ?? 'Caso', subtitle: caso?.cliente ?? '' });

  const etapaMutation = useMutation({
    mutationFn: (etapa: string) => api.patch(`/api/casos/${id}/etapa`, { etapa }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['caso', id] }),
  });

  const uploadMutation = useMutation({
    mutationFn: (file: File) => {
      const form = new FormData();
      form.append('casoId', id ?? '');
      form.append('file', file);
      return api.postForm('/api/documentos', form);
    },
    onSuccess: () => {
      setUploadError(null);
      queryClient.invalidateQueries({ queryKey: ['caso', id] });
    },
    onError: (err) => setUploadError(err instanceof Error ? err.message : 'No se pudo subir el documento'),
  });

  if (isLoading || !caso) {
    return <div style={{ color: '#8A857C', fontSize: 14 }}>Cargando caso…</div>;
  }

  const pr = prioridadColorFor(caso.prioridad);
  const puedeEditar = hasPermission('crear_editar_casos');
  const puedeSubir = hasPermission('subir_documentos');

  return (
    <div>
      <button
        onClick={() => navigate('/casos')}
        className="hover-opacity"
        style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: '#8A857C', fontWeight: 500, marginBottom: 16 }}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
          <path d="M15 6l-6 6 6 6" />
        </svg>
        Todos los casos
      </button>

      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 12, marginBottom: 6 }}>
        <h1 style={{ fontFamily: "'Spectral',serif", fontSize: 26, fontWeight: 600, margin: 0 }}>{caso.id}</h1>
        <span style={{ fontSize: 12, fontWeight: 600, padding: '4px 11px', borderRadius: 20, background: pr.bg, color: pr.fg }}>
          Prioridad {PRIORIDAD_LABEL[caso.prioridad] ?? caso.prioridad}
        </span>
        <span style={{ fontSize: 12, fontWeight: 600, padding: '4px 11px', borderRadius: 7, background: '#F0EEE9', color: '#46443E' }}>{caso.materia}</span>
      </div>
      <div style={{ fontSize: 15, color: '#57544E', marginBottom: 22 }}>
        {caso.cliente} · {caso.juzgado}
      </div>

      <Card style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', letterSpacing: 0.3, marginBottom: 14 }}>ETAPA PROCESAL</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {caso.etapas.map((name, i) => {
            let bg, fg, bd, dotBg, dotFg, num;
            if (i < caso.etapaIdx) {
              bg = 'var(--acSoft)'; fg = 'var(--ac)'; bd = 'transparent'; dotBg = 'var(--ac)'; dotFg = '#fff'; num = '✓';
            } else if (i === caso.etapaIdx) {
              bg = 'var(--ac)'; fg = '#fff'; bd = 'transparent'; dotBg = 'rgba(255,255,255,0.25)'; dotFg = '#fff'; num = String(i + 1);
            } else {
              bg = '#F3F2EE'; fg = '#9B978F'; bd = '#EAE7E0'; dotBg = '#E4E1DA'; dotFg = '#9B978F'; num = String(i + 1);
            }
            const clickable = puedeEditar && i !== caso.etapaIdx;
            return (
              <div
                key={name}
                onClick={clickable ? () => etapaMutation.mutate(name) : undefined}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 7,
                  padding: '6px 12px',
                  borderRadius: 20,
                  fontSize: 12.5,
                  fontWeight: 600,
                  background: bg,
                  color: fg,
                  border: `1px solid ${bd}`,
                  cursor: clickable ? 'pointer' : 'default',
                }}
                title={clickable ? `Marcar etapa: ${name}` : undefined}
              >
                <span style={{ width: 16, height: 16, borderRadius: '50%', background: dotBg, color: dotFg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9.5 }}>
                  {num}
                </span>
                {name}
              </div>
            );
          })}
        </div>
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: 16, alignItems: 'start' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Card>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', letterSpacing: 0.3, marginBottom: 10 }}>DESCRIPCIÓN</div>
            <p style={{ margin: '0 0 16px', fontSize: 14, lineHeight: 1.6, color: '#33312C' }}>{caso.descripcion}</p>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', letterSpacing: 0.3, marginBottom: 8 }}>ESTRATEGIA JURÍDICA</div>
            <p style={{ margin: '0 0 16px', fontSize: 14, lineHeight: 1.6, color: '#33312C' }}>{caso.estrategia}</p>
            <div style={{ display: 'flex', gap: 10, padding: '12px 14px', borderRadius: 10, background: '#FCF3E1', border: '1px solid #F0E4C4' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#8A6218" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: 1 }}>
                <path d="M12 3l9 16H3z" />
                <path d="M12 10v4M12 17h0" />
              </svg>
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: '#8A6218', marginBottom: 2 }}>RIESGOS</div>
                <div style={{ fontSize: 13.5, color: '#5E4B1B', lineHeight: 1.5 }}>{caso.riesgos}</div>
              </div>
            </div>
          </Card>

          <Card>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', letterSpacing: 0.3, marginBottom: 16 }}>CRONOLOGÍA DE ACTUACIONES</div>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {caso.cronologia.map((cr, i) => (
                <div key={i} style={{ display: 'flex', gap: 13 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                    <div style={{ width: 11, height: 11, borderRadius: '50%', background: 'var(--ac)', marginTop: 3 }} />
                    {i < caso.cronologia.length - 1 && <div style={{ width: 2, flex: 1, background: '#EAE7E0', minHeight: 14 }} />}
                  </div>
                  <div style={{ paddingBottom: 18 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                      <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--ac)', background: 'var(--acSoft)', padding: '2px 8px', borderRadius: 6 }}>
                        {TIPO_ACTUACION_LABEL[cr.tipo] ?? cr.tipo}
                      </span>
                      <span style={{ fontSize: 12, color: '#9B978F' }}>
                        {formatDateLong(cr.fecha)} · {cr.autor}
                      </span>
                    </div>
                    <div style={{ fontSize: 13.5, color: '#33312C', lineHeight: 1.5 }}>{cr.texto}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Card>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', letterSpacing: 0.3, marginBottom: 14 }}>DETALLE</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <DetailRow label="N.º de proceso" value={caso.numeroProceso} tabular />
              <DetailRow label="Contraparte" value={caso.contraparte} />
              <div style={{ display: 'flex', gap: 24 }}>
                <DetailRow label="Inicio" value={caso.inicio} />
                <DetailRow label="Cierre est." value={caso.cierreEstimado} />
              </div>
            </div>
          </Card>

          <Card>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', letterSpacing: 0.3, marginBottom: 14 }}>EQUIPO ASIGNADO</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
              {caso.equipo.map((m) => (
                <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                  <div style={{ width: 32, height: 32, borderRadius: '50%', background: m.color, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 600 }}>
                    {m.ini}
                  </div>
                  <div>
                    <div style={{ fontSize: 13.5, fontWeight: 600 }}>{m.nombre}</div>
                    <div style={{ fontSize: 12, color: '#9B978F' }}>{m.cargo}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', letterSpacing: 0.3 }}>DOCUMENTOS</div>
              {puedeSubir && (
                <>
                  <input
                    ref={fileRef}
                    type="file"
                    style={{ display: 'none' }}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) uploadMutation.mutate(file);
                      e.target.value = '';
                    }}
                  />
                  <button onClick={() => fileRef.current?.click()} style={{ fontSize: 12, color: 'var(--ac)', fontWeight: 600 }} disabled={uploadMutation.isPending}>
                    {uploadMutation.isPending ? 'Subiendo…' : '+ Subir'}
                  </button>
                </>
              )}
            </div>
            {uploadError && <div style={{ fontSize: 12.5, color: '#A23A2E', marginBottom: 10 }}>{uploadError}</div>}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
              {caso.documentos.length === 0 && <div style={{ fontSize: 13, color: '#9B978F' }}>Sin documentos cargados.</div>}
              {caso.documentos.map((d) => {
                const x = documentoExtColor(d.extension);
                return (
                  <a
                    key={d.id}
                    href={`/api/documentos/${d.id}/descargar`}
                    className="hover-accent-border"
                    style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '9px 11px', borderRadius: 9, border: '1px solid #EDEBE5', color: 'inherit' }}
                  >
                    <div style={{ width: 30, height: 30, borderRadius: 7, background: x.bg, color: x.fg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9.5, fontWeight: 700, flexShrink: 0 }}>
                      {d.extension}
                    </div>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{d.nombre}</div>
                      <div style={{ fontSize: 11.5, color: '#9B978F' }}>
                        {formatBytes(d.tamanoBytes)} · {formatDateLong(d.subidoEn)}
                      </div>
                    </div>
                  </a>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function DetailRow({ label, value, tabular }: { label: string; value: string; tabular?: boolean }) {
  return (
    <div>
      <div style={{ fontSize: 11.5, color: '#9B978F', marginBottom: 2 }}>{label}</div>
      <div className={tabular ? 'tabular-nums' : ''} style={{ fontSize: 13.5, fontWeight: 500 }}>
        {value}
      </div>
    </div>
  );
}

function prioridadColorFor(p: string): { bg: string; fg: string } {
  if (p === 'ALTA') return { bg: '#FBEAE7', fg: '#A23A2E' };
  if (p === 'MEDIA') return { bg: '#FCF3E1', fg: '#8A6218' };
  return { bg: '#EEEDE9', fg: '#75726B' };
}
