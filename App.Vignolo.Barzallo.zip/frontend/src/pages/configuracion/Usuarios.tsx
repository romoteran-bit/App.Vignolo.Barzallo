import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../../lib/api';
import type { RolOpcion, UsuarioListItem } from '../../types/api';
import { useAuth } from '../../context/AuthContext';
import { Card } from '../../components/ui/Card';
import { Avatar } from '../../components/ui/Avatar';
import { Field, inputStyle } from '../../components/ui/FormField';
import { formatLastLogin } from '../../lib/format';

export function UsuariosTab() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [showNew, setShowNew] = useState(false);
  const [resetTarget, setResetTarget] = useState<UsuarioListItem | null>(null);

  const { data: usuarios, isLoading } = useQuery({ queryKey: ['usuarios'], queryFn: () => api.get<UsuarioListItem[]>('/api/usuarios') });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['usuarios'] });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {showNew && <NuevoUsuarioForm onDone={() => { setShowNew(false); invalidate(); }} onCancel={() => setShowNew(false)} />}
      {resetTarget && (
        <RestablecerPasswordForm usuario={resetTarget} onDone={() => { setResetTarget(null); invalidate(); }} onCancel={() => setResetTarget(null)} />
      )}

      <Card noPad>
        <div style={{ padding: '16px var(--card-pad)', borderBottom: '1px solid #F0EEE9', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
          <div>
            <div style={{ fontWeight: 600, fontSize: 15 }}>Usuarios del sistema</div>
            <div style={{ fontSize: 12.5, color: '#8A857C', marginTop: 2 }}>
              Usuarios ilimitados. Las contraseñas se guardan cifradas; el administrador solo puede restablecerlas.
            </div>
          </div>
          <button
            onClick={() => setShowNew((v) => !v)}
            className="hover-brighten"
            style={{ display: 'flex', alignItems: 'center', gap: 6, height: 38, padding: '0 14px', borderRadius: 9, background: 'var(--ac)', color: '#fff', fontSize: 13, fontWeight: 600, flexShrink: 0 }}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M12 5v14M5 12h14" />
            </svg>
            Nuevo usuario
          </button>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 760 }}>
            <thead>
              <tr style={{ textAlign: 'left', color: '#8A857C', fontSize: 11.5, fontWeight: 600, letterSpacing: 0.4, textTransform: 'uppercase' }}>
                <th style={{ padding: '12px var(--card-pad)' }}>Usuario</th>
                <th style={{ padding: '12px 10px' }}>Rol</th>
                <th style={{ padding: '12px 10px' }}>Contraseña</th>
                <th style={{ padding: '12px 10px' }}>Último acceso</th>
                <th style={{ padding: '12px var(--card-pad)' }} />
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                <tr>
                  <td colSpan={5} style={{ padding: 20, textAlign: 'center', color: '#9B978F', fontSize: 13 }}>
                    Cargando…
                  </td>
                </tr>
              )}
              {usuarios?.map((u) => (
                <tr key={u.id} style={{ borderTop: '1px solid #F0EEE9' }}>
                  <td style={{ padding: 'var(--row-pad)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                      <Avatar initials={u.ini} bg={u.color} size={34} />
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 13.5, fontWeight: 600 }}>{u.nombre}</span>
                        {u.id === user?.id && (
                          <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--ac)', background: 'var(--acSoft)', padding: '2px 8px', borderRadius: 20 }}>Tu cuenta</span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: 'var(--row-pad)' }}>
                    <span style={{ fontSize: 12.5, fontWeight: 500, padding: '3px 10px', borderRadius: 7, background: '#F0EEE9', color: '#46443E' }}>{u.rol}</span>
                  </td>
                  <td style={{ padding: 'var(--row-pad)' }}>
                    <span
                      style={{
                        fontSize: 12,
                        fontWeight: 600,
                        padding: '3px 10px',
                        borderRadius: 20,
                        background: u.passwordEstablecida ? '#E7F0EB' : '#FCF3E1',
                        color: u.passwordEstablecida ? '#2F5D50' : '#8A6218',
                      }}
                    >
                      {u.passwordEstablecida ? 'Contraseña establecida' : 'Invitación pendiente'}
                    </span>
                  </td>
                  <td style={{ padding: 'var(--row-pad)', fontSize: 13, color: '#57544E' }}>{formatLastLogin(u.lastLoginAt)}</td>
                  <td style={{ padding: 'var(--row-pad)', textAlign: 'right' }}>
                    <button onClick={() => setResetTarget(u)} className="hover-underline" style={{ fontSize: 12.5, color: 'var(--ac)', fontWeight: 600 }}>
                      {u.passwordEstablecida ? 'Restablecer contraseña' : 'Reenviar invitación'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function NuevoUsuarioForm({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const { data: roles } = useQuery({ queryKey: ['roles-opciones'], queryFn: () => api.get<RolOpcion[]>('/api/roles/opciones') });
  const [form, setForm] = useState({ nombre: '', email: '', rolId: '', passwordTemporal: '', confirmar: '', mustReset: true });
  const [error, setError] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: () => api.post('/api/usuarios', { nombre: form.nombre, email: form.email, rolId: form.rolId, passwordTemporal: form.passwordTemporal, mustReset: form.mustReset }),
    onSuccess: onDone,
    onError: (err) => setError(err instanceof Error ? err.message : 'No se pudo crear el usuario'),
  });

  const rolId = form.rolId || roles?.[0]?.id || '';
  const passwordsMatch = form.passwordTemporal.length >= 10 && form.passwordTemporal === form.confirmar;

  return (
    <Card>
      <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Crear usuario</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 14, marginBottom: 14 }}>
        <Field label="Nombre completo">
          <input placeholder="Nombre y apellido" value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })} style={inputStyle} />
        </Field>
        <Field label="Correo electrónico">
          <input type="email" placeholder="usuario@vignolobarzallo.ec" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} style={inputStyle} />
        </Field>
        <Field label="Rol">
          <select value={rolId} onChange={(e) => setForm({ ...form, rolId: e.target.value })} style={inputStyle}>
            {roles?.map((r) => (
              <option key={r.id} value={r.id}>
                {r.nombre}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 14, marginBottom: 14 }}>
        <Field label="Contraseña temporal">
          <input type="password" placeholder="Mínimo 10 caracteres" value={form.passwordTemporal} onChange={(e) => setForm({ ...form, passwordTemporal: e.target.value })} style={inputStyle} />
        </Field>
        <Field label="Confirmar contraseña">
          <input type="password" placeholder="Repita la contraseña" value={form.confirmar} onChange={(e) => setForm({ ...form, confirmar: e.target.value })} style={inputStyle} />
        </Field>
      </div>
      <label style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 13, color: '#57544E', cursor: 'pointer', marginBottom: 18 }}>
        <input type="checkbox" checked={form.mustReset} onChange={(e) => setForm({ ...form, mustReset: e.target.checked })} style={{ width: 15, height: 15, accentColor: 'var(--ac)' }} />
        Exigir cambio de contraseña en el primer ingreso
      </label>
      {error && <div style={{ marginBottom: 14, fontSize: 13, color: '#A23A2E' }}>{error}</div>}
      <div style={{ display: 'flex', gap: 10 }}>
        <button
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending || !form.nombre || !form.email || !rolId || !passwordsMatch}
          className="hover-brighten"
          style={{ height: 40, padding: '0 18px', borderRadius: 9, background: 'var(--ac)', color: '#fff', fontSize: 13.5, fontWeight: 600, opacity: mutation.isPending ? 0.7 : 1 }}
        >
          Crear usuario
        </button>
        <button onClick={onCancel} className="hover-surface" style={{ height: 40, padding: '0 16px', borderRadius: 9, background: '#F3F2EE', color: '#57544E', fontSize: 13.5, fontWeight: 600 }}>
          Cancelar
        </button>
      </div>
    </Card>
  );
}

function RestablecerPasswordForm({ usuario, onDone, onCancel }: { usuario: UsuarioListItem; onDone: () => void; onCancel: () => void }) {
  const [passwordTemporal, setPasswordTemporal] = useState('');
  const [error, setError] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: () => api.post(`/api/usuarios/${usuario.id}/restablecer-password`, { passwordTemporal, mustReset: true }),
    onSuccess: onDone,
    onError: (err) => setError(err instanceof Error ? err.message : 'No se pudo restablecer la contraseña'),
  });

  return (
    <Card>
      <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 4 }}>Restablecer contraseña de {usuario.nombre}</div>
      <div style={{ fontSize: 12.5, color: '#8A857C', marginBottom: 16 }}>Se cerrarán todas sus sesiones activas y deberá cambiarla en el próximo ingreso.</div>
      <div style={{ maxWidth: 320, marginBottom: 16 }}>
        <Field label="Contraseña temporal">
          <input type="password" placeholder="Mínimo 10 caracteres" value={passwordTemporal} onChange={(e) => setPasswordTemporal(e.target.value)} style={inputStyle} />
        </Field>
      </div>
      {error && <div style={{ marginBottom: 14, fontSize: 13, color: '#A23A2E' }}>{error}</div>}
      <div style={{ display: 'flex', gap: 10 }}>
        <button
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending || passwordTemporal.length < 10}
          className="hover-brighten"
          style={{ height: 40, padding: '0 18px', borderRadius: 9, background: 'var(--ac)', color: '#fff', fontSize: 13.5, fontWeight: 600, opacity: mutation.isPending ? 0.7 : 1 }}
        >
          Restablecer
        </button>
        <button onClick={onCancel} className="hover-surface" style={{ height: 40, padding: '0 16px', borderRadius: 9, background: '#F3F2EE', color: '#57544E', fontSize: 13.5, fontWeight: 600 }}>
          Cancelar
        </button>
      </div>
    </Card>
  );
}
