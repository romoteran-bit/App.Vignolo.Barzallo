import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../../lib/api';
import type { Abogado } from '../../types/api';
import { Card } from '../../components/ui/Card';
import { Avatar } from '../../components/ui/Avatar';
import { Field, inputStyle } from '../../components/ui/FormField';
import { ACCENTS } from '../../theme/tokens';

export function AbogadosTab() {
  const queryClient = useQueryClient();
  const [showNew, setShowNew] = useState(false);
  const { data: abogados, isLoading } = useQuery({ queryKey: ['abogados'], queryFn: () => api.get<Abogado[]>('/api/abogados') });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {showNew && (
        <NuevoAbogadoForm
          onDone={() => {
            setShowNew(false);
            queryClient.invalidateQueries({ queryKey: ['abogados'] });
          }}
          onCancel={() => setShowNew(false)}
        />
      )}
      <Card noPad>
        <div style={{ padding: '16px var(--card-pad)', borderBottom: '1px solid #F0EEE9', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontWeight: 600, fontSize: 15 }}>Abogados del estudio</div>
            <div style={{ fontSize: 12.5, color: '#8A857C', marginTop: 2 }}>Almacenados en base de datos — se agregan, editan o desactivan desde aquí.</div>
          </div>
          <button
            onClick={() => setShowNew((v) => !v)}
            className="hover-brighten"
            style={{ fontSize: 13, fontWeight: 600, color: '#fff', background: 'var(--ac)', padding: '8px 14px', borderRadius: 9 }}
          >
            + Nuevo abogado
          </button>
        </div>
        {isLoading && <div style={{ padding: 20, textAlign: 'center', color: '#9B978F', fontSize: 13 }}>Cargando…</div>}
        {abogados?.map((a) => (
          <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '13px var(--card-pad)', borderTop: '1px solid #F0EEE9' }}>
            <Avatar initials={a.iniciales} bg={a.color} size={38} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 600 }}>{a.nombre}</div>
            </div>
            <span style={{ fontSize: 13, color: '#57544E' }}>{a.cargo}</span>
            <span style={{ fontSize: 12, fontWeight: 600, padding: '3px 10px', borderRadius: 20, background: a.activo ? '#E7F0EB' : '#EEEDE9', color: a.activo ? '#2F5D50' : '#75726B' }}>
              {a.activo ? 'Activo' : 'Inactivo'}
            </span>
          </div>
        ))}
      </Card>
    </div>
  );
}

function NuevoAbogadoForm({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const [form, setForm] = useState<{ nombre: string; iniciales: string; cargo: string; color: string }>({
    nombre: '',
    iniciales: '',
    cargo: 'Abogado',
    color: ACCENTS[0].accent,
  });
  const [error, setError] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: () => api.post('/api/abogados', form),
    onSuccess: onDone,
    onError: (err) => setError(err instanceof Error ? err.message : 'No se pudo crear el abogado'),
  });

  return (
    <Card>
      <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Nuevo abogado</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', gap: 14, marginBottom: 18 }}>
        <Field label="Nombre completo">
          <input value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })} style={inputStyle} />
        </Field>
        <Field label="Iniciales">
          <input maxLength={3} value={form.iniciales} onChange={(e) => setForm({ ...form, iniciales: e.target.value.toUpperCase() })} style={inputStyle} />
        </Field>
        <Field label="Cargo">
          <input value={form.cargo} onChange={(e) => setForm({ ...form, cargo: e.target.value })} style={inputStyle} />
        </Field>
        <Field label="Color">
          <select value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} style={inputStyle}>
            {ACCENTS.map((a) => (
              <option key={a.accent} value={a.accent}>
                {a.label}
              </option>
            ))}
          </select>
        </Field>
      </div>
      {error && <div style={{ marginBottom: 14, fontSize: 13, color: '#A23A2E' }}>{error}</div>}
      <div style={{ display: 'flex', gap: 10 }}>
        <button
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending || !form.nombre || !form.iniciales || !form.cargo}
          className="hover-brighten"
          style={{ height: 40, padding: '0 18px', borderRadius: 9, background: 'var(--ac)', color: '#fff', fontSize: 13.5, fontWeight: 600, opacity: mutation.isPending ? 0.7 : 1 }}
        >
          Crear abogado
        </button>
        <button onClick={onCancel} className="hover-surface" style={{ height: 40, padding: '0 16px', borderRadius: 9, background: '#F3F2EE', color: '#57544E', fontSize: 13.5, fontWeight: 600 }}>
          Cancelar
        </button>
      </div>
    </Card>
  );
}
