import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../../lib/api';
import type { CategoriaCatalogo } from '../../types/api';
import { Card } from '../../components/ui/Card';

const CATEGORIAS: { key: CategoriaCatalogo; titulo: string }[] = [
  { key: 'MATERIA', titulo: 'Materias' },
  { key: 'ETAPA_PROCESAL', titulo: 'Etapas procesales' },
  { key: 'PRIORIDAD', titulo: 'Prioridades' },
  { key: 'TIPO_CLIENTE', titulo: 'Tipos de cliente' },
];

export function CatalogosTab() {
  const queryClient = useQueryClient();
  const { data } = useQuery({ queryKey: ['catalogos'], queryFn: () => api.get<Record<string, string[]>>('/api/catalogos') });

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))', gap: 16 }}>
      {CATEGORIAS.map((cat) => (
        <CatalogoCard key={cat.key} categoria={cat.key} titulo={cat.titulo} items={data?.[cat.key] ?? []} onAdded={() => queryClient.invalidateQueries({ queryKey: ['catalogos'] })} />
      ))}
    </div>
  );
}

function CatalogoCard({ categoria, titulo, items, onAdded }: { categoria: CategoriaCatalogo; titulo: string; items: string[]; onAdded: () => void }) {
  const [adding, setAdding] = useState(false);
  const [valor, setValor] = useState('');

  const mutation = useMutation({
    mutationFn: () => api.post('/api/catalogos', { categoria, valor }),
    onSuccess: () => {
      setValor('');
      setAdding(false);
      onAdded();
    },
  });

  return (
    <Card>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div style={{ fontWeight: 600, fontSize: 14.5 }}>{titulo}</div>
        <button onClick={() => setAdding((v) => !v)} style={{ fontSize: 12, color: 'var(--ac)', fontWeight: 600 }}>
          + Añadir
        </button>
      </div>
      {adding && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
          <input
            autoFocus
            value={valor}
            onChange={(e) => setValor(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && valor.trim()) mutation.mutate();
            }}
            placeholder="Nuevo valor…"
            style={{ flex: 1, height: 34, padding: '0 10px', border: '1px solid #E1DED6', borderRadius: 8, fontSize: 13, outline: 'none' }}
          />
          <button
            onClick={() => valor.trim() && mutation.mutate()}
            disabled={!valor.trim() || mutation.isPending}
            className="hover-brighten"
            style={{ height: 34, padding: '0 12px', borderRadius: 8, background: 'var(--ac)', color: '#fff', fontSize: 12.5, fontWeight: 600 }}
          >
            Añadir
          </button>
        </div>
      )}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {items.length === 0 && <span style={{ fontSize: 12.5, color: '#9B978F' }}>Sin valores.</span>}
        {items.map((it) => (
          <span key={it} style={{ fontSize: 12.5, fontWeight: 500, padding: '5px 12px', borderRadius: 20, background: '#F0EEE9', color: '#46443E' }}>
            {it}
          </span>
        ))}
      </div>
    </Card>
  );
}
