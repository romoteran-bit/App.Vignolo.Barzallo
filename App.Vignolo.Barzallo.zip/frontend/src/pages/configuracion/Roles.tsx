import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../../lib/api';
import type { RolesMatrixResponse } from '../../types/api';
import { Card } from '../../components/ui/Card';

export function RolesTab() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ['roles-matrix'], queryFn: () => api.get<RolesMatrixResponse>('/api/roles') });

  const toggle = useMutation({
    mutationFn: (vars: { rolId: string; permisoClave: string; permitido: boolean }) => api.put('/api/roles/permisos', vars),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['roles-matrix'] }),
  });

  if (isLoading || !data) return <div style={{ color: '#8A857C', fontSize: 14 }}>Cargando…</div>;

  return (
    <Card noPad>
      <div style={{ padding: '16px var(--card-pad)', borderBottom: '1px solid #F0EEE9' }}>
        <div style={{ fontWeight: 600, fontSize: 15 }}>Matriz de permisos</div>
        <div style={{ fontSize: 12.5, color: '#8A857C', marginTop: 2 }}>
          Los permisos se administran aquí, no en el código. Haga clic en una celda para conceder o revocar el acceso.
        </div>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 640 }}>
          <thead>
            <tr style={{ color: '#8A857C', fontSize: 11.5, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.4 }}>
              <th style={{ padding: '12px var(--card-pad)', textAlign: 'left' }}>Permiso</th>
              {data.roles.map((r) => (
                <th key={r.id} style={{ padding: '12px 8px', textAlign: 'center' }}>
                  {r.nombre}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.permisos.map((p) => (
              <tr key={p.clave} style={{ borderTop: '1px solid #F0EEE9' }}>
                <td style={{ padding: '12px var(--card-pad)', fontSize: 13.5, fontWeight: 500 }}>{p.etiqueta}</td>
                {data.roles.map((r) => {
                  const permitido = r.permisos.includes(p.clave);
                  const editable = r.nombre !== 'Administrador';
                  return (
                    <td key={r.id} style={{ padding: '12px 8px', textAlign: 'center' }}>
                      <button
                        onClick={editable ? () => toggle.mutate({ rolId: r.id, permisoClave: p.clave, permitido: !permitido }) : undefined}
                        disabled={!editable || toggle.isPending}
                        title={editable ? `${permitido ? 'Revocar' : 'Conceder'} "${p.etiqueta}" para ${r.nombre}` : 'El rol Administrador no es editable'}
                        style={{
                          fontSize: 15,
                          color: permitido ? 'var(--ac)' : '#CFCBC2',
                          cursor: editable ? 'pointer' : 'default',
                          width: 26,
                          height: 26,
                          borderRadius: 6,
                        }}
                        className={editable ? 'hover-surface' : ''}
                      >
                        {permitido ? '✓' : '·'}
                      </button>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
