import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../../lib/api';
import type { ConfiguracionGeneral } from '../../types/api';
import { Card } from '../../components/ui/Card';
import { Field, inputStyle } from '../../components/ui/FormField';
import { useAppearance, type Density, type SidebarTheme } from '../../context/AppearanceContext';
import { ACCENTS } from '../../theme/tokens';

export function GeneralTab() {
  const queryClient = useQueryClient();
  const { data } = useQuery({ queryKey: ['config-general'], queryFn: () => api.get<ConfiguracionGeneral>('/api/config/general') });
  const [form, setForm] = useState<Pick<ConfiguracionGeneral, 'nombreEstudio' | 'zonaHoraria' | 'moneda' | 'dosFactoresHabilitado'> | null>(null);

  useEffect(() => {
    if (data) setForm({ nombreEstudio: data.nombreEstudio, zonaHoraria: data.zonaHoraria, moneda: data.moneda, dosFactoresHabilitado: data.dosFactoresHabilitado });
  }, [data]);

  const mutation = useMutation({
    mutationFn: () => api.patch('/api/config/general', form),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['config-general'] }),
  });

  const { accentIndex, setAccentIndex, sidebarTheme, setSidebarTheme, density, setDensity } = useAppearance();

  if (!form) return <div style={{ color: '#8A857C', fontSize: 14 }}>Cargando…</div>;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 560 }}>
      <Card>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <Field label="Nombre del estudio">
            <input value={form.nombreEstudio} onChange={(e) => setForm({ ...form, nombreEstudio: e.target.value })} style={inputStyle} />
          </Field>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            <div style={{ flex: 1, minWidth: 180 }}>
              <Field label="Zona horaria">
                <input value={form.zonaHoraria} onChange={(e) => setForm({ ...form, zonaHoraria: e.target.value })} style={inputStyle} />
              </Field>
            </div>
            <div style={{ flex: 1, minWidth: 140 }}>
              <Field label="Moneda">
                <input value={form.moneda} onChange={(e) => setForm({ ...form, moneda: e.target.value })} style={inputStyle} />
              </Field>
            </div>
          </div>

          <Toggle
            label="Autenticación en dos pasos (2FA)"
            sub="Refuerza el acceso de todos los usuarios"
            on={form.dosFactoresHabilitado}
            onToggle={() => setForm({ ...form, dosFactoresHabilitado: !form.dosFactoresHabilitado })}
          />
          <Toggle label="Eliminación lógica (soft delete)" sub="Nada se borra físicamente — se conserva la trazabilidad" on={true} disabled />

          <div>
            <button
              onClick={() => mutation.mutate()}
              disabled={mutation.isPending}
              className="hover-brighten"
              style={{ height: 40, padding: '0 18px', borderRadius: 9, background: 'var(--ac)', color: '#fff', fontSize: 13.5, fontWeight: 600, opacity: mutation.isPending ? 0.7 : 1 }}
            >
              Guardar cambios
            </button>
          </div>
        </div>
      </Card>

      <Card>
        <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 4 }}>Apariencia</div>
        <div style={{ fontSize: 12.5, color: '#8A857C', marginBottom: 16 }}>Preferencias visuales guardadas en este navegador.</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', marginBottom: 8 }}>Color de acento</div>
            <div style={{ display: 'flex', gap: 8 }}>
              {ACCENTS.map((a, i) => (
                <button
                  key={a.accent}
                  onClick={() => setAccentIndex(i)}
                  title={a.label}
                  style={{
                    width: 30,
                    height: 30,
                    borderRadius: '50%',
                    background: a.accent,
                    border: i === accentIndex ? '2px solid #1C1B18' : '2px solid transparent',
                    outline: i === accentIndex ? '2px solid #fff' : 'none',
                    outlineOffset: -4,
                  }}
                />
              ))}
            </div>
          </div>
          <SegmentedToggle label="Barra lateral" value={sidebarTheme} options={['Oscuro', 'Claro']} onChange={(v) => setSidebarTheme(v as SidebarTheme)} />
          <SegmentedToggle label="Densidad" value={density} options={['Cómoda', 'Compacta']} onChange={(v) => setDensity(v as Density)} />
        </div>
      </Card>
    </div>
  );
}

function Toggle({ label, sub, on, onToggle, disabled }: { label: string; sub: string; on: boolean; onToggle?: () => void; disabled?: boolean }) {
  return (
    <div
      onClick={disabled ? undefined : onToggle}
      style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px', border: '1px solid #EDEBE5', borderRadius: 10, cursor: disabled ? 'default' : 'pointer' }}
    >
      <div>
        <div style={{ fontSize: 13.5, fontWeight: 600 }}>{label}</div>
        <div style={{ fontSize: 12, color: '#9B978F' }}>{sub}</div>
      </div>
      <div style={{ width: 42, height: 24, borderRadius: 20, background: on ? 'var(--ac)' : '#DAD7CF', position: 'relative', flexShrink: 0 }}>
        <span style={{ position: 'absolute', top: 3, [on ? 'right' : 'left']: 3, width: 18, height: 18, borderRadius: '50%', background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,.2)' }} />
      </div>
    </div>
  );
}

function SegmentedToggle<T extends string>({ label, value, options, onChange }: { label: string; value: T; options: T[]; onChange: (v: T) => void }) {
  return (
    <div>
      <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', marginBottom: 8 }}>{label}</div>
      <div style={{ display: 'flex', gap: 4, background: '#F1EFEA', borderRadius: 9, padding: 4, width: 'fit-content' }}>
        {options.map((o) => {
          const on = o === value;
          return (
            <button
              key={o}
              onClick={() => onChange(o)}
              style={{ padding: '6px 13px', borderRadius: 6, fontSize: 12.5, fontWeight: 600, background: on ? '#fff' : 'transparent', color: on ? '#1C1B18' : '#8A857C', boxShadow: on ? '0 1px 3px rgba(0,0,0,.08)' : 'none' }}
            >
              {o}
            </button>
          );
        })}
      </div>
    </div>
  );
}
