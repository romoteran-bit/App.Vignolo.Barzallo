import { useState, type CSSProperties, type ReactNode } from 'react';
import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import { api } from '../lib/api';
import type { Abogado, ClienteListItem, EstadoCliente } from '../types/api';
import { usePageHeader } from '../context/PageHeaderContext';
import { useAuth } from '../context/AuthContext';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Avatar } from '../components/ui/Avatar';
import { ClienteDrawer } from '../components/ClienteDrawer';
import { clienteEstadoColor, avatarColorFor } from '../theme/tokens';
import { clienteIniciales } from '../lib/format';

const FILTROS: (EstadoCliente | 'Todos')[] = ['Todos', 'ACTIVO', 'VIP', 'POTENCIAL', 'INACTIVO'];
const FILTRO_LABEL: Record<string, string> = { Todos: 'Todos', ACTIVO: 'Activo', VIP: 'VIP', POTENCIAL: 'Potencial', INACTIVO: 'Inactivo' };
const ESTADO_LABEL: Record<string, string> = { ACTIVO: 'Activo', VIP: 'VIP', POTENCIAL: 'Potencial', INACTIVO: 'Inactivo' };
const TIPO_CLIENTE_OPTS = ['Empresa', 'Persona natural'];

export function ClientesPage() {
  const { hasPermission } = useAuth();
  const [filtro, setFiltro] = useState<string>('Todos');
  const [drawerId, setDrawerId] = useState<string | null>(null);
  const [showNew, setShowNew] = useState(false);
  const queryClient = useQueryClient();

  const { data: clientes, isLoading } = useQuery({
    queryKey: ['clientes', filtro],
    queryFn: () => api.get<ClienteListItem[]>(`/api/clientes?estado=${encodeURIComponent(filtro)}`),
  });

  usePageHeader({
    title: 'Clientes',
    subtitle: clientes ? `${clientes.length} registrados` : '',
    primaryLabel: hasPermission('gestionar_clientes') ? 'Nuevo cliente' : undefined,
    onPrimary: () => setShowNew((v) => !v),
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['clientes'] });

  return (
    <div>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
        {FILTROS.map((f) => {
          const on = filtro === f;
          return (
            <button
              key={f}
              onClick={() => setFiltro(f)}
              style={{
                padding: '6px 14px',
                borderRadius: 20,
                fontSize: 13,
                fontWeight: 500,
                border: `1px solid ${on ? 'var(--ac)' : '#E1DED6'}`,
                background: on ? 'var(--ac)' : '#fff',
                color: on ? '#fff' : '#57544E',
              }}
            >
              {FILTRO_LABEL[f]}
            </button>
          );
        })}
      </div>

      {showNew && hasPermission('gestionar_clientes') && (
        <NuevoClienteForm
          onDone={() => {
            setShowNew(false);
            invalidate();
          }}
          onCancel={() => setShowNew(false)}
        />
      )}

      <Card noPad>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 720 }}>
            <thead>
              <tr style={{ textAlign: 'left', color: '#8A857C', fontSize: 11.5, fontWeight: 600, letterSpacing: 0.4, textTransform: 'uppercase' }}>
                <th style={{ padding: '12px var(--card-pad)' }}>Cliente</th>
                <th style={{ padding: '12px 10px' }}>Tipo</th>
                <th style={{ padding: '12px 10px' }}>Identificación</th>
                <th style={{ padding: '12px 10px' }}>Ciudad</th>
                <th style={{ padding: '12px 10px' }}>Casos</th>
                <th style={{ padding: '12px 10px' }}>Estado</th>
                <th style={{ padding: '12px var(--card-pad)' }}>Resp.</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                <tr>
                  <td colSpan={7} style={{ padding: 20, textAlign: 'center', color: '#9B978F', fontSize: 13 }}>
                    Cargando…
                  </td>
                </tr>
              )}
              {!isLoading && clientes?.length === 0 && (
                <tr>
                  <td colSpan={7} style={{ padding: 20, textAlign: 'center', color: '#9B978F', fontSize: 13 }}>
                    No hay clientes con este filtro.
                  </td>
                </tr>
              )}
              {clientes?.map((c) => {
                const est = clienteEstadoColor(c.estado);
                const av = avatarColorFor(c.nombre);
                return (
                  <tr key={c.id} onClick={() => setDrawerId(c.id)} className="hover-row" style={{ borderTop: '1px solid #F0EEE9', cursor: 'pointer' }}>
                    <td style={{ padding: 'var(--row-pad)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                        <Avatar initials={clienteIniciales(c.nombre)} bg={av.bg} fg={av.fg} size={32} square />
                        <div style={{ fontSize: 13.5, fontWeight: 600 }}>{c.nombre}</div>
                      </div>
                    </td>
                    <td style={{ padding: 'var(--row-pad)', fontSize: 13, color: '#57544E' }}>{c.tipo}</td>
                    <td className="tabular-nums" style={{ padding: 'var(--row-pad)', fontSize: 13, color: '#57544E' }}>
                      {c.identificacion}
                    </td>
                    <td style={{ padding: 'var(--row-pad)', fontSize: 13, color: '#57544E' }}>{c.ciudad}</td>
                    <td style={{ padding: 'var(--row-pad)', fontSize: 13, color: '#57544E' }}>{c.casos}</td>
                    <td style={{ padding: 'var(--row-pad)' }}>
                      <Badge bg={est.bg} fg={est.fg}>
                        {ESTADO_LABEL[c.estado] ?? c.estado}
                      </Badge>
                    </td>
                    <td style={{ padding: 'var(--row-pad)' }}>
                      <Avatar initials={c.responsable.ini} bg={c.responsable.color} size={28} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {drawerId && <ClienteDrawer clienteId={drawerId} onClose={() => setDrawerId(null)} />}
    </div>
  );
}

function NuevoClienteForm({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const { data: abogados } = useQuery({ queryKey: ['abogados'], queryFn: () => api.get<Abogado[]>('/api/abogados') });
  const [form, setForm] = useState({
    nombre: '',
    tipo: 'Empresa',
    estado: 'POTENCIAL' as EstadoCliente,
    identificacion: '',
    telefono: '',
    ciudad: '',
    responsableId: '',
  });
  const [error, setError] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: () => api.post('/api/clientes', form),
    onSuccess: onDone,
    onError: (err) => setError(err instanceof Error ? err.message : 'No se pudo crear el cliente'),
  });

  const responsableId = form.responsableId || abogados?.[0]?.id || '';

  return (
    <Card style={{ marginBottom: 16 }}>
      <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Nuevo cliente</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 14, marginBottom: 14 }}>
        <Field label="Nombre completo o razón social">
          <input value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })} style={inputStyle} />
        </Field>
        <Field label="Tipo">
          <select value={form.tipo} onChange={(e) => setForm({ ...form, tipo: e.target.value })} style={inputStyle}>
            {TIPO_CLIENTE_OPTS.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>
        <Field label="Estado">
          <select value={form.estado} onChange={(e) => setForm({ ...form, estado: e.target.value as EstadoCliente })} style={inputStyle}>
            {(['POTENCIAL', 'ACTIVO', 'VIP', 'INACTIVO'] as EstadoCliente[]).map((e) => (
              <option key={e} value={e}>
                {ESTADO_LABEL[e]}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 14, marginBottom: 14 }}>
        <Field label="Identificación (RUC/CI)">
          <input value={form.identificacion} onChange={(e) => setForm({ ...form, identificacion: e.target.value })} style={inputStyle} />
        </Field>
        <Field label="Teléfono">
          <input value={form.telefono} onChange={(e) => setForm({ ...form, telefono: e.target.value })} style={inputStyle} />
        </Field>
        <Field label="Ciudad">
          <input value={form.ciudad} onChange={(e) => setForm({ ...form, ciudad: e.target.value })} style={inputStyle} />
        </Field>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 14, marginBottom: 18 }}>
        <Field label="Abogado responsable">
          <select value={responsableId} onChange={(e) => setForm({ ...form, responsableId: e.target.value })} style={inputStyle}>
            {abogados?.map((a) => (
              <option key={a.id} value={a.id}>
                {a.nombre}
              </option>
            ))}
          </select>
        </Field>
      </div>
      {error && <div style={{ marginBottom: 14, fontSize: 13, color: '#A23A2E' }}>{error}</div>}
      <div style={{ display: 'flex', gap: 10 }}>
        <button
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending || !form.nombre || !form.identificacion || !responsableId}
          className="hover-brighten"
          style={{ height: 40, padding: '0 18px', borderRadius: 9, background: 'var(--ac)', color: '#fff', fontSize: 13.5, fontWeight: 600, opacity: mutation.isPending ? 0.7 : 1 }}
        >
          Crear cliente
        </button>
        <button onClick={onCancel} className="hover-surface" style={{ height: 40, padding: '0 16px', borderRadius: 9, background: '#F3F2EE', color: '#57544E', fontSize: 13.5, fontWeight: 600 }}>
          Cancelar
        </button>
      </div>
    </Card>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', marginBottom: 6 }}>{label}</div>
      {children}
    </div>
  );
}

const inputStyle: CSSProperties = {
  width: '100%',
  height: 40,
  padding: '0 12px',
  border: '1px solid #E1DED6',
  borderRadius: 9,
  fontSize: 14,
  outline: 'none',
  background: '#fff',
};
