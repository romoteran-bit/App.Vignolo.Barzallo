import { useState } from 'react';
import { usePageHeader } from '../context/PageHeaderContext';
import { useAuth } from '../context/AuthContext';
import { UsuariosTab } from './configuracion/Usuarios';
import { RolesTab } from './configuracion/Roles';
import { CatalogosTab } from './configuracion/Catalogos';
import { AbogadosTab } from './configuracion/Abogados';
import { GeneralTab } from './configuracion/General';

type TabKey = 'users' | 'roles' | 'cat' | 'ab' | 'gen';

export function ConfiguracionPage() {
  const { hasPermission } = useAuth();

  const tabs: { key: TabKey; label: string; visible: boolean }[] = [
    { key: 'users', label: 'Usuarios', visible: hasPermission('administrar_usuarios') },
    { key: 'roles', label: 'Roles y permisos', visible: hasPermission('configurar_sistema') },
    { key: 'cat', label: 'Catálogos', visible: hasPermission('configurar_sistema') },
    { key: 'ab', label: 'Abogados', visible: hasPermission('configurar_sistema') },
    { key: 'gen', label: 'General', visible: hasPermission('configurar_sistema') },
  ];
  const visibleTabs = tabs.filter((t) => t.visible);
  const [tab, setTab] = useState<TabKey>(visibleTabs[0]?.key ?? 'gen');

  usePageHeader({ title: 'Configuración', subtitle: 'Administración del sistema' });

  return (
    <div>
      <div style={{ display: 'flex', gap: 4, background: '#F1EFEA', borderRadius: 11, padding: 4, marginBottom: 20, width: 'fit-content', flexWrap: 'wrap' }}>
        {visibleTabs.map((t) => {
          const on = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              style={{
                padding: '8px 15px',
                borderRadius: 8,
                fontSize: 13,
                fontWeight: 600,
                background: on ? '#fff' : 'transparent',
                color: on ? '#1C1B18' : '#8A857C',
                boxShadow: on ? '0 1px 3px rgba(0,0,0,.08)' : 'none',
              }}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      {tab === 'users' && hasPermission('administrar_usuarios') && <UsuariosTab />}
      {tab === 'roles' && hasPermission('configurar_sistema') && <RolesTab />}
      {tab === 'cat' && hasPermission('configurar_sistema') && <CatalogosTab />}
      {tab === 'ab' && hasPermission('configurar_sistema') && <AbogadosTab />}
      {tab === 'gen' && hasPermission('configurar_sistema') && <GeneralTab />}

      {visibleTabs.length === 0 && <div style={{ fontSize: 14, color: '#8A857C' }}>No tiene permisos de configuración.</div>}
    </div>
  );
}
