import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { api } from '../lib/api';
import type { CasoListItem } from '../types/api';
import { usePageHeader } from '../context/PageHeaderContext';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { prioridadColor } from '../theme/tokens';

const PRIORIDAD_LABEL: Record<string, string> = { ALTA: 'Alta', MEDIA: 'Media', BAJA: 'Baja' };

export function CasosPage() {
  const navigate = useNavigate();
  const { data: casos, isLoading } = useQuery({
    queryKey: ['casos'],
    queryFn: () => api.get<CasoListItem[]>('/api/casos'),
  });

  usePageHeader({ title: 'Casos', subtitle: casos ? `${casos.length} activos` : '' });

  return (
    <Card noPad>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 860 }}>
          <thead>
            <tr style={{ textAlign: 'left', color: '#8A857C', fontSize: 11.5, fontWeight: 600, letterSpacing: 0.4, textTransform: 'uppercase' }}>
              <th style={{ padding: '12px var(--card-pad)' }}>Código</th>
              <th style={{ padding: '12px 10px' }}>Cliente</th>
              <th style={{ padding: '12px 10px' }}>Materia</th>
              <th style={{ padding: '12px 10px' }}>Etapa actual</th>
              <th style={{ padding: '12px 10px' }}>Prioridad</th>
              <th style={{ padding: '12px 10px' }}>Equipo</th>
              <th style={{ padding: '12px var(--card-pad)' }}>Próxima actuación</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={7} style={{ padding: 20, textAlign: 'center', color: '#9B978F', fontSize: 13 }}>
                  Cargando…
                </td>
              </tr>
            )}
            {!isLoading && casos?.length === 0 && (
              <tr>
                <td colSpan={7} style={{ padding: 20, textAlign: 'center', color: '#9B978F', fontSize: 13 }}>
                  No tiene casos visibles.
                </td>
              </tr>
            )}
            {casos?.map((c) => {
              const pr = prioridadColor(c.prioridad);
              return (
                <tr key={c.id} onClick={() => navigate(`/casos/${c.id}`)} className="hover-row" style={{ borderTop: '1px solid #F0EEE9', cursor: 'pointer' }}>
                  <td className="tabular-nums" style={{ padding: 'var(--row-pad)', fontSize: 13, fontWeight: 600, color: 'var(--ac)' }}>
                    {c.id}
                  </td>
                  <td style={{ padding: 'var(--row-pad)', fontSize: 13.5, fontWeight: 500 }}>{c.cliente}</td>
                  <td style={{ padding: 'var(--row-pad)' }}>
                    <Badge bg="#F0EEE9" fg="#46443E" square>
                      {c.materia}
                    </Badge>
                  </td>
                  <td style={{ padding: 'var(--row-pad)', fontSize: 13, color: '#57544E' }}>{c.etapa}</td>
                  <td style={{ padding: 'var(--row-pad)' }}>
                    <Badge bg={pr.bg} fg={pr.fg}>
                      {PRIORIDAD_LABEL[c.prioridad] ?? c.prioridad}
                    </Badge>
                  </td>
                  <td style={{ padding: 'var(--row-pad)' }}>
                    <div style={{ display: 'flex' }}>
                      {c.equipo.map((r, i) => (
                        <div
                          key={r.id}
                          style={{
                            width: 27,
                            height: 27,
                            borderRadius: '50%',
                            background: r.color,
                            color: '#fff',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: 10.5,
                            fontWeight: 600,
                            border: '2px solid #fff',
                            marginLeft: i === 0 ? 0 : -7,
                          }}
                        >
                          {r.ini}
                        </div>
                      ))}
                    </div>
                  </td>
                  <td style={{ padding: 'var(--row-pad)', fontSize: 12.5, color: '#57544E' }}>{c.proxima}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
