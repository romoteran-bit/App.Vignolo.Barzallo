import { useMemo, useRef, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../lib/api';
import type { CasoListItem, Documento } from '../types/api';
import { usePageHeader } from '../context/PageHeaderContext';
import { useAuth } from '../context/AuthContext';
import { Card } from '../components/ui/Card';
import { Avatar } from '../components/ui/Avatar';
import { formatBytes, formatDateShort } from '../lib/format';
import { documentoExtColor } from '../theme/tokens';

export function DocumentosPage() {
  const { hasPermission } = useAuth();
  const queryClient = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [casoId, setCasoId] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const { data: documentos, isLoading } = useQuery({ queryKey: ['documentos'], queryFn: () => api.get<Documento[]>('/api/documentos') });
  const { data: casos } = useQuery({ queryKey: ['casos'], queryFn: () => api.get<CasoListItem[]>('/api/casos'), enabled: hasPermission('subir_documentos') });

  usePageHeader({ title: 'Documentos', subtitle: 'Repositorio del estudio' });

  const uploadMutation = useMutation({
    mutationFn: (file: File) => {
      const form = new FormData();
      if (casoId) form.append('casoId', casoId);
      form.append('file', file);
      return api.postForm('/api/documentos', form);
    },
    onSuccess: () => {
      setError(null);
      queryClient.invalidateQueries({ queryKey: ['documentos'] });
    },
    onError: (err) => setError(err instanceof Error ? err.message : 'No se pudo subir el documento'),
  });

  function handleFile(file: File | undefined) {
    if (!file) return;
    if (!casoId) {
      setError('Seleccione un caso antes de subir el documento.');
      return;
    }
    uploadMutation.mutate(file);
  }

  const kpis = useMemo(() => {
    if (!documentos) return null;
    const totalBytes = documentos.reduce((a, d) => a + d.tamanoBytes, 0);
    const now = new Date();
    const esteMes = documentos.filter((d) => {
      const f = new Date(d.subidoEn);
      return f.getMonth() === now.getMonth() && f.getFullYear() === now.getFullYear();
    }).length;
    return [
      { label: 'Documentos', val: String(documentos.length) },
      { label: 'Espacio usado', val: formatBytes(totalBytes) },
      { label: 'Subidos este mes', val: String(esteMes) },
    ];
  }, [documentos]);

  const puedeSubir = hasPermission('subir_documentos');

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', gap: 16, marginBottom: 18 }}>
        {(kpis ?? [{ label: 'Documentos', val: '—' }, { label: 'Espacio usado', val: '—' }, { label: 'Subidos este mes', val: '—' }]).map((k) => (
          <div key={k.label} style={{ background: '#fff', border: '1px solid #E7E4DD', borderRadius: 14, padding: '16px 18px' }}>
            <div style={{ fontSize: 12.5, color: '#8A857C', fontWeight: 500 }}>{k.label}</div>
            <div style={{ fontFamily: "'Spectral',serif", fontSize: 28, fontWeight: 600, marginTop: 6 }}>{k.val}</div>
          </div>
        ))}
      </div>

      {puedeSubir && (
        <>
          <div style={{ marginBottom: 10, maxWidth: 360 }}>
            <select value={casoId} onChange={(e) => setCasoId(e.target.value)} style={{ width: '100%', height: 38, padding: '0 12px', border: '1px solid #E1DED6', borderRadius: 9, fontSize: 13.5, background: '#fff' }}>
              <option value="">Seleccione el caso al que vincular el documento…</option>
              {casos?.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.id} · {c.cliente}
                </option>
              ))}
            </select>
          </div>

          <div
            onClick={() => fileRef.current?.click()}
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              handleFile(e.dataTransfer.files?.[0]);
            }}
            className="hover-accent-border"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 13,
              padding: '16px var(--card-pad)',
              border: `1.5px dashed ${dragOver ? 'var(--ac)' : '#D6D2C9'}`,
              borderRadius: 14,
              background: dragOver ? '#FAF9F6' : '#fff',
              marginBottom: 10,
              cursor: 'pointer',
            }}
          >
            <div style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--acSoft)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--ac)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 16V4M7 9l5-5 5 5" />
                <path d="M4 16v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
              </svg>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 600 }}>Arrastre archivos aquí o haga clic para subir</div>
              <div style={{ fontSize: 12.5, color: '#9B978F' }}>PDF, Word, Excel o imágenes · máx. 25 MB · se vincula a un caso y queda auditado</div>
            </div>
            <input ref={fileRef} type="file" style={{ display: 'none' }} onChange={(e) => { handleFile(e.target.files?.[0]); e.target.value = ''; }} />
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                fileRef.current?.click();
              }}
              disabled={uploadMutation.isPending}
              className="hover-brighten"
              style={{ height: 38, padding: '0 15px', borderRadius: 9, background: 'var(--ac)', color: '#fff', fontSize: 13, fontWeight: 600, flexShrink: 0 }}
            >
              {uploadMutation.isPending ? 'Subiendo…' : 'Subir documento'}
            </button>
          </div>
          {error && <div style={{ marginBottom: 18, fontSize: 13, color: '#A23A2E' }}>{error}</div>}
        </>
      )}

      <Card noPad>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 780 }}>
            <thead>
              <tr style={{ textAlign: 'left', color: '#8A857C', fontSize: 11.5, fontWeight: 600, letterSpacing: 0.4, textTransform: 'uppercase' }}>
                <th style={{ padding: '12px var(--card-pad)' }}>Documento</th>
                <th style={{ padding: '12px 10px' }}>Caso</th>
                <th style={{ padding: '12px 10px' }}>Cliente</th>
                <th style={{ padding: '12px 10px' }}>Tamaño</th>
                <th style={{ padding: '12px 10px' }}>Fecha</th>
                <th style={{ padding: '12px var(--card-pad)' }}>Subido por</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                <tr>
                  <td colSpan={6} style={{ padding: 20, textAlign: 'center', color: '#9B978F', fontSize: 13 }}>
                    Cargando…
                  </td>
                </tr>
              )}
              {!isLoading && documentos?.length === 0 && (
                <tr>
                  <td colSpan={6} style={{ padding: 20, textAlign: 'center', color: '#9B978F', fontSize: 13 }}>
                    Sin documentos cargados aún.
                  </td>
                </tr>
              )}
              {documentos?.map((d) => {
                const x = documentoExtColor(d.extension);
                return (
                  <tr key={d.id} className="hover-row" style={{ borderTop: '1px solid #F0EEE9' }}>
                    <td style={{ padding: 'var(--row-pad)' }}>
                      <a href={`/api/documentos/${d.id}/descargar`} style={{ display: 'flex', alignItems: 'center', gap: 11, color: 'inherit' }}>
                        <div style={{ width: 34, height: 34, borderRadius: 8, background: x.bg, color: x.fg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, flexShrink: 0 }}>
                          {d.extension}
                        </div>
                        <div style={{ fontSize: 13.5, fontWeight: 600 }}>{d.nombre}</div>
                      </a>
                    </td>
                    <td className="tabular-nums" style={{ padding: 'var(--row-pad)', fontSize: 13, fontWeight: 600, color: 'var(--ac)' }}>
                      {d.caso}
                    </td>
                    <td style={{ padding: 'var(--row-pad)', fontSize: 13, color: '#57544E' }}>{d.cliente}</td>
                    <td style={{ padding: 'var(--row-pad)', fontSize: 13, color: '#57544E' }}>{formatBytes(d.tamanoBytes)}</td>
                    <td style={{ padding: 'var(--row-pad)', fontSize: 13, color: '#57544E' }}>{formatDateShort(d.subidoEn)}</td>
                    <td style={{ padding: 'var(--row-pad)' }}>
                      <Avatar initials={d.subidoPor.ini} bg={d.subidoPor.color} size={28} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
