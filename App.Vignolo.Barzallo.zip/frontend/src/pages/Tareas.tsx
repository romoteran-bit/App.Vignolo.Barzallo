import { useState, type CSSProperties, type ReactNode } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../lib/api';
import type { Abogado, CasoListItem, Prioridad, Tarea } from '../types/api';
import { usePageHeader } from '../context/PageHeaderContext';
import { useAuth } from '../context/AuthContext';
import { Card } from '../components/ui/Card';
import { prioridadColor } from '../theme/tokens';
import { formatDateShort } from '../lib/format';

const PRIORIDAD_LABEL: Record<string, string> = { ALTA: 'Alta', MEDIA: 'Media', BAJA: 'Baja' };
const ESTADOS: { estado: Tarea['estado']; label: string; dot: string }[] = [
  { estado: 'PENDIENTE', label: 'Pendiente', dot: '#8A6218' },
  { estado: 'EN_PROGRESO', label: 'En progreso', dot: '#3A4B7A' },
  { estado: 'COMPLETADA', label: 'Completada', dot: '#2F5D50' },
];

function venceLabel(iso: string): string {
  const d = new Date(iso);
  const today = new Date();
  const sameDay = d.toDateString() === today.toDateString();
  if (sameDay) return 'Hoy';
  return formatDateShort(iso);
}

export function TareasPage() {
  const { hasPermission } = useAuth();
  const [showNew, setShowNew] = useState(false);
  const queryClient = useQueryClient();

  const { data: tareas } = useQuery({ queryKey: ['tareas'], queryFn: () => api.get<Tarea[]>('/api/tareas') });

  usePageHeader({
    title: 'Tareas',
    subtitle: tareas ? `${tareas.filter((t) => t.estado !== 'COMPLETADA').length} pendientes` : '',
    primaryLabel: hasPermission('crear_tareas') ? 'Nueva tarea' : undefined,
    onPrimary: () => setShowNew((v) => !v),
  });

  const toggleMutation = useMutation({
    mutationFn: (id: string) => api.patch(`/api/tareas/${id}/alternar`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['tareas'] }),
  });

  const columnas = ESTADOS.map((e) => ({
    ...e,
    items: (tareas ?? []).filter((t) => t.estado === e.estado),
  }));

  return (
    <div>
      {showNew && hasPermission('crear_tareas') && (
        <NuevaTareaForm
          onDone={() => {
            setShowNew(false);
            queryClient.invalidateQueries({ queryKey: ['tareas'] });
          }}
          onCancel={() => setShowNew(false)}
        />
      )}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))', gap: 16, alignItems: 'start' }}>
        {columnas.map((col) => (
          <div key={col.estado} style={{ background: '#F1EFEA', borderRadius: 14, padding: 6 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '11px 12px 9px' }}>
              <span style={{ width: 9, height: 9, borderRadius: '50%', background: col.dot }} />
              <span style={{ fontSize: 13.5, fontWeight: 600 }}>{col.label}</span>
              <span style={{ fontSize: 12, color: '#9B978F', background: '#fff', borderRadius: 20, padding: '1px 8px', fontWeight: 600 }}>{col.items.length}</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: '0 4px 4px' }}>
              {col.items.length === 0 && <div style={{ fontSize: 12.5, color: '#9B978F', padding: '10px 8px' }}>Sin tareas.</div>}
              {col.items.map((t) => {
                const pr = prioridadColor(t.prioridad);
                const done = t.estado === 'COMPLETADA';
                const venceHoyNoCompleta = venceLabel(t.vence) === 'Hoy' && !done;
                return (
                  <div key={t.id} style={{ background: '#fff', border: '1px solid #E7E4DD', borderRadius: 11, padding: '12px 13px' }}>
                    <div style={{ display: 'flex', gap: 10 }}>
                      <button
                        onClick={() => toggleMutation.mutate(t.id)}
                        aria-label={`Alternar tarea: ${t.titulo}`}
                        style={{
                          width: 19,
                          height: 19,
                          borderRadius: 6,
                          border: `1.8px solid ${done ? 'var(--ac)' : '#C4C0B7'}`,
                          background: done ? 'var(--ac)' : 'transparent',
                          flexShrink: 0,
                          marginTop: 1,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        {done && (
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M5 12l4.5 4.5L19 7" />
                          </svg>
                        )}
                      </button>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 13.5, fontWeight: 500, lineHeight: 1.4, color: done ? '#9B978F' : '#1C1B18', textDecoration: done ? 'line-through' : 'none' }}>
                          {t.titulo}
                        </div>
                        <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 7, marginTop: 9 }}>
                          <span style={{ fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 6, background: pr.bg, color: pr.fg }}>
                            {PRIORIDAD_LABEL[t.prioridad] ?? t.prioridad}
                          </span>
                          <span style={{ fontSize: 11.5, color: '#9B978F' }}>{t.caso}</span>
                          <span style={{ marginLeft: 'auto', fontSize: 11.5, fontWeight: 600, color: venceHoyNoCompleta ? '#A23A2E' : '#9B978F' }}>
                            {venceLabel(t.vence)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function NuevaTareaForm({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const { data: casos } = useQuery({ queryKey: ['casos'], queryFn: () => api.get<CasoListItem[]>('/api/casos') });
  const { data: abogados } = useQuery({ queryKey: ['abogados'], queryFn: () => api.get<Abogado[]>('/api/abogados') });
  const [form, setForm] = useState({ titulo: '', casoId: '', responsableId: '', prioridad: 'MEDIA' as Prioridad, vence: '' });
  const [error, setError] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: () =>
      api.post('/api/tareas', {
        titulo: form.titulo,
        casoId: form.casoId || undefined,
        responsableId: form.responsableId || undefined,
        prioridad: form.prioridad,
        vence: form.vence ? new Date(form.vence).toISOString() : undefined,
      }),
    onSuccess: onDone,
    onError: (err) => setError(err instanceof Error ? err.message : 'No se pudo crear la tarea'),
  });

  return (
    <Card style={{ marginBottom: 16 }}>
      <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Nueva tarea</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 14, marginBottom: 14 }}>
        <Field label="Título">
          <input value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })} style={inputStyle} />
        </Field>
        <Field label="Caso (opcional)">
          <select value={form.casoId} onChange={(e) => setForm({ ...form, casoId: e.target.value })} style={inputStyle}>
            <option value="">—</option>
            {casos?.map((c) => (
              <option key={c.id} value={c.id}>
                {c.id} · {c.cliente}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Responsable">
          <select value={form.responsableId} onChange={(e) => setForm({ ...form, responsableId: e.target.value })} style={inputStyle}>
            <option value="">—</option>
            {abogados?.map((a) => (
              <option key={a.id} value={a.id}>
                {a.nombre}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 14, marginBottom: 18 }}>
        <Field label="Prioridad">
          <select value={form.prioridad} onChange={(e) => setForm({ ...form, prioridad: e.target.value as Prioridad })} style={inputStyle}>
            {(['ALTA', 'MEDIA', 'BAJA'] as Prioridad[]).map((p) => (
              <option key={p} value={p}>
                {PRIORIDAD_LABEL[p]}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Vence">
          <input type="date" value={form.vence} onChange={(e) => setForm({ ...form, vence: e.target.value })} style={inputStyle} />
        </Field>
      </div>
      {error && <div style={{ marginBottom: 14, fontSize: 13, color: '#A23A2E' }}>{error}</div>}
      <div style={{ display: 'flex', gap: 10 }}>
        <button
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending || !form.titulo || !form.vence}
          className="hover-brighten"
          style={{ height: 40, padding: '0 18px', borderRadius: 9, background: 'var(--ac)', color: '#fff', fontSize: 13.5, fontWeight: 600, opacity: mutation.isPending ? 0.7 : 1 }}
        >
          Crear tarea
        </button>
        <button onClick={onCancel} className="hover-surface" style={{ height: 40, padding: '0 16px', borderRadius: 9, background: '#F3F2EE', color: '#57544E', fontSize: 13.5, fontWeight: 600 }}>
          Cancelar
        </button>
      </div>
    </Card>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', marginBottom: 6 }}>{label}</div>
      {children}
    </div>
  );
}

const inputStyle: CSSProperties = {
  width: '100%',
  height: 40,
  padding: '0 12px',
  border: '1px solid #E1DED6',
  borderRadius: 9,
  fontSize: 14,
  outline: 'none',
  background: '#fff',
};
