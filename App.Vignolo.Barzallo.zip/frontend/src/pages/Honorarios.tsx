import { useMemo, useState, type CSSProperties, type ReactNode } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../lib/api';
import type { CasoListItem, ClienteListItem, Factura } from '../types/api';
import { usePageHeader } from '../context/PageHeaderContext';
import { useAuth } from '../context/AuthContext';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { formatDateShort, formatMoney } from '../lib/format';
import { facturaEstadoColor } from '../theme/tokens';

const ESTADO_LABEL: Record<string, string> = { PAGADA: 'Pagada', PENDIENTE: 'Pendiente', VENCIDA: 'Vencida' };

export function HonorariosPage() {
  const { hasPermission } = useAuth();
  const [showNew, setShowNew] = useState(false);
  const queryClient = useQueryClient();

  const { data: facturas, isLoading } = useQuery({ queryKey: ['facturas'], queryFn: () => api.get<Factura[]>('/api/facturas') });

  usePageHeader({
    title: 'Honorarios',
    subtitle: 'Facturación y cobros',
    primaryLabel: hasPermission('ver_honorarios') ? 'Nueva factura' : undefined,
    onPrimary: () => setShowNew((v) => !v),
  });

  const kpis = useMemo(() => {
    const list = facturas ?? [];
    const sum = (pred: (f: Factura) => boolean) => list.filter(pred).reduce((a, f) => a + f.monto, 0);
    return [
      { label: `Facturado (${new Date().getFullYear()})`, val: formatMoney(sum(() => true)), sub: `${list.length} comprobantes`, color: '#57544E' },
      { label: 'Cobrado', val: formatMoney(sum((f) => f.estado === 'PAGADA')), sub: 'al día', color: '#2F5D50' },
      { label: 'Por cobrar', val: formatMoney(sum((f) => f.estado === 'PENDIENTE')), sub: 'pendiente', color: '#8A6218' },
      { label: 'Vencido', val: formatMoney(sum((f) => f.estado === 'VENCIDA')), sub: 'requiere gestión', color: '#A23A2E' },
    ];
  }, [facturas]);

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: 16, marginBottom: 18 }}>
        {kpis.map((k) => (
          <div key={k.label} style={{ background: '#fff', border: '1px solid #E7E4DD', borderRadius: 14, padding: '18px 18px 16px' }}>
            <div style={{ fontSize: 12.5, color: '#8A857C', fontWeight: 500 }}>{k.label}</div>
            <div className="tabular-nums" style={{ fontFamily: "'Spectral',serif", fontSize: 30, fontWeight: 600, lineHeight: 1.05, margin: '8px 0 4px', color: k.color }}>
              {k.val}
            </div>
            <div style={{ fontSize: 12, color: '#8A857C', fontWeight: 500 }}>{k.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 10, padding: '11px 14px', borderRadius: 10, background: 'var(--acSoft)', marginBottom: 18 }}>
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="var(--ac)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: 1 }}>
          <circle cx="12" cy="12" r="9" />
          <path d="M12 8h0M11 12h1v4h1" />
        </svg>
        <div style={{ fontSize: 13, color: '#33312C', lineHeight: 1.5 }}>
          Cada factura genera un <strong style={{ fontWeight: 600 }}>comprobante electrónico</strong> firmado y autorizado por el SRI (RIDE + XML). Los secuenciales son
          correlativos por punto de emisión.
        </div>
      </div>

      {showNew && (
        <NuevaFacturaForm
          onDone={() => {
            setShowNew(false);
            queryClient.invalidateQueries({ queryKey: ['facturas'] });
          }}
          onCancel={() => setShowNew(false)}
        />
      )}

      <Card noPad>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 900 }}>
            <thead>
              <tr style={{ textAlign: 'left', color: '#8A857C', fontSize: 11.5, fontWeight: 600, letterSpacing: 0.4, textTransform: 'uppercase' }}>
                <th style={{ padding: '12px var(--card-pad)' }}>Comprobante</th>
                <th style={{ padding: '12px 10px' }}>Cliente</th>
                <th style={{ padding: '12px 10px' }}>Concepto</th>
                <th style={{ padding: '12px 10px', textAlign: 'right' }}>Monto</th>
                <th style={{ padding: '12px 10px' }}>Vence</th>
                <th style={{ padding: '12px 10px' }}>SRI</th>
                <th style={{ padding: '12px var(--card-pad)' }}>Estado</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                <tr>
                  <td colSpan={7} style={{ padding: 20, textAlign: 'center', color: '#9B978F', fontSize: 13 }}>
                    Cargando…
                  </td>
                </tr>
              )}
              {facturas?.map((f) => {
                const est = facturaEstadoColor(f.estado);
                return (
                  <tr key={f.id} className="hover-row" style={{ borderTop: '1px solid #F0EEE9' }}>
                    <td style={{ padding: 'var(--row-pad)' }}>
                      <div className="tabular-nums" style={{ fontSize: 12.5, fontWeight: 600 }}>
                        {f.secuencial}
                      </div>
                      <div className="tabular-nums" style={{ fontSize: 11.5, color: '#9B978F' }}>
                        {f.caso}
                      </div>
                    </td>
                    <td style={{ padding: 'var(--row-pad)', fontSize: 13, fontWeight: 500 }}>{f.cliente}</td>
                    <td style={{ padding: 'var(--row-pad)', fontSize: 12.5, color: '#57544E', maxWidth: 230 }}>{f.concepto}</td>
                    <td className="tabular-nums" style={{ padding: 'var(--row-pad)', fontSize: 13.5, fontWeight: 700, textAlign: 'right' }}>
                      {formatMoney(f.monto)}
                    </td>
                    <td style={{ padding: 'var(--row-pad)', fontSize: 13, color: '#57544E' }}>{formatDateShort(f.vence)}</td>
                    <td style={{ padding: 'var(--row-pad)' }}>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, fontWeight: 600, color: '#2F5D50' }}>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M5 12l4.5 4.5L19 7" />
                        </svg>
                        {f.sriAutorizado ? 'Autorizado' : 'Pendiente'}
                      </span>
                    </td>
                    <td style={{ padding: 'var(--row-pad)' }}>
                      <Badge bg={est.bg} fg={est.fg}>
                        {ESTADO_LABEL[f.estado] ?? f.estado}
                      </Badge>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function NuevaFacturaForm({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const { data: clientes } = useQuery({ queryKey: ['clientes', 'Todos'], queryFn: () => api.get<ClienteListItem[]>('/api/clientes?estado=Todos') });
  const { data: casos } = useQuery({ queryKey: ['casos'], queryFn: () => api.get<CasoListItem[]>('/api/casos') });
  const [form, setForm] = useState({ clienteId: '', casoId: '', concepto: '', monto: '', vence: '' });
  const [error, setError] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: () => {
      const emision = new Date();
      const vence = form.vence ? new Date(form.vence) : new Date(emision.getTime() + 15 * 86400000);
      return api.post('/api/facturas', {
        clienteId: form.clienteId,
        casoId: form.casoId || undefined,
        concepto: form.concepto,
        monto: Number(form.monto),
        emision: emision.toISOString(),
        vence: vence.toISOString(),
      });
    },
    onSuccess: onDone,
    onError: (err) => setError(err instanceof Error ? err.message : 'No se pudo emitir la factura'),
  });

  return (
    <Card style={{ marginBottom: 16 }}>
      <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Nueva factura</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 14, marginBottom: 14 }}>
        <Field label="Cliente">
          <select value={form.clienteId} onChange={(e) => setForm({ ...form, clienteId: e.target.value })} style={inputStyle}>
            <option value="">Seleccione…</option>
            {clientes?.map((c) => (
              <option key={c.id} value={c.id}>
                {c.nombre}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Caso (opcional)">
          <select value={form.casoId} onChange={(e) => setForm({ ...form, casoId: e.target.value })} style={inputStyle}>
            <option value="">—</option>
            {casos?.map((c) => (
              <option key={c.id} value={c.id}>
                {c.id}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 14, marginBottom: 18 }}>
        <Field label="Concepto">
          <input value={form.concepto} onChange={(e) => setForm({ ...form, concepto: e.target.value })} style={inputStyle} />
        </Field>
        <Field label="Monto (USD)">
          <input type="number" min="0" step="0.01" value={form.monto} onChange={(e) => setForm({ ...form, monto: e.target.value })} style={inputStyle} />
        </Field>
        <Field label="Vence">
          <input type="date" value={form.vence} onChange={(e) => setForm({ ...form, vence: e.target.value })} style={inputStyle} />
        </Field>
      </div>
      {error && <div style={{ marginBottom: 14, fontSize: 13, color: '#A23A2E' }}>{error}</div>}
      <div style={{ display: 'flex', gap: 10 }}>
        <button
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending || !form.clienteId || !form.concepto || !form.monto}
          className="hover-brighten"
          style={{ height: 40, padding: '0 18px', borderRadius: 9, background: 'var(--ac)', color: '#fff', fontSize: 13.5, fontWeight: 600, opacity: mutation.isPending ? 0.7 : 1 }}
        >
          Emitir comprobante
        </button>
        <button onClick={onCancel} className="hover-surface" style={{ height: 40, padding: '0 16px', borderRadius: 9, background: '#F3F2EE', color: '#57544E', fontSize: 13.5, fontWeight: 600 }}>
          Cancelar
        </button>
      </div>
    </Card>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', marginBottom: 6 }}>{label}</div>
      {children}
    </div>
  );
}

const inputStyle: CSSProperties = {
  width: '100%',
  height: 40,
  padding: '0 12px',
  border: '1px solid #E1DED6',
  borderRadius: 9,
  fontSize: 14,
  outline: 'none',
  background: '#fff',
};
