import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { api } from '../lib/api';
import type { ClienteDetalle } from '../types/api';
import { clienteEstadoColor, avatarColorFor } from '../theme/tokens';
import { clienteIniciales, formatDateLong } from '../lib/format';

export function ClienteDrawer({ clienteId, onClose }: { clienteId: string; onClose: () => void }) {
  const navigate = useNavigate();
  const { data } = useQuery({
    queryKey: ['cliente', clienteId],
    queryFn: () => api.get<ClienteDetalle>(`/api/clientes/${clienteId}`),
  });

  if (!data) return null;
  const est = clienteEstadoColor(data.estado);
  const av = avatarColorFor(data.nombre);

  return (
    <div
      onClick={onClose}
      style={{ position: 'fixed', inset: 0, background: 'rgba(28,27,24,0.32)', zIndex: 40, display: 'flex', justifyContent: 'flex-end' }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{ width: 'min(420px,92vw)', height: '100%', background: '#F6F5F2', boxShadow: '-8px 0 30px rgba(0,0,0,.12)', overflowY: 'auto' }}
      >
        <div style={{ background: '#fff', padding: '22px var(--card-pad) 18px', borderBottom: '1px solid #E7E4DD' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 13, minWidth: 0 }}>
              <div
                style={{
                  width: 46,
                  height: 46,
                  borderRadius: 12,
                  background: av.bg,
                  color: av.fg,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 16,
                  fontWeight: 600,
                  flexShrink: 0,
                }}
              >
                {clienteIniciales(data.nombre)}
              </div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontFamily: "'Spectral',serif", fontSize: 19, fontWeight: 600, lineHeight: 1.15 }}>{data.nombre}</div>
                <div style={{ fontSize: 12.5, color: '#8A857C' }}>{data.tipo}</div>
              </div>
            </div>
            <button
              onClick={onClose}
              aria-label="Cerrar"
              className="hover-surface"
              style={{ width: 32, height: 32, borderRadius: 8, background: '#F3F2EE', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#57544E" strokeWidth="2" strokeLinecap="round">
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
          </div>
          <div style={{ marginTop: 14 }}>
            <span style={{ fontSize: 12, fontWeight: 600, padding: '4px 11px', borderRadius: 20, background: est.bg, color: est.fg }}>
              {estadoLabel(data.estado)}
            </span>
          </div>
        </div>

        <div style={{ padding: '18px var(--card-pad)', display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ background: '#fff', border: '1px solid #E7E4DD', borderRadius: 12, padding: 16 }}>
            <div style={{ fontSize: 11.5, fontWeight: 600, color: '#8A857C', letterSpacing: 0.3, marginBottom: 12 }}>CONTACTO</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
              <Row label="Identificación" value={data.identificacion} tabular />
              <Row label="Teléfono" value={data.telefono} />
              <Row label="Ciudad" value={data.ciudad} />
              <Row label="Creado" value={formatDateLong(data.creadoEn)} />
            </div>
          </div>

          <div style={{ background: '#fff', border: '1px solid #E7E4DD', borderRadius: 12, padding: 16 }}>
            <div style={{ fontSize: 11.5, fontWeight: 600, color: '#8A857C', letterSpacing: 0.3, marginBottom: 12 }}>CASOS ASOCIADOS</div>
            {data.casos.length === 0 ? (
              <div style={{ fontSize: 13, color: '#9B978F', textAlign: 'center', padding: '14px 0' }}>Sin casos registrados aún.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
                {data.casos.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      onClose();
                      navigate(`/casos/${c.id}`);
                    }}
                    className="hover-accent-border"
                    style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '10px 11px', borderRadius: 9, border: '1px solid #EDEBE5', textAlign: 'left', width: '100%' }}
                  >
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ac)' }}>{c.id}</div>
                      <div style={{ fontSize: 12, color: '#57544E' }}>
                        {c.materia} · {c.etapa}
                      </div>
                    </div>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#C4C0B7" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M9 6l6 6-6 6" />
                    </svg>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, tabular }: { label: string; value: string; tabular?: boolean }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
      <span style={{ fontSize: 12.5, color: '#9B978F' }}>{label}</span>
      <span className={tabular ? 'tabular-nums' : ''} style={{ fontSize: 13, fontWeight: 500 }}>
        {value}
      </span>
    </div>
  );
}

function estadoLabel(e: string): string {
  const map: Record<string, string> = { ACTIVO: 'Activo', VIP: 'VIP', POTENCIAL: 'Potencial', INACTIVO: 'Inactivo' };
  return map[e] ?? e;
}
