export function KpiCard({
  label,
  value,
  delta,
  deltaColor,
  valueColor,
  size = 34,
}: {
  label: string;
  value: string;
  delta?: string;
  deltaColor?: string;
  valueColor?: string;
  size?: number;
}) {
  return (
    <div style={{ background: '#fff', border: '1px solid #E7E4DD', borderRadius: 14, padding: '18px 18px 16px' }}>
      <div style={{ fontSize: 12.5, color: '#8A857C', fontWeight: 500 }}>{label}</div>
      <div
        style={{
          fontFamily: "'Spectral',serif",
          fontSize: size,
          fontWeight: 600,
          lineHeight: 1.05,
          margin: '8px 0 4px',
          color: valueColor ?? '#1C1B18',
          fontVariantNumeric: 'tabular-nums',
        }}
      >
        {value}
      </div>
      {delta && <div style={{ fontSize: 12, color: deltaColor ?? '#8A857C', fontWeight: 500 }}>{delta}</div>}
    </div>
  );
}
