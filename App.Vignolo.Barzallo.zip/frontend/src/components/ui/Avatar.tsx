import type { CSSProperties } from 'react';

interface AvatarProps {
  initials: string;
  bg: string;
  fg?: string;
  size?: number;
  square?: boolean;
  style?: CSSProperties;
}

export function Avatar({ initials, bg, fg = '#fff', size = 32, square = false, style }: AvatarProps) {
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: square ? size >= 40 ? 12 : 9 : '50%',
        background: bg,
        color: fg,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: size <= 28 ? 11 : size <= 34 ? 12 : 13,
        fontWeight: 600,
        flexShrink: 0,
        ...style,
      }}
    >
      {initials}
    </div>
  );
}
