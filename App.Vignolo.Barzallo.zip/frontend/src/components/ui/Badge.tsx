import type { CSSProperties, ReactNode } from 'react';

interface BadgeProps {
  bg: string;
  fg: string;
  children: ReactNode;
  square?: boolean;
  style?: CSSProperties;
}

export function Badge({ bg, fg, children, square = false, style }: BadgeProps) {
  return (
    <span
      style={{
        fontSize: 12,
        fontWeight: 600,
        padding: '3px 10px',
        borderRadius: square ? 7 : 20,
        background: bg,
        color: fg,
        whiteSpace: 'nowrap',
        ...style,
      }}
    >
      {children}
    </span>
  );
}
