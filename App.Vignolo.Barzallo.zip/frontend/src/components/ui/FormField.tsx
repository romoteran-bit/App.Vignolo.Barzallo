import type { CSSProperties, ReactNode } from 'react';

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <div style={{ fontSize: 12.5, fontWeight: 600, color: '#8A857C', marginBottom: 6 }}>{label}</div>
      {children}
    </div>
  );
}

export const inputStyle: CSSProperties = {
  width: '100%',
  height: 40,
  padding: '0 12px',
  border: '1px solid #E1DED6',
  borderRadius: 9,
  fontSize: 14,
  outline: 'none',
  background: '#fff',
};
