import type { CSSProperties, ReactNode } from 'react';

export function Card({ children, style, noPad = false }: { children: ReactNode; style?: CSSProperties; noPad?: boolean }) {
  return (
    <div
      style={{
        background: '#fff',
        border: '1px solid #E7E4DD',
        borderRadius: 14,
        overflow: 'hidden',
        ...(noPad ? {} : { padding: 'var(--card-pad, 20px)' }),
        ...style,
      }}
    >
      {children}
    </div>
  );
}
