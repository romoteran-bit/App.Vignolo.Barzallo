import type { ReactNode } from 'react';
import { useAuth } from '../context/AuthContext';

export function RequirePermission({ anyOf, children }: { anyOf: string[]; children: ReactNode }) {
  const { hasAnyPermission } = useAuth();
  if (!hasAnyPermission(...anyOf)) {
    return (
      <div style={{ padding: '48px 0', textAlign: 'center', color: '#8A857C' }}>
        <div style={{ fontFamily: "'Spectral',serif", fontSize: 18, fontWeight: 600, color: '#1C1B18', marginBottom: 6 }}>
          No tiene permisos para ver esta sección
        </div>
        <div style={{ fontSize: 13.5 }}>Consulte con un administrador si cree que esto es un error.</div>
      </div>
    );
  }
  return <>{children}</>;
}
