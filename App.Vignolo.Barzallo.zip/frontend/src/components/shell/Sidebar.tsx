import { NavLink } from 'react-router-dom';
import type { ReactNode } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useAppearance } from '../../context/AppearanceContext';

interface NavItemDef {
  to: string;
  label: string;
  icon: ReactNode;
  visible: boolean;
  end?: boolean;
}

const iconProps = { width: 19, height: 19, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };

function IconInicio() {
  return <svg {...iconProps}><path d="M3 10.5 12 4l9 6.5" /><path d="M5 9.5V20h14V9.5" /></svg>;
}
function IconClientes() {
  return <svg {...iconProps}><circle cx="9" cy="8" r="3" /><path d="M3.5 20c0-3 2.5-5 5.5-5s5.5 2 5.5 5" /><path d="M16 5.2a3 3 0 0 1 0 5.6" /><path d="M18 20c0-2.2-1-3.8-2.5-4.6" /></svg>;
}
function IconCasos() {
  return <svg {...iconProps}><path d="M3 8a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /></svg>;
}
function IconAgenda() {
  return <svg {...iconProps}><rect x="3" y="5" width="18" height="16" rx="2.5" /><path d="M3 9.5h18M8 3v4M16 3v4" /></svg>;
}
function IconTareas() {
  return <svg {...iconProps}><rect x="4" y="4" width="16" height="16" rx="3.5" /><path d="M8 12l2.8 2.8L16 9" /></svg>;
}
function IconDocumentos() {
  return <svg {...iconProps}><path d="M13 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9z" /><path d="M13 3v6h6" /></svg>;
}
function IconHonorarios() {
  return <svg {...iconProps}><rect x="2.5" y="6" width="19" height="12" rx="2.5" /><circle cx="12" cy="12" r="2.6" /><path d="M6 12h0M18 12h0" /></svg>;
}
function IconConfig() {
  return <svg {...iconProps}><path d="M4 7h9M17 7h3M4 17h3M11 17h9" /><circle cx="15" cy="7" r="2.2" /><circle cx="9" cy="17" r="2.2" /></svg>;
}
function IconLogout() {
  return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3" /><path d="M10 16l-4-4 4-4M6 12h11" /></svg>;
}

export function Sidebar() {
  const { user, logout } = useAuth();
  const { sidebarTheme } = useAppearance();
  const dark = sidebarTheme === 'Oscuro';

  const hasAny = (...claves: string[]) => claves.some((c) => user?.permisos.includes(c));

  const principal: NavItemDef[] = [
    { to: '/', end: true, label: 'Inicio', icon: <IconInicio />, visible: true },
    { to: '/clientes', label: 'Clientes', icon: <IconClientes />, visible: true },
    { to: '/casos', label: 'Casos', icon: <IconCasos />, visible: hasAny('ver_todos_casos', 'ver_casos_asignados') },
    { to: '/agenda', label: 'Agenda', icon: <IconAgenda />, visible: hasAny('ver_todos_casos', 'ver_casos_asignados') },
    { to: '/tareas', label: 'Tareas', icon: <IconTareas />, visible: hasAny('ver_todos_casos', 'ver_casos_asignados', 'crear_tareas') },
    { to: '/documentos', label: 'Documentos', icon: <IconDocumentos />, visible: true },
    { to: '/honorarios', label: 'Honorarios', icon: <IconHonorarios />, visible: hasAny('ver_honorarios') },
  ];
  const sistema: NavItemDef[] = [
    { to: '/configuracion', label: 'Configuración', icon: <IconConfig />, visible: hasAny('administrar_usuarios', 'configurar_sistema') },
  ];

  return (
    <aside
      style={{
        width: 252,
        flexShrink: 0,
        background: 'var(--side-bg)',
        color: 'var(--side-fg)',
        display: 'flex',
        flexDirection: 'column',
        padding: '18px 14px',
        borderRight: '1px solid rgba(0,0,0,0.06)',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '6px 8px 20px' }}>
        <div
          style={{
            width: 38,
            height: 38,
            borderRadius: 10,
            background: dark ? 'rgba(255,255,255,0.10)' : 'var(--acSoft)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
          }}
        >
          <img
            src={dark ? '/assets/logo-vb-white.png' : '/assets/logo-vb.png'}
            alt="Vignolo Barzallo"
            style={{ width: 27, height: 27, objectFit: 'contain' }}
          />
        </div>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontFamily: "'Spectral',serif", fontWeight: 600, fontSize: 16, lineHeight: 1.1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            Vignolo Barzallo
          </div>
          <div style={{ fontSize: 11, color: 'var(--side-fg-mut)', letterSpacing: 0.3 }}>Estudio Jurídico</div>
        </div>
      </div>

      <div style={{ fontSize: 10.5, fontWeight: 600, letterSpacing: 0.9, color: 'var(--side-fg-mut)', padding: '4px 10px 8px' }}>
        PRINCIPAL
      </div>
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {principal.filter((n) => n.visible).map((n) => (
          <SidebarLink key={n.to} {...n} />
        ))}
      </nav>

      {sistema.some((n) => n.visible) && (
        <>
          <div style={{ fontSize: 10.5, fontWeight: 600, letterSpacing: 0.9, color: 'var(--side-fg-mut)', padding: '20px 10px 8px' }}>
            SISTEMA
          </div>
          <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {sistema.filter((n) => n.visible).map((n) => (
              <SidebarLink key={n.to} {...n} />
            ))}
          </nav>
        </>
      )}

      <div style={{ marginTop: 'auto', display: 'flex', alignItems: 'center', gap: 11, padding: 10, borderRadius: 11, background: 'var(--side-hover)' }}>
        <div
          style={{
            width: 34,
            height: 34,
            borderRadius: '50%',
            background: 'var(--ac)',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontWeight: 600,
            fontSize: 13,
            flexShrink: 0,
          }}
        >
          {initialsOf(user?.nombre ?? '')}
        </div>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {user?.nombre}
          </div>
          <div style={{ fontSize: 11, color: 'var(--side-fg-mut)' }}>{user?.rol}</div>
        </div>
        <button
          onClick={() => logout()}
          title="Cerrar sesión"
          className="hover-side-item"
          style={{ width: 30, height: 30, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--side-fg-mut)', flexShrink: 0 }}
        >
          <IconLogout />
        </button>
      </div>
    </aside>
  );
}

function SidebarLink({ to, label, icon, end }: NavItemDef) {
  return (
    <NavLink
      to={to}
      end={end}
      className="hover-side-item"
      style={({ isActive }) => ({
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '9px 11px',
        borderRadius: 9,
        fontSize: 14,
        fontWeight: 500,
        textAlign: 'left',
        color: isActive ? 'var(--nav-active-fg, var(--side-fg))' : 'var(--side-fg-mut)',
        background: isActive ? 'var(--nav-active-bg)' : 'transparent',
      })}
    >
      {icon}
      {label}
    </NavLink>
  );
}

function initialsOf(nombre: string): string {
  return nombre
    .replace(/[^A-Za-zÁÉÍÓÚÑáéíóúñ. ]/g, '')
    .split(/\s+/)
    .filter((w) => w && !/^(abg|dr|dra|lic|ing)\.?$/i.test(w))
    .slice(0, 2)
    .map((w) => w.replace('.', '')[0]?.toUpperCase() ?? '')
    .join('');
}
