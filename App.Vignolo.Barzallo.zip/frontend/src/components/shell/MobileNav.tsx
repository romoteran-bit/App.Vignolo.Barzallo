import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const iconProps = { width: 21, height: 21, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };

export function MobileNav() {
  const { user } = useAuth();
  const hasAny = (...claves: string[]) => claves.some((c) => user?.permisos.includes(c));

  const items = [
    {
      to: '/',
      end: true,
      label: 'Inicio',
      visible: true,
      icon: (
        <svg {...iconProps}>
          <path d="M3 10.5 12 4l9 6.5" />
          <path d="M5 9.5V20h14V9.5" />
        </svg>
      ),
    },
    {
      to: '/clientes',
      label: 'Clientes',
      visible: true,
      icon: (
        <svg {...iconProps}>
          <circle cx="9" cy="8" r="3" />
          <path d="M3.5 20c0-3 2.5-5 5.5-5s5.5 2 5.5 5" />
        </svg>
      ),
    },
    {
      to: '/casos',
      label: 'Casos',
      visible: hasAny('ver_todos_casos', 'ver_casos_asignados'),
      icon: (
        <svg {...iconProps}>
          <path d="M3 8a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
        </svg>
      ),
    },
    {
      to: '/agenda',
      label: 'Agenda',
      visible: hasAny('ver_todos_casos', 'ver_casos_asignados'),
      icon: (
        <svg {...iconProps}>
          <rect x="3" y="5" width="18" height="16" rx="2.5" />
          <path d="M3 9.5h18M8 3v4M16 3v4" />
        </svg>
      ),
    },
    {
      to: '/tareas',
      label: 'Tareas',
      visible: hasAny('ver_todos_casos', 'ver_casos_asignados', 'crear_tareas'),
      icon: (
        <svg {...iconProps}>
          <rect x="4" y="4" width="16" height="16" rx="3.5" />
          <path d="M8 12l2.8 2.8L16 9" />
        </svg>
      ),
    },
  ];

  return (
    <nav
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        height: 62,
        background: '#fff',
        borderTop: '1px solid #E7E4DD',
        display: 'flex',
        zIndex: 30,
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      {items.filter((i) => i.visible).map((i) => (
        <NavLink
          key={i.to}
          to={i.to}
          end={i.end}
          style={({ isActive }) => ({
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 3,
            color: isActive ? 'var(--ac)' : '#9B978F',
            fontSize: 10,
            fontWeight: 600,
          })}
        >
          {i.icon}
          {i.label}
        </NavLink>
      ))}
    </nav>
  );
}
