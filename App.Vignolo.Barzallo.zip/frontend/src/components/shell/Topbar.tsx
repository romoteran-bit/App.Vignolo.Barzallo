import { usePageHeaderContext } from '../../context/PageHeaderContext';

export function Topbar() {
  const { title, subtitle, primaryLabel, triggerPrimary } = usePageHeaderContext();

  return (
    <header
      style={{
        height: 62,
        flexShrink: 0,
        background: '#fff',
        borderBottom: '1px solid #E7E4DD',
        display: 'flex',
        alignItems: 'center',
        gap: 16,
        padding: '0 clamp(16px,3vw,28px)',
      }}
    >
      <div style={{ minWidth: 0, flexShrink: 0 }}>
        <div
          style={{
            fontFamily: "'Spectral',serif",
            fontSize: 18,
            fontWeight: 600,
            lineHeight: 1.1,
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}
        >
          {title}
        </div>
        <div style={{ fontSize: 12, color: '#8A857C', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {subtitle}
        </div>
      </div>

      <label
        className="focus-within-accent"
        style={{
          flex: 1,
          maxWidth: 440,
          margin: '0 auto',
          display: 'flex',
          alignItems: 'center',
          gap: 9,
          height: 38,
          padding: '0 12px',
          background: '#F3F2EE',
          border: '1px solid transparent',
          borderRadius: 10,
          cursor: 'text',
        }}
      >
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#8A857C" strokeWidth="1.8" strokeLinecap="round">
          <circle cx="11" cy="11" r="7" />
          <path d="M21 21l-4-4" />
        </svg>
        <input
          placeholder="Buscar clientes, casos, documentos…"
          style={{ flex: 1, border: 'none', background: 'transparent', outline: 'none', fontSize: 13.5, color: '#1C1B18' }}
        />
        <kbd style={{ fontSize: 10.5, color: '#9B978F', background: '#fff', border: '1px solid #E1DED6', borderRadius: 5, padding: '2px 6px' }}>
          ⌘K
        </kbd>
      </label>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
        {primaryLabel && (
          <button
            onClick={triggerPrimary}
            className="hover-brighten"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 7,
              height: 38,
              padding: '0 15px',
              borderRadius: 9,
              background: 'var(--ac)',
              color: '#fff',
              fontSize: 13.5,
              fontWeight: 600,
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M12 5v14M5 12h14" />
            </svg>
            {primaryLabel}
          </button>
        )}
        <button
          className="hover-surface"
          style={{
            width: 38,
            height: 38,
            borderRadius: 9,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: '#F3F2EE',
            position: 'relative',
          }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#57544E" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
            <path d="M6 9a6 6 0 0 1 12 0c0 6 2 7 2 7H4s2-1 2-7" />
            <path d="M10 20a2 2 0 0 0 4 0" />
          </svg>
          <span style={{ position: 'absolute', top: 8, right: 9, width: 7, height: 7, borderRadius: '50%', background: '#A23A2E', border: '1.5px solid #F3F2EE' }} />
        </button>
      </div>
    </header>
  );
}
