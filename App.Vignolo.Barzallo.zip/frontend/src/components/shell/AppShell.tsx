import { Outlet } from 'react-router-dom';
import { useAppearance } from '../../context/AppearanceContext';
import { PageHeaderProvider } from '../../context/PageHeaderContext';
import { useIsNarrow } from '../../lib/useIsNarrow';
import { Sidebar } from './Sidebar';
import { Topbar } from './Topbar';
import { MobileNav } from './MobileNav';

export function AppShell() {
  const { cssVars } = useAppearance();
  const isNarrow = useIsNarrow();

  return (
    <PageHeaderProvider>
      <div
        style={{
          ...cssVars,
          display: 'flex',
          height: '100vh',
          width: '100%',
          overflow: 'hidden',
          background: '#F6F5F2',
          color: '#1C1B18',
          fontFamily: "'Hanken Grotesk',system-ui,sans-serif",
        }}
      >
        {!isNarrow && <Sidebar />}

        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          <Topbar />
          <main style={{ flex: 1, overflowY: 'auto', padding: 'clamp(16px,3vw,30px) clamp(16px,3vw,32px) 96px' }}>
            <div style={{ maxWidth: 1240, margin: '0 auto' }}>
              <Outlet />
            </div>
          </main>
        </div>

        {isNarrow && <MobileNav />}
      </div>
    </PageHeaderProvider>
  );
}
