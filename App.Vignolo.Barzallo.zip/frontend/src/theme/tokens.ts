// Design tokens ported 1:1 from the Claude Design handoff
// (project/design_handoff_vignolo_barzallo_erp/README.md § Design Tokens).
export const colors = {
  bgApp: '#F6F5F2',
  surface: '#FFFFFF',
  surfaceAlt: '#FAF9F6',
  surfaceMuted: '#F3F2EE',
  surfaceMuted2: '#F1EFEA',
  text: '#1C1B18',
  text2: '#33312C',
  text3: '#57544E',
  textMuted: '#8A857C',
  textFaint: '#9B978F',
  border: '#E7E4DD',
  border2: '#E1DED6',
  border3: '#EDEBE5',
  border4: '#F0EEE9',
  sidebarDarkBg: '#1B1A17',
  sidebarDarkFg: '#F5F4F1',
} as const;

export const ACCENTS = [
  { accent: '#2F5D50', soft: '#E7F0EB', label: 'Verde bosque' },
  { accent: '#3A4B7A', soft: '#E9ECF5', label: 'Azul' },
  { accent: '#6E3B4E', soft: '#F3E9ED', label: 'Vino' },
  { accent: '#454440', soft: '#ECEBE7', label: 'Grafito' },
] as const;

export const SEMANTIC = {
  exito: { bg: '#E7F0EB', fg: '#2F5D50' },
  advertencia: { bg: '#FCF3E1', fg: '#8A6218' },
  peligro: { bg: '#FBEAE7', fg: '#A23A2E' },
  neutro: { bg: '#EEEDE9', fg: '#75726B' },
  vip: { bg: '#1B1A17', fg: '#E7C67C' },
} as const;

export function prioridadColor(p: string): { bg: string; fg: string } {
  if (p === 'ALTA' || p === 'Alta') return SEMANTIC.peligro;
  if (p === 'MEDIA' || p === 'Media') return SEMANTIC.advertencia;
  return SEMANTIC.neutro;
}

export function clienteEstadoColor(estado: string): { bg: string; fg: string } {
  if (estado === 'ACTIVO' || estado === 'Activo') return SEMANTIC.exito;
  if (estado === 'VIP') return SEMANTIC.vip;
  if (estado === 'POTENCIAL' || estado === 'Potencial') return SEMANTIC.advertencia;
  return { bg: SEMANTIC.neutro.bg, fg: colors.textMuted };
}

export function facturaEstadoColor(estado: string): { bg: string; fg: string } {
  if (estado === 'PAGADA' || estado === 'Pagada') return SEMANTIC.exito;
  if (estado === 'PENDIENTE' || estado === 'Pendiente') return SEMANTIC.advertencia;
  if (estado === 'VENCIDA' || estado === 'Vencida') return SEMANTIC.peligro;
  return SEMANTIC.neutro;
}

export function documentoExtColor(ext: string): { bg: string; fg: string } {
  const e = ext.toUpperCase();
  if (e === 'PDF') return SEMANTIC.peligro;
  if (e === 'DOCX' || e === 'DOC') return { bg: '#E9ECF5', fg: '#3A4B7A' };
  if (e === 'XLSX' || e === 'XLS') return SEMANTIC.exito;
  return { bg: colors.border4, fg: colors.text3 };
}

const AVATAR_PALETTE = ['#2F5D50', '#3A4B7A', '#6E3B4E', '#8A6218', '#43604E'];

/** Deterministic hash-based avatar color for entities without a stored color (clients). */
export function avatarColorFor(seed: string): { bg: string; fg: string } {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) % 997;
  const c = AVATAR_PALETTE[h % AVATAR_PALETTE.length]!;
  return { bg: `${c}22`, fg: c };
}

export const radii = {
  input: 10,
  card: 14,
  pill: 20,
  tag: 7,
};
