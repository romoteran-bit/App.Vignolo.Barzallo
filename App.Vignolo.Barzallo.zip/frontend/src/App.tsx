import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { AppShell } from './components/shell/AppShell';
import { RequirePermission } from './components/RequirePermission';
import { LoginPage } from './pages/Login';
import { DashboardPage } from './pages/Dashboard';
import { ClientesPage } from './pages/Clientes';
import { CasosPage } from './pages/Casos';
import { CasoDetallePage } from './pages/CasoDetalle';
import { AgendaPage } from './pages/Agenda';
import { TareasPage } from './pages/Tareas';
import { DocumentosPage } from './pages/Documentos';
import { HonorariosPage } from './pages/Honorarios';
import { ConfiguracionPage } from './pages/Configuracion';

function FullScreenLoader() {
  return (
    <div
      style={{
        height: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#F6F5F2',
        color: '#8A857C',
        fontSize: 14,
      }}
    >
      Cargando…
    </div>
  );
}

export default function App() {
  const { user, loading } = useAuth();

  if (loading) return <FullScreenLoader />;

  if (!user) {
    return (
      <Routes>
        <Route path="*" element={<LoginPage />} />
      </Routes>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={<Navigate to="/" replace />} />
      <Route element={<AppShell />}>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/clientes" element={<ClientesPage />} />
        <Route
          path="/casos"
          element={
            <RequirePermission anyOf={['ver_todos_casos', 'ver_casos_asignados']}>
              <CasosPage />
            </RequirePermission>
          }
        />
        <Route
          path="/casos/:id"
          element={
            <RequirePermission anyOf={['ver_todos_casos', 'ver_casos_asignados']}>
              <CasoDetallePage />
            </RequirePermission>
          }
        />
        <Route
          path="/agenda"
          element={
            <RequirePermission anyOf={['ver_todos_casos', 'ver_casos_asignados']}>
              <AgendaPage />
            </RequirePermission>
          }
        />
        <Route
          path="/tareas"
          element={
            <RequirePermission anyOf={['ver_todos_casos', 'ver_casos_asignados', 'crear_tareas']}>
              <TareasPage />
            </RequirePermission>
          }
        />
        <Route path="/documentos" element={<DocumentosPage />} />
        <Route
          path="/honorarios"
          element={
            <RequirePermission anyOf={['ver_honorarios']}>
              <HonorariosPage />
            </RequirePermission>
          }
        />
        <Route
          path="/configuracion"
          element={
            <RequirePermission anyOf={['administrar_usuarios', 'configurar_sistema']}>
              <ConfiguracionPage />
            </RequirePermission>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
