import { createContext, useContext, useEffect, useMemo, useState, type CSSProperties, type ReactNode } from 'react';
import { ACCENTS } from '../theme/tokens';

export type SidebarTheme = 'Oscuro' | 'Claro';
export type Density = 'Cómoda' | 'Compacta';

interface AppearanceState {
  accentIndex: number;
  sidebarTheme: SidebarTheme;
  density: Density;
}

interface AppearanceContextValue extends AppearanceState {
  setAccentIndex: (i: number) => void;
  setSidebarTheme: (t: SidebarTheme) => void;
  setDensity: (d: Density) => void;
  cssVars: CSSProperties;
  ac: string;
  acSoft: string;
}

const STORAGE_KEY = 'vb-erp-appearance';

function loadInitial(): AppearanceState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    /* ignore malformed storage */
  }
  return { accentIndex: 0, sidebarTheme: 'Oscuro', density: 'Cómoda' };
}

const AppearanceContext = createContext<AppearanceContextValue | null>(null);

export function AppearanceProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppearanceState>(loadInitial);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const value = useMemo<AppearanceContextValue>(() => {
    const accent = ACCENTS[state.accentIndex] ?? ACCENTS[0]!;
    const dark = state.sidebarTheme === 'Oscuro';
    const dense = state.density === 'Compacta';
    const sideHover = dark ? 'rgba(255,255,255,0.06)' : '#F3F2EE';
    const cssVars: CSSProperties & Record<string, string> = {
      '--ac': accent.accent,
      '--acSoft': accent.soft,
      '--side-bg': dark ? '#1B1A17' : '#FFFFFF',
      '--side-fg': dark ? '#F5F4F1' : '#1C1B18',
      '--side-fg-mut': dark ? 'rgba(245,244,241,0.55)' : '#78756E',
      '--side-hover': sideHover,
      '--row-pad': dense ? '9px 14px' : '13px 16px',
      '--card-pad': dense ? '15px' : '20px',
      '--nav-active-bg': dark ? 'rgba(255,255,255,0.10)' : accent.soft,
      '--nav-active-fg': dark ? '#FFFFFF' : accent.accent,
    };
    return {
      ...state,
      setAccentIndex: (i) => setState((s) => ({ ...s, accentIndex: i })),
      setSidebarTheme: (t) => setState((s) => ({ ...s, sidebarTheme: t })),
      setDensity: (d) => setState((s) => ({ ...s, density: d })),
      cssVars,
      ac: accent.accent,
      acSoft: accent.soft,
    };
  }, [state]);

  return <AppearanceContext.Provider value={value}>{children}</AppearanceContext.Provider>;
}

export function useAppearance(): AppearanceContextValue {
  const ctx = useContext(AppearanceContext);
  if (!ctx) throw new Error('useAppearance debe usarse dentro de AppearanceProvider');
  return ctx;
}
