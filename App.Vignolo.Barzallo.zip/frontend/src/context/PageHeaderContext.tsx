import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';

interface PageHeaderConfig {
  title: string;
  subtitle?: string;
  primaryLabel?: string;
  onPrimary?: () => void;
}

interface HeaderState {
  title: string;
  subtitle?: string;
  primaryLabel?: string;
}

interface PageHeaderContextValue extends HeaderState {
  setHeaderState: (state: HeaderState) => void;
  triggerPrimary: () => void;
  setOnPrimary: (fn: (() => void) | undefined) => void;
}

const DEFAULT: HeaderState = { title: '', subtitle: '' };

const PageHeaderContext = createContext<PageHeaderContextValue | null>(null);

export function PageHeaderProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<HeaderState>(DEFAULT);
  const onPrimaryRef = useRef<(() => void) | undefined>(undefined);

  const value = useMemo<PageHeaderContextValue>(
    () => ({
      ...state,
      setHeaderState: setState,
      triggerPrimary: () => onPrimaryRef.current?.(),
      setOnPrimary: (fn) => {
        onPrimaryRef.current = fn;
      },
    }),
    [state],
  );

  return <PageHeaderContext.Provider value={value}>{children}</PageHeaderContext.Provider>;
}

export function usePageHeaderContext(): PageHeaderContextValue {
  const ctx = useContext(PageHeaderContext);
  if (!ctx) throw new Error('usePageHeaderContext debe usarse dentro de PageHeaderProvider');
  return ctx;
}

/** Pages call this to declare the topbar title/subtitle/primary action for as long as they're mounted. */
export function usePageHeader(config: PageHeaderConfig) {
  const { setHeaderState, setOnPrimary } = usePageHeaderContext();
  const { title, subtitle, primaryLabel, onPrimary } = config;

  // The callback identity changes every render of the calling page; keep it in
  // a ref via the context rather than in reactive state, or it would feed
  // back into a state update on every render and loop forever.
  useEffect(() => {
    setOnPrimary(() => onPrimary);
  });

  useEffect(() => {
    setHeaderState({ title, subtitle, primaryLabel });
    return () => setHeaderState(DEFAULT);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [title, subtitle, primaryLabel]);
}
