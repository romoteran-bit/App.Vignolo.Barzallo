import Fastify from 'fastify';
import cors from '@fastify/cors';
import cookie from '@fastify/cookie';
import multipart from '@fastify/multipart';
import fastifyStatic from '@fastify/static';
import path from 'node:path';
import { env } from './config/env.js';
import authPlugin from './plugins/auth.js';
import authRoutes from './modules/auth/routes.js';
import clientesRoutes from './modules/clientes/routes.js';
import casosRoutes from './modules/casos/routes.js';
import agendaRoutes from './modules/agenda/routes.js';
import tareasRoutes from './modules/tareas/routes.js';
import documentosRoutes from './modules/documentos/routes.js';
import facturasRoutes from './modules/facturas/routes.js';
import usuariosRoutes from './modules/usuarios/routes.js';
import rolesRoutes from './modules/roles/routes.js';
import catalogosRoutes from './modules/catalogos/routes.js';
import abogadosRoutes from './modules/abogados/routes.js';
import dashboardRoutes from './modules/dashboard/routes.js';
import configRoutes from './modules/config/routes.js';

export async function buildApp() {
  const app = Fastify({ logger: env.NODE_ENV !== 'test' });

  await app.register(cors, { origin: env.FRONTEND_ORIGIN, credentials: true });
  await app.register(cookie, { secret: env.COOKIE_SIGNING_SECRET });
  await app.register(multipart);
  await app.register(fastifyStatic, {
    root: path.resolve(env.UPLOAD_DIR),
    prefix: '/uploads-internal/',
    serve: false,
  });

  await app.register(authPlugin);

  app.get('/api/health', async () => ({ ok: true }));

  await app.register(authRoutes);
  await app.register(clientesRoutes);
  await app.register(casosRoutes);
  await app.register(agendaRoutes);
  await app.register(tareasRoutes);
  await app.register(documentosRoutes);
  await app.register(facturasRoutes);
  await app.register(usuariosRoutes);
  await app.register(rolesRoutes);
  await app.register(catalogosRoutes);
  await app.register(abogadosRoutes);
  await app.register(dashboardRoutes);
  await app.register(configRoutes);

  return app;
}
