import type { Prisma } from '@prisma/client';
import { prisma } from '../../lib/prisma.js';

export async function recordAudit(params: {
  actorId: string | null;
  accion: string;
  entidad: string;
  entidadId?: string | null;
  metadata?: Record<string, unknown>;
}) {
  await prisma.auditLog.create({
    data: {
      actorId: params.actorId,
      accion: params.accion,
      entidad: params.entidad,
      entidadId: params.entidadId ?? null,
      metadata: (params.metadata ?? undefined) as Prisma.InputJsonValue | undefined,
    },
  });
}
