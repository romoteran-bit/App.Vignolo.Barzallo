import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { EstadoFactura } from '@prisma/client';
import { prisma } from '../../lib/prisma.js';
import { requirePermission } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';
import { recordAudit } from '../audit/service.js';

const createSchema = z.object({
  clienteId: z.string().min(1),
  casoId: z.string().min(1).optional(),
  concepto: z.string().min(2),
  monto: z.number().positive(),
  emision: z.string().datetime(),
  vence: z.string().datetime(),
});

async function nextSecuencial(): Promise<string> {
  const last = await prisma.factura.findFirst({ orderBy: { secuencial: 'desc' } });
  const lastN = last ? parseInt(last.secuencial.split('-')[2] ?? '0', 10) : 0;
  const next = (Number.isFinite(lastN) ? lastN : 0) + 1;
  return `001-001-${String(next).padStart(9, '0')}`;
}

export default async function facturasRoutes(app: FastifyInstance) {
  app.get('/api/facturas', { preHandler: requirePermission(PERMISOS.VER_HONORARIOS) }, async () => {
    const facturas = await prisma.factura.findMany({
      where: { deletedAt: null },
      include: { cliente: true, caso: true },
      orderBy: { emision: 'desc' },
    });
    return facturas.map((f) => ({
      id: f.id,
      secuencial: f.secuencial,
      caso: f.caso?.id ?? '—',
      cliente: f.cliente.nombre,
      concepto: f.concepto,
      monto: f.monto.toNumber(),
      emision: f.emision,
      vence: f.vence,
      sriAutorizado: f.sriAutorizado,
      estado: f.estado,
    }));
  });

  app.post(
    '/api/facturas',
    { preHandler: requirePermission(PERMISOS.VER_HONORARIOS) },
    async (request, reply) => {
      const parsed = createSchema.safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos', detalles: parsed.error.flatten() });
      const data = parsed.data;

      const secuencial = await nextSecuencial();
      const factura = await prisma.factura.create({
        data: {
          secuencial,
          clienteId: data.clienteId,
          casoId: data.casoId,
          concepto: data.concepto,
          monto: data.monto,
          emision: new Date(data.emision),
          vence: new Date(data.vence),
          estado: EstadoFactura.PENDIENTE,
          sriAutorizado: true,
          sriAutorizacion: nanoidAuth(),
        },
      });

      await recordAudit({
        actorId: request.user!.id,
        accion: 'emitió el comprobante',
        entidad: 'Factura',
        entidadId: factura.id,
        metadata: { secuencial },
      });

      return reply.code(201).send(factura);
    },
  );
}

function nanoidAuth(): string {
  return Array.from({ length: 49 }, () => Math.floor(Math.random() * 10)).join('');
}
