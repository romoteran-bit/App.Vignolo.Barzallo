import type { FastifyInstance } from 'fastify';
import { EstadoTarea, TipoEvento, type Prisma } from '@prisma/client';
import { prisma } from '../../lib/prisma.js';
import { requireAuth } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';
import { casoScopeWhere } from '../casos/service.js';

function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}
function endOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1);
}
function startOfMonth(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

/** Prefers a human-readable label from audit metadata over the raw entity id. */
function friendlyAuditObject(entidad: string, entidadId: string | null, metadata: Record<string, unknown> | null): string {
  if (entidad === 'Caso') return entidadId ?? '';
  const meta = metadata ?? {};
  const candidate = meta.nombre ?? meta.titulo ?? meta.secuencial ?? meta.valor ?? meta.etapa;
  return typeof candidate === 'string' ? candidate : '';
}

export default async function dashboardRoutes(app: FastifyInstance) {
  app.get('/api/dashboard', { preHandler: requireAuth }, async (request) => {
    const user = request.user!;
    const now = new Date();
    const today0 = startOfDay(now);
    const today1 = endOfDay(now);
    const in7 = new Date(today0.getTime() + 7 * 24 * 60 * 60 * 1000);

    const casoWhere = casoScopeWhere(user);
    const casoIdsScoped = (await prisma.caso.findMany({ where: casoWhere, select: { id: true } })).map((c) => c.id);

    const [casosActivos, casosEsteMes, clientesActivos, clientesTotales] = await Promise.all([
      prisma.caso.count({ where: casoWhere }),
      prisma.caso.count({ where: { ...casoWhere, createdAt: { gte: startOfMonth(now) } } }),
      prisma.cliente.count({ where: { deletedAt: null, estado: { in: ['ACTIVO', 'VIP'] } } }),
      prisma.cliente.count({ where: { deletedAt: null } }),
    ]);

    const tareaVisibleOr: Prisma.TareaWhereInput[] = [
      ...(user.abogadoId ? [{ responsableId: user.abogadoId }] : []),
      { casoId: { in: casoIdsScoped } },
      ...(user.permisos.has(PERMISOS.VER_TODOS_CASOS) ? [{ casoId: null }] : []),
    ];
    const tareaVisibleWhere: Prisma.TareaWhereInput = { deletedAt: null, OR: tareaVisibleOr };

    const [tareasPendientes, tareasVencenHoy] = await Promise.all([
      prisma.tarea.count({ where: { ...tareaVisibleWhere, estado: { not: EstadoTarea.COMPLETADA } } }),
      prisma.tarea.count({
        where: { ...tareaVisibleWhere, estado: { not: EstadoTarea.COMPLETADA }, vence: { gte: today0, lt: today1 } },
      }),
    ]);

    const eventoVisibleWhere: Prisma.EventoAgendaWhereInput = {
      deletedAt: null,
      OR: [{ casoId: null }, { casoId: { in: casoIdsScoped } }],
    };

    const [audienciasSemana, audienciasHoy, eventosHoyRaw] = await Promise.all([
      prisma.eventoAgenda.count({
        where: { ...eventoVisibleWhere, tipo: TipoEvento.AUDIENCIA, fecha: { gte: today0, lt: in7 } },
      }),
      prisma.eventoAgenda.count({
        where: { ...eventoVisibleWhere, tipo: TipoEvento.AUDIENCIA, fecha: { gte: today0, lt: today1 } },
      }),
      prisma.eventoAgenda.findMany({
        where: { ...eventoVisibleWhere, fecha: { gte: today0, lt: today1 } },
        include: { caso: { include: { cliente: true } } },
        orderBy: { fecha: 'asc' },
      }),
    ]);

    const TIPO_COLOR: Record<TipoEvento, string> = {
      AUDIENCIA: '#A23A2E',
      REUNION: 'var(--ac,#2F5D50)',
      PLAZO: '#8A6218',
      LLAMADA: '#3A4B7A',
    };
    const eventosHoy = eventosHoyRaw.map((e) => ({
      hora: e.fecha.toLocaleTimeString('es-EC', { hour: '2-digit', minute: '2-digit', hour12: false }),
      titulo: e.titulo,
      sub: e.subtitulo || (e.caso ? `${e.caso.id} · ${e.caso.cliente.nombre}` : ''),
      tipo: e.tipo,
      color: TIPO_COLOR[e.tipo],
    }));

    const tareasVenc = await prisma.tarea.findMany({
      where: { ...tareaVisibleWhere, estado: { not: EstadoTarea.COMPLETADA } },
      include: { caso: true },
      orderBy: { vence: 'asc' },
      take: 5,
    });
    const vencimientos = tareasVenc.map((t) => {
      const days = Math.round((startOfDay(t.vence).getTime() - today0.getTime()) / 86400000);
      const cuando = days <= 0 ? 'Hoy' : days === 1 ? 'Mañana' : t.vence.toLocaleDateString('es-EC', { day: '2-digit', month: 'short' });
      const color = days <= 0 ? '#A23A2E' : days === 1 ? '#8A6218' : '#57544E';
      const bg = days <= 0 ? '#FBEAE7' : days === 1 ? '#FCF3E1' : '#EEEDE9';
      return { texto: t.titulo, caso: t.caso?.id ?? '—', cuando, color, bg };
    });

    const casosPorMateria = await prisma.caso.groupBy({
      by: ['materia'],
      where: casoWhere,
      _count: { _all: true },
      orderBy: { _count: { materia: 'desc' } },
    });
    const materiaMax = Math.max(1, ...casosPorMateria.map((m) => m._count._all));
    const materiaStats = casosPorMateria.map((m) => ({
      m: m.materia,
      n: m._count._all,
      pct: Math.round((m._count._all / materiaMax) * 100) + '%',
    }));

    const equipoRows = await prisma.casoResponsable.findMany({
      where: { caso: casoWhere },
      include: { abogado: true },
    });
    const porAbogado = new Map<string, { ini: string; a: string; color: string; n: number }>();
    for (const row of equipoRows) {
      const cur = porAbogado.get(row.abogadoId) ?? {
        ini: row.abogado.iniciales,
        a: row.abogado.nombre,
        color: row.abogado.color,
        n: 0,
      };
      cur.n += 1;
      porAbogado.set(row.abogadoId, cur);
    }
    const abogadoList = Array.from(porAbogado.values()).sort((a, b) => b.n - a.n);
    const abogadoMax = Math.max(1, ...abogadoList.map((a) => a.n));
    const abogadoStats = abogadoList.map((a) => ({ ...a, pct: Math.round((a.n / abogadoMax) * 100) + '%' }));

    let actividad: { autor: string; accion: string; obj: string; cuando: Date }[] = [];
    if (user.permisos.has(PERMISOS.VER_AUDITORIA)) {
      const logs = await prisma.auditLog.findMany({
        include: { actor: true },
        orderBy: { createdAt: 'desc' },
        take: 8,
      });
      actividad = logs.map((l) => ({
        autor: l.actor?.nombre ?? 'Sistema',
        accion: l.accion,
        obj: friendlyAuditObject(l.entidad, l.entidadId, l.metadata as Record<string, unknown> | null),
        cuando: l.createdAt,
      }));
    }

    return {
      kpis: {
        casosActivos,
        casosNuevosMes: casosEsteMes,
        audienciasSemana,
        audienciasHoy,
        tareasPendientes,
        tareasVencenHoy,
        clientesActivos,
        clientesTotales,
      },
      eventosHoy,
      vencimientos,
      materiaStats,
      abogadoStats,
      actividad,
    };
  });
}
