import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { EstadoCliente } from '@prisma/client';
import { prisma } from '../../lib/prisma.js';
import { requireAuth, requirePermission } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';
import { recordAudit } from '../audit/service.js';

const createSchema = z.object({
  nombre: z.string().min(2),
  tipo: z.string().min(2),
  estado: z.nativeEnum(EstadoCliente).default(EstadoCliente.POTENCIAL),
  identificacion: z.string().min(3),
  telefono: z.string().min(3),
  ciudad: z.string().min(2),
  responsableId: z.string().min(1),
});

export default async function clientesRoutes(app: FastifyInstance) {
  app.get('/api/clientes', { preHandler: requireAuth }, async (request) => {
    const { estado } = request.query as { estado?: string };
    const clientes = await prisma.cliente.findMany({
      where: {
        deletedAt: null,
        ...(estado && estado !== 'Todos' ? { estado: estado as EstadoCliente } : {}),
      },
      include: { responsable: true, _count: { select: { casos: { where: { deletedAt: null } } } } },
      orderBy: { nombre: 'asc' },
    });
    return clientes.map((c) => ({
      id: c.id,
      nombre: c.nombre,
      tipo: c.tipo,
      estado: c.estado,
      identificacion: c.identificacion,
      telefono: c.telefono,
      ciudad: c.ciudad,
      casos: c._count.casos,
      responsable: { id: c.responsable.id, ini: c.responsable.iniciales, color: c.responsable.color },
      creadoEn: c.createdAt,
    }));
  });

  app.get('/api/clientes/:id', { preHandler: requireAuth }, async (request, reply) => {
    const { id } = request.params as { id: string };
    const cliente = await prisma.cliente.findFirst({
      where: { id, deletedAt: null },
      include: {
        responsable: true,
        casos: { where: { deletedAt: null }, orderBy: { createdAt: 'desc' } },
      },
    });
    if (!cliente) return reply.code(404).send({ error: 'Cliente no encontrado' });
    return {
      id: cliente.id,
      nombre: cliente.nombre,
      tipo: cliente.tipo,
      estado: cliente.estado,
      identificacion: cliente.identificacion,
      telefono: cliente.telefono,
      ciudad: cliente.ciudad,
      creadoEn: cliente.createdAt,
      responsable: { id: cliente.responsable.id, nombre: cliente.responsable.nombre },
      casos: cliente.casos.map((c) => ({ id: c.id, materia: c.materia, etapa: c.etapa })),
    };
  });

  app.post(
    '/api/clientes',
    { preHandler: requirePermission(PERMISOS.GESTIONAR_CLIENTES) },
    async (request, reply) => {
      const parsed = createSchema.safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos', detalles: parsed.error.flatten() });

      const cliente = await prisma.cliente.create({ data: parsed.data });
      await recordAudit({
        actorId: request.user!.id,
        accion: 'creó el cliente',
        entidad: 'Cliente',
        entidadId: cliente.id,
        metadata: { nombre: cliente.nombre },
      });
      return reply.code(201).send(cliente);
    },
  );

  app.patch(
    '/api/clientes/:id',
    { preHandler: requirePermission(PERMISOS.GESTIONAR_CLIENTES) },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const parsed = createSchema.partial().safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos' });

      const existing = await prisma.cliente.findFirst({ where: { id, deletedAt: null } });
      if (!existing) return reply.code(404).send({ error: 'Cliente no encontrado' });

      const cliente = await prisma.cliente.update({ where: { id }, data: parsed.data });
      await recordAudit({
        actorId: request.user!.id,
        accion: 'editó el cliente',
        entidad: 'Cliente',
        entidadId: cliente.id,
      });
      return reply.send(cliente);
    },
  );

  app.delete(
    '/api/clientes/:id',
    { preHandler: requirePermission(PERMISOS.ELIMINACION_LOGICA) },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const existing = await prisma.cliente.findFirst({ where: { id, deletedAt: null } });
      if (!existing) return reply.code(404).send({ error: 'Cliente no encontrado' });

      await prisma.cliente.update({ where: { id }, data: { deletedAt: new Date() } });
      await recordAudit({
        actorId: request.user!.id,
        accion: 'eliminó (soft delete) el cliente',
        entidad: 'Cliente',
        entidadId: id,
        metadata: { nombre: existing.nombre },
      });
      return reply.send({ ok: true });
    },
  );
}

export function initials(nombre: string): string {
  return nombre
    .replace(/[^A-Za-zÁÉÍÓÚÑáéíóúñ ]/g, '')
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('');
}
