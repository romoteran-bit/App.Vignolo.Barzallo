import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { Prioridad, EstadoTarea, Prisma } from '@prisma/client';
import { prisma } from '../../lib/prisma.js';
import { requireAnyPermission, requireAuth } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';
import type { AuthUser } from '../../plugins/auth.js';
import { recordAudit } from '../audit/service.js';

const createSchema = z.object({
  casoId: z.string().min(1).optional(),
  titulo: z.string().min(2),
  responsableId: z.string().min(1).optional(),
  prioridad: z.nativeEnum(Prioridad),
  vence: z.string().datetime(),
});

function tareaScopeWhere(user: AuthUser): Prisma.TareaWhereInput {
  if (user.permisos.has(PERMISOS.VER_TODOS_CASOS)) return { deletedAt: null };
  if (user.permisos.has(PERMISOS.VER_CASOS_ASIGNADOS) && user.abogadoId) {
    return {
      deletedAt: null,
      OR: [{ responsableId: user.abogadoId }, { caso: { equipo: { some: { abogadoId: user.abogadoId } } } }],
    };
  }
  return { id: '__no-visible-tasks__' };
}

export default async function tareasRoutes(app: FastifyInstance) {
  app.get('/api/tareas', { preHandler: requireAuth }, async (request) => {
    const tareas = await prisma.tarea.findMany({
      where: tareaScopeWhere(request.user!),
      include: { caso: true },
      orderBy: { vence: 'asc' },
    });
    return tareas.map((t) => ({
      id: t.id,
      titulo: t.titulo,
      caso: t.caso?.id ?? '—',
      prioridad: t.prioridad,
      vence: t.vence,
      estado: t.estado,
    }));
  });

  app.post(
    '/api/tareas',
    { preHandler: requireAnyPermission(PERMISOS.CREAR_TAREAS) },
    async (request, reply) => {
      const parsed = createSchema.safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos', detalles: parsed.error.flatten() });

      const tarea = await prisma.tarea.create({
        data: { ...parsed.data, vence: new Date(parsed.data.vence) },
      });
      await recordAudit({
        actorId: request.user!.id,
        accion: 'creó la tarea',
        entidad: 'Tarea',
        entidadId: tarea.id,
        metadata: { titulo: tarea.titulo },
      });
      return reply.code(201).send(tarea);
    },
  );

  app.patch('/api/tareas/:id/alternar', { preHandler: requireAuth }, async (request, reply) => {
    const { id } = request.params as { id: string };
    const tarea = await prisma.tarea.findFirst({
      where: { id, deletedAt: null },
      include: { caso: { include: { equipo: true } } },
    });
    if (!tarea) return reply.code(404).send({ error: 'Tarea no encontrada' });

    const user = request.user!;
    const visible =
      user.permisos.has(PERMISOS.VER_TODOS_CASOS) ||
      (user.permisos.has(PERMISOS.VER_CASOS_ASIGNADOS) &&
        (tarea.responsableId === user.abogadoId ||
          tarea.caso?.equipo.some((e) => e.abogadoId === user.abogadoId)));
    if (!visible) return reply.code(403).send({ error: 'No autorizado' });

    const nuevoEstado = tarea.estado === EstadoTarea.COMPLETADA ? EstadoTarea.PENDIENTE : EstadoTarea.COMPLETADA;
    await prisma.tarea.update({ where: { id }, data: { estado: nuevoEstado } });
    await recordAudit({
      actorId: user.id,
      accion: nuevoEstado === EstadoTarea.COMPLETADA ? 'completó la tarea' : 'reabrió la tarea',
      entidad: 'Tarea',
      entidadId: id,
      metadata: { titulo: tarea.titulo },
    });
    return reply.send({ ok: true, estado: nuevoEstado });
  });
}
