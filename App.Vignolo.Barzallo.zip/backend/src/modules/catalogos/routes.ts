import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { CategoriaCatalogo } from '@prisma/client';
import { prisma } from '../../lib/prisma.js';
import { requireAuth, requirePermission } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';
import { recordAudit } from '../audit/service.js';

const createSchema = z.object({
  categoria: z.nativeEnum(CategoriaCatalogo),
  valor: z.string().min(1).max(80),
});

export default async function catalogosRoutes(app: FastifyInstance) {
  app.get('/api/catalogos', { preHandler: requireAuth }, async () => {
    const items = await prisma.catalogoItem.findMany({
      where: { activo: true },
      orderBy: [{ categoria: 'asc' }, { orden: 'asc' }],
    });
    const grouped: Record<string, string[]> = {};
    for (const item of items) {
      (grouped[item.categoria] ??= []).push(item.valor);
    }
    return grouped;
  });

  app.post(
    '/api/catalogos',
    { preHandler: requirePermission(PERMISOS.CONFIGURAR_SISTEMA) },
    async (request, reply) => {
      const parsed = createSchema.safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos' });

      const max = await prisma.catalogoItem.aggregate({
        where: { categoria: parsed.data.categoria },
        _max: { orden: true },
      });
      const item = await prisma.catalogoItem.create({
        data: { ...parsed.data, orden: (max._max.orden ?? -1) + 1 },
      });
      await recordAudit({
        actorId: request.user!.id,
        accion: 'añadió al catálogo',
        entidad: 'CatalogoItem',
        entidadId: item.id,
        metadata: { categoria: item.categoria, valor: item.valor },
      });
      return reply.code(201).send(item);
    },
  );
}
