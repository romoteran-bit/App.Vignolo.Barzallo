import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '../../lib/prisma.js';
import { requireAuth, requirePermission } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';
import { recordAudit } from '../audit/service.js';

const createSchema = z.object({
  nombre: z.string().min(2),
  iniciales: z.string().min(1).max(3),
  cargo: z.string().min(2),
  color: z.string().regex(/^#[0-9A-Fa-f]{6}$/),
});

export default async function abogadosRoutes(app: FastifyInstance) {
  app.get('/api/abogados', { preHandler: requireAuth }, async () => {
    return prisma.abogado.findMany({
      where: { deletedAt: null },
      orderBy: { nombre: 'asc' },
    });
  });

  app.post(
    '/api/abogados',
    { preHandler: requirePermission(PERMISOS.CONFIGURAR_SISTEMA) },
    async (request, reply) => {
      const parsed = createSchema.safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos' });

      const abogado = await prisma.abogado.create({ data: parsed.data });
      await recordAudit({
        actorId: request.user!.id,
        accion: 'creó el abogado',
        entidad: 'Abogado',
        entidadId: abogado.id,
        metadata: { nombre: abogado.nombre },
      });
      return reply.code(201).send(abogado);
    },
  );
}
