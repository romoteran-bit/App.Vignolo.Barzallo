import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '../../lib/prisma.js';
import { requirePermission } from '../../plugins/auth.js';
import { PERMISOS, PERMISO_ETIQUETAS, PERMISO_ORDEN } from '../../lib/permissions.js';
import { recordAudit } from '../audit/service.js';

const toggleSchema = z.object({
  rolId: z.string().min(1),
  permisoClave: z.string().min(1),
  permitido: z.boolean(),
});

export default async function rolesRoutes(app: FastifyInstance) {
  // Roles y permisos matrix requires configurar_sistema; the mere list of
  // roles (for the "new user" role select) is available to anyone who can
  // administer users.
  app.get(
    '/api/roles',
    { preHandler: requirePermission(PERMISOS.CONFIGURAR_SISTEMA) },
    async () => {
      const roles = await prisma.rol.findMany({
        include: { permisos: true },
        orderBy: { createdAt: 'asc' },
      });
      return {
        permisos: PERMISO_ORDEN.map((clave) => ({ clave, etiqueta: PERMISO_ETIQUETAS[clave] })),
        roles: roles.map((r) => ({
          id: r.id,
          nombre: r.nombre,
          permisos: r.permisos.map((p) => p.permisoClave),
        })),
      };
    },
  );

  app.get('/api/roles/opciones', { preHandler: requirePermission(PERMISOS.ADMINISTRAR_USUARIOS) }, async () => {
    return prisma.rol.findMany({ select: { id: true, nombre: true }, orderBy: { createdAt: 'asc' } });
  });

  app.put(
    '/api/roles/permisos',
    { preHandler: requirePermission(PERMISOS.CONFIGURAR_SISTEMA) },
    async (request, reply) => {
      const parsed = toggleSchema.safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos' });
      const { rolId, permisoClave, permitido } = parsed.data;

      const rol = await prisma.rol.findUnique({ where: { id: rolId } });
      if (!rol) return reply.code(404).send({ error: 'Rol no encontrado' });
      if (rol.nombre === 'Administrador') {
        return reply.code(400).send({ error: 'El rol Administrador no es editable' });
      }

      if (permitido) {
        await prisma.rolPermiso.upsert({
          where: { rolId_permisoClave: { rolId, permisoClave } },
          create: { rolId, permisoClave },
          update: {},
        });
      } else {
        await prisma.rolPermiso.deleteMany({ where: { rolId, permisoClave } });
      }

      await recordAudit({
        actorId: request.user!.id,
        accion: permitido ? 'concedió el permiso' : 'revocó el permiso',
        entidad: 'RolPermiso',
        entidadId: rolId,
        metadata: { rol: rol.nombre, permisoClave },
      });

      return reply.send({ ok: true });
    },
  );
}
