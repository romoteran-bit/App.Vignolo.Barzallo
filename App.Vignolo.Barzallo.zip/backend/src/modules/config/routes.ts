import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '../../lib/prisma.js';
import { requirePermission } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';
import { recordAudit } from '../audit/service.js';

const updateSchema = z.object({
  nombreEstudio: z.string().min(2).optional(),
  zonaHoraria: z.string().min(2).optional(),
  moneda: z.string().min(1).optional(),
  dosFactoresHabilitado: z.boolean().optional(),
});

export default async function configRoutes(app: FastifyInstance) {
  app.get('/api/config/general', { preHandler: requirePermission(PERMISOS.CONFIGURAR_SISTEMA) }, async () => {
    return prisma.configuracionGeneral.upsert({
      where: { id: 1 },
      create: { id: 1 },
      update: {},
    });
  });

  app.patch(
    '/api/config/general',
    { preHandler: requirePermission(PERMISOS.CONFIGURAR_SISTEMA) },
    async (request, reply) => {
      const parsed = updateSchema.safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos' });

      const config = await prisma.configuracionGeneral.upsert({
        where: { id: 1 },
        create: { id: 1, ...parsed.data },
        update: parsed.data,
      });

      await recordAudit({
        actorId: request.user!.id,
        accion: 'actualizó la configuración general',
        entidad: 'ConfiguracionGeneral',
        entidadId: '1',
      });

      return reply.send(config);
    },
  );
}
