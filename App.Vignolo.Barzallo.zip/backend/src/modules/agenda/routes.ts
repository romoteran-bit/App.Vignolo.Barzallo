import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { TipoEvento } from '@prisma/client';
import { prisma } from '../../lib/prisma.js';
import { requireAnyPermission, requireAuth } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';
import { canSeeCaso } from '../casos/service.js';
import { recordAudit } from '../audit/service.js';

const createSchema = z.object({
  casoId: z.string().min(1).optional(),
  abogadoId: z.string().min(1).optional(),
  fecha: z.string().datetime(),
  titulo: z.string().min(2),
  subtitulo: z.string().default(''),
  tipo: z.nativeEnum(TipoEvento),
});

const TIPO_COLOR: Record<TipoEvento, string> = {
  AUDIENCIA: '#A23A2E',
  REUNION: 'var(--ac,#2F5D50)',
  PLAZO: '#8A6218',
  LLAMADA: '#3A4B7A',
};

export default async function agendaRoutes(app: FastifyInstance) {
  app.get('/api/agenda', { preHandler: requireAuth }, async (request) => {
    const { year, month } = request.query as { year?: string; month?: string };
    const y = year ? parseInt(year, 10) : new Date().getFullYear();
    const m = month ? parseInt(month, 10) : new Date().getMonth() + 1;
    const start = new Date(y, m - 1, 1);
    const end = new Date(y, m, 1);

    const eventos = await prisma.eventoAgenda.findMany({
      where: { deletedAt: null, fecha: { gte: start, lt: end } },
      include: { caso: { include: { equipo: true } } },
      orderBy: { fecha: 'asc' },
    });

    return eventos
      .filter((e) => !e.caso || canSeeCaso(request.user!, e.caso.equipo.map((x) => x.abogadoId)))
      .map((e) => ({
        id: e.id,
        casoId: e.casoId,
        fecha: e.fecha,
        titulo: e.titulo,
        subtitulo: e.subtitulo,
        tipo: e.tipo,
        color: TIPO_COLOR[e.tipo],
      }));
  });

  app.post(
    '/api/agenda',
    { preHandler: requireAnyPermission(PERMISOS.CREAR_TAREAS, PERMISOS.CREAR_EDITAR_CASOS) },
    async (request, reply) => {
      const parsed = createSchema.safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos', detalles: parsed.error.flatten() });

      const evento = await prisma.eventoAgenda.create({
        data: { ...parsed.data, fecha: new Date(parsed.data.fecha) },
      });
      await recordAudit({
        actorId: request.user!.id,
        accion: 'creó el evento de agenda',
        entidad: 'EventoAgenda',
        entidadId: evento.id,
        metadata: { titulo: evento.titulo },
      });
      return reply.code(201).send(evento);
    },
  );
}
