import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '../../lib/prisma.js';
import { verifyPassword } from '../../lib/password.js';
import { createSession, destroySession } from '../../lib/session.js';
import { env } from '../../config/env.js';
import { recordAudit } from '../audit/service.js';
import { isLocked, nextFailedAttemptState, RESET_ATTEMPT_STATE, LOCKOUT_MINUTES } from '../../lib/lockout.js';

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  recordarDispositivo: z.boolean().optional(),
});

export default async function authRoutes(app: FastifyInstance) {
  app.post('/api/auth/login', async (request, reply) => {
    const parsed = loginSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: 'Correo o contraseña inválidos' });
    }
    const { email, password } = parsed.data;

    const usuario = await prisma.usuario.findUnique({
      where: { email: email.toLowerCase() },
      include: { rol: true },
    });

    // Constant-shaped response whether the account exists or not, to avoid
    // leaking which emails are registered.
    const genericError = () => reply.code(401).send({ error: 'Correo o contraseña incorrectos' });
    const lockedError = () =>
      reply.code(423).send({
        error: `Cuenta bloqueada temporalmente por múltiples intentos fallidos. Intente de nuevo en ${LOCKOUT_MINUTES} minutos.`,
      });

    if (!usuario || !usuario.activo || usuario.deletedAt || !usuario.passwordHash) return genericError();

    if (isLocked(usuario.lockedUntil)) return lockedError();

    const ok = await verifyPassword(usuario.passwordHash, password);
    if (!ok) {
      const nextState = nextFailedAttemptState(usuario.failedLoginAttempts);
      await prisma.usuario.update({ where: { id: usuario.id }, data: nextState });
      if (nextState.lockedUntil) {
        await recordAudit({
          actorId: usuario.id,
          accion: 'bloqueó la cuenta por intentos fallidos de',
          entidad: 'Usuario',
          entidadId: usuario.id,
        });
        return lockedError();
      }
      return genericError();
    }

    const { token, expiresAt } = await createSession(
      usuario.id,
      request.headers['user-agent'],
      request.ip,
    );

    await prisma.usuario.update({
      where: { id: usuario.id },
      data: { lastLoginAt: new Date(), ...RESET_ATTEMPT_STATE },
    });
    await recordAudit({
      actorId: usuario.id,
      accion: 'inició sesión',
      entidad: 'Usuario',
      entidadId: usuario.id,
    });

    reply.setCookie(env.SESSION_COOKIE_NAME, token, {
      httpOnly: true,
      secure: env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      signed: true,
      expires: expiresAt,
    });

    return reply.send({
      id: usuario.id,
      nombre: usuario.nombre,
      email: usuario.email,
      rol: usuario.rol.nombre,
      mustReset: usuario.mustReset,
    });
  });

  app.post('/api/auth/logout', async (request, reply) => {
    if (request.sessionToken) {
      await destroySession(request.sessionToken);
    }
    reply.clearCookie(env.SESSION_COOKIE_NAME, { path: '/' });
    return reply.send({ ok: true });
  });

  app.get('/api/auth/me', async (request, reply) => {
    if (!request.user) return reply.code(401).send({ error: 'No autenticado' });
    return reply.send({
      id: request.user.id,
      nombre: request.user.nombre,
      email: request.user.email,
      rol: request.user.rolNombre,
      abogadoId: request.user.abogadoId,
      mustReset: request.user.mustReset,
      permisos: Array.from(request.user.permisos),
    });
  });
}
