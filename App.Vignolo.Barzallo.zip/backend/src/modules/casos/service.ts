import type { Prisma } from '@prisma/client';
import type { AuthUser } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';

/** Builds the visibility scope for casos according to the requester's role. */
export function casoScopeWhere(user: AuthUser): Prisma.CasoWhereInput {
  if (user.permisos.has(PERMISOS.VER_TODOS_CASOS)) {
    return { deletedAt: null };
  }
  if (user.permisos.has(PERMISOS.VER_CASOS_ASIGNADOS) && user.abogadoId) {
    return { deletedAt: null, equipo: { some: { abogadoId: user.abogadoId } } };
  }
  return { id: '__no-visible-cases__' };
}

export function canSeeCaso(user: AuthUser, equipoAbogadoIds: string[]): boolean {
  if (user.permisos.has(PERMISOS.VER_TODOS_CASOS)) return true;
  if (user.permisos.has(PERMISOS.VER_CASOS_ASIGNADOS) && user.abogadoId) {
    return equipoAbogadoIds.includes(user.abogadoId);
  }
  return false;
}
