import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { CategoriaCatalogo, Prioridad, TipoActuacion } from '@prisma/client';
import { prisma } from '../../lib/prisma.js';
import { requireAnyPermission, requirePermission } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';
import { casoScopeWhere, canSeeCaso } from './service.js';
import { recordAudit } from '../audit/service.js';

const createSchema = z.object({
  clienteId: z.string().min(1),
  materia: z.string().min(2),
  etapa: z.string().min(2),
  prioridad: z.nativeEnum(Prioridad),
  juzgado: z.string().min(2),
  numeroProceso: z.string().default('—'),
  contraparte: z.string().default('—'),
  inicio: z.string().min(2),
  cierreEstimado: z.string().default('—'),
  descripcion: z.string().min(1),
  estrategia: z.string().min(1),
  riesgos: z.string().default('—'),
  equipoAbogadoIds: z.array(z.string()).min(1),
});

async function nextCasoId(): Promise<string> {
  const year = new Date().getFullYear();
  const prefix = `VB-${year}-`;
  const last = await prisma.caso.findFirst({
    where: { id: { startsWith: prefix } },
    orderBy: { id: 'desc' },
  });
  const lastN = last ? parseInt(last.id.slice(prefix.length), 10) : 0;
  const next = (Number.isFinite(lastN) ? lastN : 0) + 1;
  return `${prefix}${String(next).padStart(3, '0')}`;
}

async function proximaFor(casoId: string): Promise<string> {
  const [tarea, evento] = await Promise.all([
    prisma.tarea.findFirst({
      where: { casoId, estado: { not: 'COMPLETADA' }, deletedAt: null },
      orderBy: { vence: 'asc' },
    }),
    prisma.eventoAgenda.findFirst({
      where: { casoId, fecha: { gte: new Date(new Date().toDateString()) }, deletedAt: null },
      orderBy: { fecha: 'asc' },
    }),
  ]);
  const candidates: { fecha: Date; texto: string }[] = [];
  if (tarea) candidates.push({ fecha: tarea.vence, texto: `${tarea.titulo} — ${fmtDate(tarea.vence)}` });
  if (evento) candidates.push({ fecha: evento.fecha, texto: `${evento.titulo} — ${fmtDate(evento.fecha)}` });
  candidates.sort((a, b) => a.fecha.getTime() - b.fecha.getTime());
  return candidates[0]?.texto ?? '—';
}

function fmtDate(d: Date): string {
  return d.toLocaleDateString('es-EC', { day: '2-digit', month: 'short' });
}

export default async function casosRoutes(app: FastifyInstance) {
  app.get(
    '/api/casos',
    { preHandler: requireAnyPermission(PERMISOS.VER_TODOS_CASOS, PERMISOS.VER_CASOS_ASIGNADOS) },
    async (request) => {
      const casos = await prisma.caso.findMany({
        where: casoScopeWhere(request.user!),
        include: { cliente: true, equipo: { include: { abogado: true } } },
        orderBy: { createdAt: 'desc' },
      });
      return Promise.all(
        casos.map(async (c) => ({
          id: c.id,
          cliente: c.cliente.nombre,
          materia: c.materia,
          etapa: c.etapa,
          prioridad: c.prioridad,
          equipo: c.equipo.map((e) => ({ id: e.abogado.id, ini: e.abogado.iniciales, color: e.abogado.color })),
          proxima: await proximaFor(c.id),
        })),
      );
    },
  );

  app.get(
    '/api/casos/:id',
    { preHandler: requireAnyPermission(PERMISOS.VER_TODOS_CASOS, PERMISOS.VER_CASOS_ASIGNADOS) },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const caso = await prisma.caso.findFirst({
        where: { id, deletedAt: null },
        include: {
          cliente: true,
          equipo: { include: { abogado: true } },
          actuaciones: { include: { autor: true }, orderBy: { fecha: 'desc' } },
          documentos: { where: { deletedAt: null }, orderBy: { subidoEn: 'desc' } },
        },
      });
      if (!caso) return reply.code(404).send({ error: 'Caso no encontrado' });
      if (!canSeeCaso(request.user!, caso.equipo.map((e) => e.abogadoId))) {
        return reply.code(403).send({ error: 'No autorizado para ver este caso' });
      }

      const etapasCatalogo = await prisma.catalogoItem.findMany({
        where: { categoria: CategoriaCatalogo.ETAPA_PROCESAL, activo: true },
        orderBy: { orden: 'asc' },
      });
      const etapaIdx = Math.max(0, etapasCatalogo.findIndex((e) => e.valor === caso.etapa));

      return {
        id: caso.id,
        cliente: caso.cliente.nombre,
        clienteId: caso.clienteId,
        materia: caso.materia,
        etapa: caso.etapa,
        etapaIdx,
        etapas: etapasCatalogo.map((e) => e.valor),
        prioridad: caso.prioridad,
        juzgado: caso.juzgado,
        numeroProceso: caso.numeroProceso,
        contraparte: caso.contraparte,
        inicio: caso.inicio,
        cierreEstimado: caso.cierreEstimado,
        descripcion: caso.descripcion,
        estrategia: caso.estrategia,
        riesgos: caso.riesgos,
        equipo: caso.equipo.map((e) => ({
          id: e.abogado.id,
          nombre: e.abogado.nombre,
          cargo: e.abogado.cargo,
          color: e.abogado.color,
          ini: e.abogado.iniciales,
        })),
        cronologia: caso.actuaciones.map((a) => ({
          tipo: a.tipo,
          fecha: a.fecha,
          autor: a.autor?.nombre ?? '—',
          texto: a.texto,
        })),
        documentos: caso.documentos.map((d) => ({
          id: d.id,
          nombre: d.nombre,
          extension: d.extension,
          tamanoBytes: d.tamanoBytes,
          subidoEn: d.subidoEn,
        })),
      };
    },
  );

  app.post(
    '/api/casos',
    { preHandler: requirePermission(PERMISOS.CREAR_EDITAR_CASOS) },
    async (request, reply) => {
      const parsed = createSchema.safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos', detalles: parsed.error.flatten() });
      const data = parsed.data;

      const id = await nextCasoId();
      const caso = await prisma.caso.create({
        data: {
          id,
          clienteId: data.clienteId,
          materia: data.materia,
          etapa: data.etapa,
          prioridad: data.prioridad,
          juzgado: data.juzgado,
          numeroProceso: data.numeroProceso,
          contraparte: data.contraparte,
          inicio: data.inicio,
          cierreEstimado: data.cierreEstimado,
          descripcion: data.descripcion,
          estrategia: data.estrategia,
          riesgos: data.riesgos,
          equipo: { createMany: { data: data.equipoAbogadoIds.map((abogadoId) => ({ abogadoId })) } },
          actuaciones: {
            create: {
              tipo: TipoActuacion.CREACION,
              texto: 'Caso creado y asignado al equipo.',
              autorId: request.user!.id,
            },
          },
        },
      });

      await recordAudit({
        actorId: request.user!.id,
        accion: 'creó el caso',
        entidad: 'Caso',
        entidadId: caso.id,
      });

      return reply.code(201).send(caso);
    },
  );

  app.patch(
    '/api/casos/:id/etapa',
    { preHandler: requirePermission(PERMISOS.CREAR_EDITAR_CASOS) },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const parsed = z.object({ etapa: z.string().min(2) }).safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos' });

      const caso = await prisma.caso.findFirst({
        where: { id, deletedAt: null },
        include: { equipo: true },
      });
      if (!caso) return reply.code(404).send({ error: 'Caso no encontrado' });
      if (!canSeeCaso(request.user!, caso.equipo.map((e) => e.abogadoId))) {
        return reply.code(403).send({ error: 'No autorizado para editar este caso' });
      }

      const etapaValida = await prisma.catalogoItem.findFirst({
        where: { categoria: CategoriaCatalogo.ETAPA_PROCESAL, valor: parsed.data.etapa, activo: true },
      });
      if (!etapaValida) return reply.code(400).send({ error: 'Etapa procesal inválida' });

      await prisma.$transaction([
        prisma.caso.update({ where: { id }, data: { etapa: parsed.data.etapa } }),
        prisma.actuacion.create({
          data: {
            casoId: id,
            tipo: TipoActuacion.ETAPA,
            texto: `Etapa cambiada a "${parsed.data.etapa}".`,
            autorId: request.user!.id,
          },
        }),
      ]);

      await recordAudit({
        actorId: request.user!.id,
        accion: 'cambió la etapa de',
        entidad: 'Caso',
        entidadId: id,
        metadata: { etapa: parsed.data.etapa },
      });

      return reply.send({ ok: true });
    },
  );
}
