import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '../../lib/prisma.js';
import { requirePermission } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';
import { hashPassword } from '../../lib/password.js';
import { destroyAllSessionsForUser } from '../../lib/session.js';
import { initialsFromName } from '../../lib/names.js';
import { recordAudit } from '../audit/service.js';

const createSchema = z.object({
  nombre: z.string().min(2),
  email: z.string().email(),
  rolId: z.string().min(1),
  passwordTemporal: z.string().min(10),
  mustReset: z.boolean().default(true),
});

const resetSchema = z.object({
  passwordTemporal: z.string().min(10),
  mustReset: z.boolean().default(true),
});

export default async function usuariosRoutes(app: FastifyInstance) {
  app.get('/api/usuarios', { preHandler: requirePermission(PERMISOS.ADMINISTRAR_USUARIOS) }, async () => {
    const usuarios = await prisma.usuario.findMany({
      where: { deletedAt: null },
      include: { rol: true, abogado: true },
      orderBy: { createdAt: 'asc' },
    });
    return usuarios.map((u) => ({
      id: u.id,
      nombre: u.nombre,
      email: u.email,
      rol: u.rol.nombre,
      activo: u.activo,
      passwordEstablecida: !!u.passwordHash,
      lastLoginAt: u.lastLoginAt,
      createdAt: u.createdAt,
      ini: u.abogado?.iniciales ?? initialsFromName(u.nombre),
      color: u.abogado?.color ?? '#7A6A5A',
    }));
  });

  app.post(
    '/api/usuarios',
    { preHandler: requirePermission(PERMISOS.ADMINISTRAR_USUARIOS) },
    async (request, reply) => {
      const parsed = createSchema.safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos', detalles: parsed.error.flatten() });
      const { nombre, email, rolId, passwordTemporal, mustReset } = parsed.data;

      const existing = await prisma.usuario.findUnique({ where: { email: email.toLowerCase() } });
      if (existing) return reply.code(409).send({ error: 'Ya existe un usuario con ese correo' });

      const rol = await prisma.rol.findUnique({ where: { id: rolId } });
      if (!rol) return reply.code(400).send({ error: 'Rol inválido' });

      const passwordHash = await hashPassword(passwordTemporal);
      const usuario = await prisma.usuario.create({
        data: { nombre, email: email.toLowerCase(), rolId, passwordHash, mustReset },
      });

      await recordAudit({
        actorId: request.user!.id,
        accion: 'creó el usuario',
        entidad: 'Usuario',
        entidadId: usuario.id,
        metadata: { nombre, rol: rol.nombre },
      });

      return reply.code(201).send({ id: usuario.id, nombre: usuario.nombre, email: usuario.email });
    },
  );

  app.post(
    '/api/usuarios/:id/restablecer-password',
    { preHandler: requirePermission(PERMISOS.ADMINISTRAR_USUARIOS) },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const parsed = resetSchema.safeParse(request.body);
      if (!parsed.success) return reply.code(400).send({ error: 'Datos inválidos' });

      const usuario = await prisma.usuario.findUnique({ where: { id } });
      if (!usuario || usuario.deletedAt) return reply.code(404).send({ error: 'Usuario no encontrado' });

      const passwordHash = await hashPassword(parsed.data.passwordTemporal);
      await prisma.usuario.update({
        where: { id },
        data: { passwordHash, mustReset: parsed.data.mustReset },
      });
      await destroyAllSessionsForUser(id);

      await recordAudit({
        actorId: request.user!.id,
        accion: 'restableció la contraseña de',
        entidad: 'Usuario',
        entidadId: id,
        metadata: { nombre: usuario.nombre },
      });

      return reply.send({ ok: true });
    },
  );
}
