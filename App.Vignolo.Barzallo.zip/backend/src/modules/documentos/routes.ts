import type { FastifyInstance } from 'fastify';
import { createWriteStream } from 'node:fs';
import { mkdir, stat, unlink } from 'node:fs/promises';
import path from 'node:path';
import { pipeline } from 'node:stream/promises';
import { nanoid } from 'nanoid';
import { prisma } from '../../lib/prisma.js';
import { requireAuth, requirePermission } from '../../plugins/auth.js';
import { PERMISOS } from '../../lib/permissions.js';
import { env } from '../../config/env.js';
import { recordAudit } from '../audit/service.js';
import { initialsFromName } from '../../lib/names.js';

const uploadDir = path.resolve(env.UPLOAD_DIR);

export default async function documentosRoutes(app: FastifyInstance) {
  await mkdir(uploadDir, { recursive: true });

  app.get('/api/documentos', { preHandler: requireAuth }, async () => {
    const documentos = await prisma.documento.findMany({
      where: { deletedAt: null },
      include: { caso: true, cliente: true, subidoPor: { include: { abogado: true } } },
      orderBy: { subidoEn: 'desc' },
    });
    return documentos.map((d) => ({
      id: d.id,
      nombre: d.nombre,
      extension: d.extension,
      caso: d.caso?.id ?? '—',
      cliente: d.cliente?.nombre ?? '—',
      tamanoBytes: d.tamanoBytes,
      subidoEn: d.subidoEn,
      subidoPor: {
        ini: d.subidoPor.abogado?.iniciales ?? initialsFromName(d.subidoPor.nombre),
        color: d.subidoPor.abogado?.color ?? '#57544E',
      },
    }));
  });

  app.post(
    '/api/documentos',
    { preHandler: requirePermission(PERMISOS.SUBIR_DOCUMENTOS) },
    async (request, reply) => {
      const data = await request.file({ limits: { fileSize: 25 * 1024 * 1024 } });
      if (!data) return reply.code(400).send({ error: 'No se recibió ningún archivo' });

      const fields = data.fields as Record<string, { value?: string } | undefined>;
      const casoId = fields.casoId?.value || undefined;
      const clienteId = fields.clienteId?.value || undefined;

      if (casoId) {
        const caso = await prisma.caso.findFirst({ where: { id: casoId, deletedAt: null } });
        if (!caso) return reply.code(400).send({ error: 'Caso inválido' });
      }
      if (clienteId) {
        const cliente = await prisma.cliente.findFirst({ where: { id: clienteId, deletedAt: null } });
        if (!cliente) return reply.code(400).send({ error: 'Cliente inválido' });
      }

      const extension = path.extname(data.filename).replace('.', '').toUpperCase() || 'BIN';
      const storageKey = `${nanoid()}${path.extname(data.filename)}`;
      const destPath = path.join(uploadDir, storageKey);

      await pipeline(data.file, createWriteStream(destPath));
      if (data.file.truncated) {
        await unlink(destPath).catch(() => undefined);
        return reply.code(413).send({ error: 'El archivo excede el límite de 25 MB' });
      }
      const stats = await stat(destPath);

      const documento = await prisma.documento.create({
        data: {
          casoId,
          clienteId,
          nombre: data.filename.replace(path.extname(data.filename), ''),
          extension,
          tamanoBytes: stats.size,
          storageKey,
          subidoPorId: request.user!.id,
        },
      });

      if (casoId) {
        await prisma.actuacion.create({
          data: {
            casoId,
            tipo: 'DOCUMENTO',
            texto: `Documento cargado al expediente: "${data.filename}".`,
            autorId: request.user!.id,
          },
        });
      }

      await recordAudit({
        actorId: request.user!.id,
        accion: 'cargó el documento',
        entidad: 'Documento',
        entidadId: documento.id,
        metadata: { nombre: data.filename },
      });

      return reply.code(201).send({ id: documento.id, nombre: documento.nombre, extension: documento.extension });
    },
  );

  app.get('/api/documentos/:id/descargar', { preHandler: requireAuth }, async (request, reply) => {
    const { id } = request.params as { id: string };
    const documento = await prisma.documento.findFirst({ where: { id, deletedAt: null } });
    if (!documento) return reply.code(404).send({ error: 'Documento no encontrado' });

    const filePath = path.join(uploadDir, documento.storageKey);
    try {
      await stat(filePath);
    } catch {
      return reply.code(404).send({ error: 'Archivo no disponible' });
    }
    reply.header(
      'Content-Disposition',
      `attachment; filename="${documento.nombre}.${documento.extension.toLowerCase()}"`,
    );
    return reply.sendFile(documento.storageKey, uploadDir);
  });
}
