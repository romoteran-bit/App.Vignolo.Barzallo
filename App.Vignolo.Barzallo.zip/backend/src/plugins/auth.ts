import fp from 'fastify-plugin';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { resolveSession } from '../lib/session.js';
import { env } from '../config/env.js';

export interface AuthUser {
  id: string;
  nombre: string;
  email: string;
  rolId: string;
  rolNombre: string;
  abogadoId: string | null;
  mustReset: boolean;
  permisos: Set<string>;
}

declare module 'fastify' {
  interface FastifyRequest {
    user: AuthUser | null;
    sessionToken: string | null;
  }
}

export default fp(async function authPlugin(app: FastifyInstance) {
  app.decorateRequest('user', null);
  app.decorateRequest('sessionToken', null);

  app.addHook('preHandler', async (request) => {
    const token = request.cookies[env.SESSION_COOKIE_NAME];
    if (!token) return;
    const unsigned = request.unsignCookie(token);
    if (!unsigned.valid || !unsigned.value) return;

    const session = await resolveSession(unsigned.value);
    if (!session) return;

    request.sessionToken = unsigned.value;
    request.user = {
      id: session.usuario.id,
      nombre: session.usuario.nombre,
      email: session.usuario.email,
      rolId: session.usuario.rolId,
      rolNombre: session.usuario.rol.nombre,
      abogadoId: session.usuario.abogado?.id ?? null,
      mustReset: session.usuario.mustReset,
      permisos: new Set(session.usuario.rol.permisos.map((p) => p.permisoClave)),
    };
  });
});

export function requireAuth(request: FastifyRequest, reply: FastifyReply, done: () => void) {
  if (!request.user) {
    reply.code(401).send({ error: 'No autenticado' });
    return;
  }
  done();
}

export function requirePermission(clave: string) {
  return function (request: FastifyRequest, reply: FastifyReply, done: () => void) {
    if (!request.user) {
      reply.code(401).send({ error: 'No autenticado' });
      return;
    }
    if (!request.user.permisos.has(clave)) {
      reply.code(403).send({ error: 'No autorizado para esta acción' });
      return;
    }
    done();
  };
}

export function requireAnyPermission(...claves: string[]) {
  return function (request: FastifyRequest, reply: FastifyReply, done: () => void) {
    if (!request.user) {
      reply.code(401).send({ error: 'No autenticado' });
      return;
    }
    if (!claves.some((c) => request.user!.permisos.has(c))) {
      reply.code(403).send({ error: 'No autorizado para esta acción' });
      return;
    }
    done();
  };
}
