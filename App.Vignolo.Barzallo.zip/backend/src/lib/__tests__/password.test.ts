import { describe, expect, it } from 'vitest';
import { hashPassword, verifyPassword } from '../password.js';

describe('password hashing', () => {
  it('hashes and verifies a correct password', async () => {
    const hash = await hashPassword('VignoloBarzallo2026!');
    expect(hash).not.toBe('VignoloBarzallo2026!');
    await expect(verifyPassword(hash, 'VignoloBarzallo2026!')).resolves.toBe(true);
  });

  it('rejects an incorrect password', async () => {
    const hash = await hashPassword('VignoloBarzallo2026!');
    await expect(verifyPassword(hash, 'wrong-password')).resolves.toBe(false);
  });

  it('produces a different hash each time (random salt)', async () => {
    const a = await hashPassword('same-input-password');
    const b = await hashPassword('same-input-password');
    expect(a).not.toBe(b);
  });
});
