import { describe, expect, it } from 'vitest';
import { initialsFromName } from '../names.js';

describe('initialsFromName', () => {
  it('strips honorific titles before computing initials', () => {
    expect(initialsFromName('Abg. Paúl Romo T.')).toBe('PR');
    expect(initialsFromName('Dra. María Augusta Barzallo')).toBe('MA');
  });

  it('handles a single-word name', () => {
    expect(initialsFromName('Recepción')).toBe('R');
  });
});
