import { describe, expect, it } from 'vitest';
import { PERMISOS, PERMISO_ORDEN, ROLE_SEED } from '../permissions.js';

describe('permission matrix seed', () => {
  it('grants the Administrador role every permission', () => {
    const admin = ROLE_SEED.find((r) => r.nombre === 'Administrador')!;
    expect(new Set(admin.permisos)).toEqual(new Set(PERMISO_ORDEN));
  });

  it('never grants Pasante case-deletion or configuration access', () => {
    const pasante = ROLE_SEED.find((r) => r.nombre === 'Pasante')!;
    expect(pasante.permisos).not.toContain(PERMISOS.ELIMINACION_LOGICA);
    expect(pasante.permisos).not.toContain(PERMISOS.CONFIGURAR_SISTEMA);
    expect(pasante.permisos).not.toContain(PERMISOS.VER_HONORARIOS);
    expect(pasante.permisos).toContain(PERMISOS.VER_CASOS_ASIGNADOS);
    expect(pasante.permisos).toContain(PERMISOS.CREAR_TAREAS);
    expect(pasante.permisos).toContain(PERMISOS.SUBIR_DOCUMENTOS);
  });

  it('only grants administrar_usuarios / configurar_sistema to Administrador', () => {
    for (const rol of ROLE_SEED) {
      if (rol.nombre === 'Administrador') continue;
      expect(rol.permisos).not.toContain(PERMISOS.ADMINISTRAR_USUARIOS);
      expect(rol.permisos).not.toContain(PERMISOS.CONFIGURAR_SISTEMA);
    }
  });

  it('every seeded permission key has a stable slug used nowhere else', () => {
    const claves = new Set(Object.values(PERMISOS));
    expect(claves.size).toBe(Object.keys(PERMISOS).length);
  });
});
