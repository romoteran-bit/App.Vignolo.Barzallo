import { describe, expect, it } from 'vitest';
import { isLocked, nextFailedAttemptState, MAX_LOGIN_ATTEMPTS, LOCKOUT_MINUTES } from '../lockout.js';

describe('isLocked', () => {
  it('is false when lockedUntil is null', () => {
    expect(isLocked(null)).toBe(false);
  });

  it('is true when lockedUntil is in the future', () => {
    const future = new Date(Date.now() + 60_000);
    expect(isLocked(future)).toBe(true);
  });

  it('is false when lockedUntil is in the past', () => {
    const past = new Date(Date.now() - 60_000);
    expect(isLocked(past)).toBe(false);
  });
});

describe('nextFailedAttemptState', () => {
  it('increments attempts without locking below the threshold', () => {
    const state = nextFailedAttemptState(0);
    expect(state.failedLoginAttempts).toBe(1);
    expect(state.lockedUntil).toBeNull();
  });

  it('locks the account once the max attempts is reached', () => {
    const now = new Date('2026-01-01T00:00:00Z');
    const state = nextFailedAttemptState(MAX_LOGIN_ATTEMPTS - 1, now);
    expect(state.failedLoginAttempts).toBe(MAX_LOGIN_ATTEMPTS);
    expect(state.lockedUntil).toEqual(new Date(now.getTime() + LOCKOUT_MINUTES * 60 * 1000));
  });
});
