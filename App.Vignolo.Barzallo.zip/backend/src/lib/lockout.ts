export const MAX_LOGIN_ATTEMPTS = 5;
export const LOCKOUT_MINUTES = 15;

export function isLocked(lockedUntil: Date | null, now: Date = new Date()): boolean {
  return !!lockedUntil && lockedUntil.getTime() > now.getTime();
}

/** Pure decision for what to persist after a failed login attempt. */
export function nextFailedAttemptState(
  currentAttempts: number,
  now: Date = new Date(),
): { failedLoginAttempts: number; lockedUntil: Date | null } {
  const failedLoginAttempts = currentAttempts + 1;
  if (failedLoginAttempts >= MAX_LOGIN_ATTEMPTS) {
    return { failedLoginAttempts, lockedUntil: new Date(now.getTime() + LOCKOUT_MINUTES * 60 * 1000) };
  }
  return { failedLoginAttempts, lockedUntil: null };
}

export const RESET_ATTEMPT_STATE = { failedLoginAttempts: 0, lockedUntil: null as Date | null };
