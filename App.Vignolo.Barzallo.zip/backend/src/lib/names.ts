const HONORIFICOS = /^(abg|dr|dra|lic|lcdo|lcda|ing|sr|sra)\.?$/i;

/** Best-effort 2-letter initials for a person's display name, skipping titles. */
export function initialsFromName(nombre: string): string {
  const words = nombre
    .replace(/[^A-Za-zÁÉÍÓÚÑáéíóúñ. ]/g, '')
    .split(/\s+/)
    .filter((w) => w && !HONORIFICOS.test(w));
  return words
    .slice(0, 2)
    .map((w) => w.replace('.', '')[0]?.toUpperCase() ?? '')
    .join('');
}
