import { createHash, randomBytes } from 'node:crypto';
import { prisma } from './prisma.js';
import { env } from '../config/env.js';

function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

export async function createSession(usuarioId: string, userAgent?: string, ip?: string) {
  const token = randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + env.SESSION_TTL_HOURS * 60 * 60 * 1000);
  await prisma.session.create({
    data: { id: hashToken(token), usuarioId, userAgent, ip, expiresAt },
  });
  return { token, expiresAt };
}

export async function resolveSession(token: string) {
  const id = hashToken(token);
  const session = await prisma.session.findUnique({
    where: { id },
    include: {
      usuario: {
        include: { rol: { include: { permisos: true } }, abogado: true },
      },
    },
  });
  if (!session) return null;
  if (session.expiresAt.getTime() < Date.now()) {
    await prisma.session.delete({ where: { id } }).catch(() => undefined);
    return null;
  }
  if (!session.usuario.activo || session.usuario.deletedAt) return null;
  return session;
}

export async function destroySession(token: string) {
  const id = hashToken(token);
  await prisma.session.deleteMany({ where: { id } });
}

export async function destroyAllSessionsForUser(usuarioId: string) {
  await prisma.session.deleteMany({ where: { usuarioId } });
}
