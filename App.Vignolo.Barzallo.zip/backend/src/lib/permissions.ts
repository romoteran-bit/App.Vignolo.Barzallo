// Stable slugs — must match the seeded Permiso.clave rows. Never hardcode role
// names against features; always check one of these permission keys instead,
// so the access matrix stays fully editable from Configuración → Roles.
export const PERMISOS = {
  VER_TODOS_CASOS: 'ver_todos_casos',
  VER_CASOS_ASIGNADOS: 'ver_casos_asignados',
  CREAR_EDITAR_CASOS: 'crear_editar_casos',
  CREAR_TAREAS: 'crear_tareas',
  SUBIR_DOCUMENTOS: 'subir_documentos',
  ELIMINACION_LOGICA: 'eliminacion_logica',
  GESTIONAR_CLIENTES: 'gestionar_clientes',
  VER_HONORARIOS: 'ver_honorarios',
  ADMINISTRAR_USUARIOS: 'administrar_usuarios',
  CONFIGURAR_SISTEMA: 'configurar_sistema',
  VER_AUDITORIA: 'ver_auditoria',
} as const;

export type PermisoClave = (typeof PERMISOS)[keyof typeof PERMISOS];

export const PERMISO_ETIQUETAS: Record<PermisoClave, string> = {
  [PERMISOS.VER_TODOS_CASOS]: 'Ver todos los casos',
  [PERMISOS.VER_CASOS_ASIGNADOS]: 'Ver casos asignados',
  [PERMISOS.CREAR_EDITAR_CASOS]: 'Crear / editar casos',
  [PERMISOS.CREAR_TAREAS]: 'Crear tareas',
  [PERMISOS.SUBIR_DOCUMENTOS]: 'Subir documentos',
  [PERMISOS.ELIMINACION_LOGICA]: 'Eliminación lógica',
  [PERMISOS.GESTIONAR_CLIENTES]: 'Gestionar clientes',
  [PERMISOS.VER_HONORARIOS]: 'Ver honorarios',
  [PERMISOS.ADMINISTRAR_USUARIOS]: 'Administrar usuarios',
  [PERMISOS.CONFIGURAR_SISTEMA]: 'Configurar sistema',
  [PERMISOS.VER_AUDITORIA]: 'Ver registro de auditoría',
};

export const PERMISO_ORDEN: PermisoClave[] = [
  PERMISOS.VER_TODOS_CASOS,
  PERMISOS.VER_CASOS_ASIGNADOS,
  PERMISOS.CREAR_EDITAR_CASOS,
  PERMISOS.CREAR_TAREAS,
  PERMISOS.SUBIR_DOCUMENTOS,
  PERMISOS.ELIMINACION_LOGICA,
  PERMISOS.GESTIONAR_CLIENTES,
  PERMISOS.VER_HONORARIOS,
  PERMISOS.ADMINISTRAR_USUARIOS,
  PERMISOS.CONFIGURAR_SISTEMA,
  PERMISOS.VER_AUDITORIA,
];

// Seed matrix — exact values approved in the design handoff (README §Roles y
// permisos). 1 = permitido, 0 = denegado.
export const ROLE_SEED: { nombre: string; permisos: PermisoClave[] }[] = [
  {
    nombre: 'Administrador',
    permisos: PERMISO_ORDEN.slice(),
  },
  {
    nombre: 'Socio',
    permisos: [
      PERMISOS.VER_TODOS_CASOS,
      PERMISOS.VER_CASOS_ASIGNADOS,
      PERMISOS.CREAR_EDITAR_CASOS,
      PERMISOS.CREAR_TAREAS,
      PERMISOS.SUBIR_DOCUMENTOS,
      PERMISOS.ELIMINACION_LOGICA,
      PERMISOS.GESTIONAR_CLIENTES,
      PERMISOS.VER_HONORARIOS,
      PERMISOS.VER_AUDITORIA,
    ],
  },
  {
    nombre: 'Abogado',
    permisos: [
      PERMISOS.VER_CASOS_ASIGNADOS,
      PERMISOS.CREAR_EDITAR_CASOS,
      PERMISOS.CREAR_TAREAS,
      PERMISOS.SUBIR_DOCUMENTOS,
      PERMISOS.GESTIONAR_CLIENTES,
    ],
  },
  {
    nombre: 'Pasante',
    permisos: [PERMISOS.VER_CASOS_ASIGNADOS, PERMISOS.CREAR_TAREAS, PERMISOS.SUBIR_DOCUMENTOS],
  },
  {
    nombre: 'Administrativo',
    permisos: [PERMISOS.SUBIR_DOCUMENTOS, PERMISOS.GESTIONAR_CLIENTES, PERMISOS.VER_HONORARIOS],
  },
];
