import 'dotenv/config';
import { z } from 'zod';

const schema = z.object({
  DATABASE_URL: z.string().min(1),
  PORT: z.coerce.number().default(4000),
  SESSION_COOKIE_NAME: z.string().default('vb_session'),
  SESSION_TTL_HOURS: z.coerce.number().default(12),
  COOKIE_SIGNING_SECRET: z.string().min(16),
  FRONTEND_ORIGIN: z.string().default('http://localhost:5173'),
  UPLOAD_DIR: z.string().default('./uploads'),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
});

export const env = schema.parse(process.env);
