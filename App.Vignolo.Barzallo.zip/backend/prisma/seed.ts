import { PrismaClient, CategoriaCatalogo, EstadoCliente, Prioridad, TipoActuacion, TipoEvento, EstadoTarea, EstadoFactura } from '@prisma/client';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { hashPassword } from '../src/lib/password.js';
import { ROLE_SEED, PERMISO_ETIQUETAS, PERMISO_ORDEN } from '../src/lib/permissions.js';

const prisma = new PrismaClient();

const DEV_PASSWORD = 'VignoloBarzallo2026!';
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR ?? './uploads');

const MATERIAS = [
  'Laboral', 'Tributario', 'Familia', 'Societario', 'Civil', 'Mercantil',
  'Administrativo', 'Constitucional', 'Penal', 'Propiedad Intelectual',
];
const ETAPAS = [
  'Consulta inicial', 'Documentación', 'Análisis', 'Demanda', 'Contestación',
  'Prueba', 'Audiencia', 'Sentencia', 'Recursos', 'Ejecución', 'Archivado',
];
const PRIORIDADES_CAT = ['Alta', 'Media', 'Baja'];
const TIPOS_CLIENTE = ['Potencial', 'Activo', 'Inactivo', 'VIP', 'Empresa', 'Persona natural'];

const MESES_ES: Record<string, number> = {
  ene: 0, feb: 1, mar: 2, abr: 3, may: 4, jun: 5, jul: 6, ago: 7, sep: 8, oct: 9, nov: 10, dic: 11,
};

/** Parses seed date strings like "15 jun 2025" into a real Date. */
function parseFechaEs(texto: string): Date {
  const m = texto.match(/(\d{1,2})\s+([a-záéíóú]{3})\.?\s+(\d{4})/i);
  if (!m) return new Date();
  const [, day, mesAbbr, year] = m;
  const mes = MESES_ES[mesAbbr!.toLowerCase()] ?? 0;
  return new Date(Number(year), mes, Number(day));
}

function addDays(d: Date, days: number): Date {
  const copy = new Date(d);
  copy.setDate(copy.getDate() + days);
  return copy;
}

function daysFromToday(offset: number): Date {
  const d = new Date();
  d.setHours(9, 0, 0, 0);
  d.setDate(d.getDate() + offset);
  return d;
}

async function seedPlaceholderFile(storageKey: string, sizeBytes: number) {
  await mkdir(UPLOAD_DIR, { recursive: true });
  const filler = Buffer.alloc(sizeBytes, 'VB-ERP-DOCUMENTO-SEED ');
  await writeFile(path.join(UPLOAD_DIR, storageKey), filler);
}

async function main() {
  console.log('→ Limpiando datos existentes…');
  await prisma.$transaction([
    prisma.auditLog.deleteMany(),
    prisma.factura.deleteMany(),
    prisma.documento.deleteMany(),
    prisma.eventoAgenda.deleteMany(),
    prisma.tarea.deleteMany(),
    prisma.actuacion.deleteMany(),
    prisma.casoResponsable.deleteMany(),
    prisma.caso.deleteMany(),
    prisma.cliente.deleteMany(),
    prisma.session.deleteMany(),
    prisma.usuario.deleteMany(),
    prisma.abogado.deleteMany(),
    prisma.rolPermiso.deleteMany(),
    prisma.rol.deleteMany(),
    prisma.permiso.deleteMany(),
    prisma.catalogoItem.deleteMany(),
    prisma.configuracionGeneral.deleteMany(),
  ]);

  console.log('→ Permisos y roles…');
  await prisma.permiso.createMany({
    data: PERMISO_ORDEN.map((clave, i) => ({ clave, etiqueta: PERMISO_ETIQUETAS[clave], orden: i })),
  });
  const roles = new Map<string, string>();
  for (const r of ROLE_SEED) {
    const rol = await prisma.rol.create({ data: { nombre: r.nombre } });
    roles.set(r.nombre, rol.id);
    await prisma.rolPermiso.createMany({
      data: r.permisos.map((clave) => ({ rolId: rol.id, permisoClave: clave })),
    });
  }

  console.log('→ Catálogos…');
  await prisma.catalogoItem.createMany({
    data: [
      ...MATERIAS.map((valor, orden) => ({ categoria: CategoriaCatalogo.MATERIA, valor, orden })),
      ...ETAPAS.map((valor, orden) => ({ categoria: CategoriaCatalogo.ETAPA_PROCESAL, valor, orden })),
      ...PRIORIDADES_CAT.map((valor, orden) => ({ categoria: CategoriaCatalogo.PRIORIDAD, valor, orden })),
      ...TIPOS_CLIENTE.map((valor, orden) => ({ categoria: CategoriaCatalogo.TIPO_CLIENTE, valor, orden })),
    ],
  });

  console.log('→ Configuración general…');
  await prisma.configuracionGeneral.create({ data: { id: 1 } });

  console.log('→ Abogados y usuarios…');
  const PR = await prisma.abogado.create({ data: { nombre: 'Abg. Paúl Romo T.', iniciales: 'PR', cargo: 'Socio · Abogado', color: '#2F5D50' } });
  const MB = await prisma.abogado.create({ data: { nombre: 'Dra. María Augusta Barzallo', iniciales: 'MB', cargo: 'Socia · Abogada', color: '#3A4B7A' } });
  const MV = await prisma.abogado.create({ data: { nombre: 'Dra. María Augusta Vignolo', iniciales: 'MV', cargo: 'Socia · Abogada', color: '#6E3B4E' } });
  const ES = await prisma.abogado.create({ data: { nombre: 'Dr. Eugenio Stanculenscu', iniciales: 'ES', cargo: 'Abogado', color: '#8A6218' } });

  const passwordHash = await hashPassword(DEV_PASSWORD);

  const uPR = await prisma.usuario.create({
    data: { nombre: PR.nombre, email: 'paul.romo@vignolobarzallo.ec', passwordHash, rolId: roles.get('Administrador')!, mustReset: false, lastLoginAt: new Date() },
  });
  await prisma.abogado.update({ where: { id: PR.id }, data: { usuarioId: uPR.id } });

  const uMB = await prisma.usuario.create({
    data: { nombre: MB.nombre, email: 'ma.barzallo@vignolobarzallo.ec', passwordHash, rolId: roles.get('Socio')!, mustReset: false, lastLoginAt: daysFromToday(0) },
  });
  await prisma.abogado.update({ where: { id: MB.id }, data: { usuarioId: uMB.id } });

  const uMV = await prisma.usuario.create({
    data: { nombre: MV.nombre, email: 'magu.vignolo@vignolobarzallo.ec', passwordHash, rolId: roles.get('Socio')!, mustReset: false, lastLoginAt: daysFromToday(-1) },
  });
  await prisma.abogado.update({ where: { id: MV.id }, data: { usuarioId: uMV.id } });

  const uES = await prisma.usuario.create({
    data: { nombre: ES.nombre, email: 'eugenio.s@vignolobarzallo.ec', passwordHash, rolId: roles.get('Abogado')!, mustReset: false, lastLoginAt: daysFromToday(0) },
  });
  await prisma.abogado.update({ where: { id: ES.id }, data: { usuarioId: uES.id } });

  await prisma.usuario.create({
    data: {
      nombre: 'María José Torres', email: 'maria.jose.torres@vignolobarzallo.ec',
      passwordHash: null, rolId: roles.get('Pasante')!, mustReset: true,
    },
  });

  await prisma.usuario.create({
    data: { nombre: 'Recepción', email: 'recepcion@vignolobarzallo.ec', passwordHash, rolId: roles.get('Administrativo')!, mustReset: false, lastLoginAt: daysFromToday(0) },
  });

  console.log('→ Clientes…');
  const clientesData = [
    { key: 'c1', nombre: 'Comercial Andina S.A.', tipo: 'Empresa', estado: EstadoCliente.ACTIVO, identificacion: 'RUC 0190312345001', telefono: '+593 7 405 1122', ciudad: 'Cuenca', resp: PR.id, creado: '12 mar 2025' },
    { key: 'c2', nombre: 'María Fernanda Ortiz', tipo: 'Persona natural', estado: EstadoCliente.VIP, identificacion: 'CI 0102345678', telefono: '+593 99 812 4477', ciudad: 'Cuenca', resp: MV.id, creado: '03 feb 2025' },
    { key: 'c3', nombre: 'Constructora del Austro Cía. Ltda.', tipo: 'Empresa', estado: EstadoCliente.ACTIVO, identificacion: 'RUC 0190555221001', telefono: '+593 7 288 9010', ciudad: 'Cuenca', resp: PR.id, creado: '20 ene 2025' },
    { key: 'c4', nombre: 'Importadora Guayas S.A.', tipo: 'Empresa', estado: EstadoCliente.VIP, identificacion: 'RUC 0992134567001', telefono: '+593 4 268 3300', ciudad: 'Guayaquil', resp: PR.id, creado: '18 nov 2024' },
    { key: 'c5', nombre: 'Textiles del Sur S.A.', tipo: 'Empresa', estado: EstadoCliente.POTENCIAL, identificacion: 'RUC 0190777889001', telefono: '+593 7 410 5566', ciudad: 'Cuenca', resp: MB.id, creado: '28 may 2025' },
    { key: 'c6', nombre: 'Juan Carlos Peralta', tipo: 'Persona natural', estado: EstadoCliente.ACTIVO, identificacion: 'CI 0105678123', telefono: '+593 98 445 7788', ciudad: 'Azogues', resp: ES.id, creado: '09 abr 2025' },
    { key: 'c7', nombre: 'Diego Armijos', tipo: 'Persona natural', estado: EstadoCliente.ACTIVO, identificacion: 'CI 0103344556', telefono: '+593 99 223 1190', ciudad: 'Cuenca', resp: PR.id, creado: '15 jun 2025' },
    { key: 'c8', nombre: 'Rosa Elena Cárdenas', tipo: 'Persona natural', estado: EstadoCliente.INACTIVO, identificacion: 'CI 0101122334', telefono: '+593 98 001 2233', ciudad: 'Cuenca', resp: MV.id, creado: '22 ago 2024' },
  ];
  const clientes = new Map<string, string>();
  for (const c of clientesData) {
    const created = await prisma.cliente.create({
      data: {
        nombre: c.nombre, tipo: c.tipo, estado: c.estado, identificacion: c.identificacion,
        telefono: c.telefono, ciudad: c.ciudad, responsableId: c.resp, createdAt: parseFechaEs(c.creado),
      },
    });
    clientes.set(c.key, created.id);
  }

  console.log('→ Casos…');
  const casosData = [
    { id: 'VB-2025-014', cliente: 'c1', materia: 'Laboral', etapaIdx: 6, prioridad: Prioridad.ALTA, resp: [PR.id, MB.id], juzgado: 'U. J. de Trabajo — Cuenca', numeroProceso: '01371-2025-00842', contraparte: 'Luis A. Mora (ex trabajador)', inicio: '14 abr 2025', cierreEstimado: 'Sep 2025', desc: 'Demanda por despido intempestivo. El actor reclama indemnizaciones y remuneraciones pendientes.', estrategia: 'Sostener la existencia de visto bueno debidamente notificado y respaldar con planillas del IESS y roles firmados.', riesgos: 'Riesgo medio. La notificación del visto bueno podría cuestionarse; asegurar prueba documental completa.' },
    { id: 'VB-2025-021', cliente: 'c3', materia: 'Civil', etapaIdx: 5, prioridad: Prioridad.MEDIA, resp: [PR.id], juzgado: 'U. J. Civil — Cuenca', numeroProceso: '01333-2025-01120', contraparte: 'Inmobiliaria Los Ceibos S.A.', inicio: '02 may 2025', cierreEstimado: 'Dic 2025', desc: 'Controversia por incumplimiento de contrato de obra y liquidación de valores pendientes.', estrategia: 'Acreditar el avance de obra con actas de fiscalización y respaldar con peritaje técnico independiente.', riesgos: 'Riesgo bajo con peritaje favorable.' },
    { id: 'VB-2025-008', cliente: 'c2', materia: 'Familia', etapaIdx: 7, prioridad: Prioridad.ALTA, resp: [MV.id], juzgado: 'U. J. de Familia — Cuenca', numeroProceso: '01204-2025-00455', contraparte: 'Carlos J. Sánchez', inicio: '03 feb 2025', cierreEstimado: 'Ago 2025', desc: 'Fijación de pensión alimenticia y régimen de visitas a favor del menor.', estrategia: 'Priorizar el interés superior del menor y sustentar la capacidad económica real del demandado.', riesgos: '—' },
    { id: 'VB-2024-097', cliente: 'c4', materia: 'Tributario', etapaIdx: 8, prioridad: Prioridad.ALTA, resp: [PR.id], juzgado: 'Tribunal Distrital de lo Fiscal — Guayaquil', numeroProceso: '09501-2024-02233', contraparte: 'Servicio de Rentas Internas', inicio: '18 nov 2024', cierreEstimado: '2026', desc: 'Impugnación del acta de determinación de IVA por diferencias en el crédito tributario.', estrategia: 'Recurso de casación por errónea aplicación de la norma; respaldar con documentación de importaciones.', riesgos: 'Riesgo alto por el monto en discusión; evaluar afianzamiento.' },
    { id: 'VB-2025-030', cliente: 'c5', materia: 'Societario', etapaIdx: 2, prioridad: Prioridad.BAJA, resp: [MB.id], juzgado: 'Superintendencia de Compañías', numeroProceso: '—', contraparte: '—', inicio: '28 may 2025', cierreEstimado: '—', desc: 'Reforma de estatutos y aumento de capital de la compañía.', estrategia: 'Estructurar la junta general y las actas conforme a la Ley de Compañías.', riesgos: '—' },
    { id: 'VB-2025-025', cliente: 'c6', materia: 'Penal', etapaIdx: 4, prioridad: Prioridad.ALTA, resp: [ES.id], juzgado: 'U. J. Penal — Azogues', numeroProceso: '03281-2025-00990', contraparte: 'Fiscalía General del Estado', inicio: '09 abr 2025', cierreEstimado: '—', desc: 'Instrucción fiscal por presunto delito de estafa.', estrategia: 'Desvirtuar el dolo y solicitar diligencias de descargo dentro de la instrucción.', riesgos: 'Riesgo alto; preparar teoría del caso sólida.' },
    { id: 'VB-2025-011', cliente: 'c7', materia: 'Mercantil', etapaIdx: 9, prioridad: Prioridad.MEDIA, resp: [PR.id], juzgado: 'U. J. Civil — Cuenca', numeroProceso: '01333-2025-00701', contraparte: 'Distribuidora El Faro', inicio: '15 jun 2025', cierreEstimado: '—', desc: 'Cobro de pagaré vencido mediante procedimiento ejecutivo.', estrategia: 'Ejecutar el título y solicitar medidas cautelares para asegurar el cobro.', riesgos: 'Riesgo bajo.' },
  ];

  for (const c of casosData) {
    await prisma.caso.create({
      data: {
        id: c.id, clienteId: clientes.get(c.cliente)!, materia: c.materia, etapa: ETAPAS[c.etapaIdx]!,
        prioridad: c.prioridad, juzgado: c.juzgado, numeroProceso: c.numeroProceso, contraparte: c.contraparte,
        inicio: c.inicio, cierreEstimado: c.cierreEstimado, descripcion: c.desc, estrategia: c.estrategia, riesgos: c.riesgos,
        createdAt: parseFechaEs(c.inicio),
        equipo: { createMany: { data: c.resp.map((abogadoId) => ({ abogadoId })) } },
      },
    });
  }

  // Cronología — historial detallado para el caso insignia; genérico para el resto.
  await prisma.actuacion.createMany({
    data: [
      { casoId: 'VB-2025-014', tipo: TipoActuacion.CREACION, fecha: new Date(2025, 3, 14), autorId: uPR.id, texto: 'Caso creado y asignado al equipo.' },
      { casoId: 'VB-2025-014', tipo: TipoActuacion.ETAPA, fecha: new Date(2025, 4, 9), autorId: uMB.id, texto: 'Etapa cambiada a "Análisis". Elaboración de la teoría del caso.' },
      { casoId: 'VB-2025-014', tipo: TipoActuacion.ACTUACION, fecha: new Date(2025, 4, 27), autorId: uPR.id, texto: 'Presentada la contestación a la demanda.' },
      { casoId: 'VB-2025-014', tipo: TipoActuacion.DOCUMENTO, fecha: new Date(2025, 6, 5), autorId: uMB.id, texto: 'Cargados 3 documentos de prueba al expediente.' },
      { casoId: 'VB-2025-014', tipo: TipoActuacion.ETAPA, fecha: new Date(2025, 5, 18), autorId: uPR.id, texto: 'Etapa cambiada a "Audiencia". Convocatoria a audiencia única.' },
    ],
  });
  const genericAuthors: Record<string, string> = { [PR.id]: uPR.id, [MB.id]: uMB.id, [MV.id]: uMV.id, [ES.id]: uES.id };
  for (const c of casosData) {
    if (c.id === 'VB-2025-014') continue;
    const autorId = genericAuthors[c.resp[0]!]!;
    const inicio = parseFechaEs(c.inicio);
    await prisma.actuacion.createMany({
      data: [
        { casoId: c.id, tipo: TipoActuacion.CREACION, texto: 'Caso creado y asignado al responsable.', autorId, fecha: inicio },
        { casoId: c.id, tipo: TipoActuacion.ACTUACION, texto: 'Registrada la actuación inicial del proceso.', autorId, fecha: addDays(inicio, 6) },
        { casoId: c.id, tipo: TipoActuacion.ETAPA, texto: `Etapa actual: "${ETAPAS[c.etapaIdx]}".`, autorId, fecha: addDays(inicio, 14) },
      ],
    });
  }

  console.log('→ Documentos (con archivos de muestra)…');
  const docsData = [
    { n: 'Contestación a la demanda', ext: 'PDF', caso: 'VB-2025-014', cliente: 'c1', sizeKB: 240, autor: uPR.id, fecha: '27 may 2025' },
    { n: 'Planillas IESS 2024-2025', ext: 'XLSX', caso: 'VB-2025-014', cliente: 'c1', sizeKB: 1200, autor: uMB.id, fecha: '22 abr 2025' },
    { n: 'Roles de pago firmados', ext: 'PDF', caso: 'VB-2025-014', cliente: 'c1', sizeKB: 3400, autor: uPR.id, fecha: '22 abr 2025' },
    { n: 'Contrato de obra', ext: 'PDF', caso: 'VB-2025-021', cliente: 'c3', sizeKB: 860, autor: uPR.id, fecha: '02 may 2025' },
    { n: 'Informe pericial técnico', ext: 'PDF', caso: 'VB-2025-021', cliente: 'c3', sizeKB: 5100, autor: uPR.id, fecha: '18 jun 2025' },
    { n: 'Acta de determinación IVA', ext: 'PDF', caso: 'VB-2024-097', cliente: 'c4', sizeKB: 1900, autor: uPR.id, fecha: '18 nov 2024' },
    { n: 'Demanda de alimentos', ext: 'DOCX', caso: 'VB-2025-008', cliente: 'c2', sizeKB: 95, autor: uMV.id, fecha: '03 feb 2025' },
    { n: 'Estatutos vigentes', ext: 'DOCX', caso: 'VB-2025-030', cliente: 'c5', sizeKB: 180, autor: uMB.id, fecha: '28 may 2025' },
    { n: 'Pagaré escaneado', ext: 'PDF', caso: 'VB-2025-011', cliente: 'c7', sizeKB: 420, autor: uPR.id, fecha: '15 jun 2025' },
  ];
  let docSeq = 0;
  for (const d of docsData) {
    docSeq += 1;
    const storageKey = `seed-${docSeq}.${d.ext.toLowerCase()}`;
    const sizeBytes = d.sizeKB * 1024;
    await seedPlaceholderFile(storageKey, sizeBytes);
    await prisma.documento.create({
      data: {
        casoId: d.caso, clienteId: clientes.get(d.cliente)!, nombre: d.n, extension: d.ext,
        tamanoBytes: sizeBytes, storageKey, subidoPorId: d.autor, subidoEn: parseFechaEs(d.fecha),
      },
    });
  }

  console.log('→ Agenda…');
  await prisma.eventoAgenda.createMany({
    data: [
      { fecha: daysFromToday(0), titulo: 'Audiencia única', subtitulo: 'VB-2025-014 · Comercial Andina', tipo: TipoEvento.AUDIENCIA, casoId: 'VB-2025-014' },
      { fecha: new Date(daysFromToday(0).setHours(11, 30)), titulo: 'Reunión con cliente', subtitulo: 'Constructora del Austro', tipo: TipoEvento.REUNION, casoId: 'VB-2025-021' },
      { fecha: new Date(daysFromToday(0).setHours(14, 0)), titulo: 'Vence: contestar dictamen', subtitulo: 'VB-2025-025 · J. C. Peralta', tipo: TipoEvento.PLAZO, casoId: 'VB-2025-025' },
      { fecha: new Date(daysFromToday(0).setHours(16, 30)), titulo: 'Llamada de seguimiento', subtitulo: 'María Fernanda Ortiz', tipo: TipoEvento.LLAMADA, casoId: 'VB-2025-008' },
      { fecha: daysFromToday(1), titulo: 'Lectura de sentencia', subtitulo: 'VB-2025-008 · María Fernanda Ortiz', tipo: TipoEvento.PLAZO, casoId: 'VB-2025-008' },
      { fecha: daysFromToday(1), titulo: 'Presentar escrito de prueba', subtitulo: 'VB-2025-021 · Constructora del Austro', tipo: TipoEvento.PLAZO, casoId: 'VB-2025-021' },
      { fecha: daysFromToday(6), titulo: 'Revisar estatutos', subtitulo: 'VB-2025-030 · Textiles del Sur', tipo: TipoEvento.PLAZO, casoId: 'VB-2025-030' },
      { fecha: daysFromToday(9), titulo: 'Fundamentar recurso de casación', subtitulo: 'VB-2024-097 · Importadora Guayas', tipo: TipoEvento.PLAZO, casoId: 'VB-2024-097' },
      { fecha: daysFromToday(12), titulo: 'Reunión de seguimiento', subtitulo: 'Equipo del estudio', tipo: TipoEvento.REUNION },
      { fecha: daysFromToday(13), titulo: 'Llamada con cliente', subtitulo: 'Seguimiento de cartera', tipo: TipoEvento.LLAMADA },
    ],
  });

  console.log('→ Tareas…');
  await prisma.tarea.createMany({
    data: [
      { titulo: 'Preparar alegato para la audiencia única', casoId: 'VB-2025-014', responsableId: PR.id, prioridad: Prioridad.ALTA, vence: daysFromToday(0), estado: EstadoTarea.EN_PROGRESO },
      { titulo: 'Redactar y presentar escrito de prueba', casoId: 'VB-2025-021', responsableId: PR.id, prioridad: Prioridad.ALTA, vence: daysFromToday(1), estado: EstadoTarea.PENDIENTE },
      { titulo: 'Contestar el dictamen fiscal', casoId: 'VB-2025-025', responsableId: ES.id, prioridad: Prioridad.ALTA, vence: daysFromToday(0), estado: EstadoTarea.PENDIENTE },
      { titulo: 'Revisar el contrato de arrendamiento', casoId: 'VB-2025-021', responsableId: PR.id, prioridad: Prioridad.MEDIA, vence: daysFromToday(2), estado: EstadoTarea.PENDIENTE },
      { titulo: 'Solicitar copias certificadas del proceso', casoId: 'VB-2024-097', responsableId: PR.id, prioridad: Prioridad.MEDIA, vence: daysFromToday(3), estado: EstadoTarea.PENDIENTE },
      { titulo: 'Actualizar la ficha de Importadora Guayas', casoId: null, responsableId: PR.id, prioridad: Prioridad.BAJA, vence: daysFromToday(-1), estado: EstadoTarea.COMPLETADA },
      { titulo: 'Agendar la reunión de estrategia', casoId: 'VB-2025-008', responsableId: MV.id, prioridad: Prioridad.BAJA, vence: daysFromToday(5), estado: EstadoTarea.COMPLETADA },
    ],
  });

  console.log('→ Honorarios…');
  const facturas = [
    { secuencial: '001-001-000000142', cliente: 'c1', caso: 'VB-2025-014', concepto: 'Honorarios profesionales · fase de audiencia', monto: 2800, estado: EstadoFactura.PENDIENTE, emision: '2026-07-01', vence: '2026-07-16' },
    { secuencial: '001-001-000000141', cliente: 'c4', caso: 'VB-2024-097', concepto: 'Honorarios · recurso de casación', monto: 6500, estado: EstadoFactura.PAGADA, emision: '2026-06-20', vence: '2026-07-05' },
    { secuencial: '001-001-000000140', cliente: 'c2', caso: 'VB-2025-008', concepto: 'Honorarios · patrocinio juicio de alimentos', monto: 1500, estado: EstadoFactura.PAGADA, emision: '2026-06-10', vence: '2026-06-25' },
    { secuencial: '001-001-000000139', cliente: 'c3', caso: 'VB-2025-021', concepto: 'Honorarios · etapa de prueba', monto: 3200, estado: EstadoFactura.VENCIDA, emision: '2026-05-15', vence: '2026-05-30' },
    { secuencial: '001-001-000000138', cliente: 'c7', caso: 'VB-2025-011', concepto: 'Honorarios · juicio ejecutivo', monto: 1200, estado: EstadoFactura.PENDIENTE, emision: '2026-06-20', vence: '2026-07-05' },
    { secuencial: '001-001-000000137', cliente: 'c5', caso: 'VB-2025-030', concepto: 'Consulta y reforma de estatutos', monto: 900, estado: EstadoFactura.PAGADA, emision: '2026-05-30', vence: '2026-06-14' },
  ];
  for (const f of facturas) {
    await prisma.factura.create({
      data: {
        secuencial: f.secuencial, clienteId: clientes.get(f.cliente)!, casoId: f.caso, concepto: f.concepto,
        monto: f.monto, estado: f.estado, emision: new Date(f.emision), vence: new Date(f.vence),
        sriAutorizado: true, sriAutorizacion: Array.from({ length: 49 }, () => Math.floor(Math.random() * 10)).join(''),
      },
    });
  }

  console.log('→ Registro de auditoría (semilla)…');
  await prisma.auditLog.createMany({
    data: [
      { actorId: uPR.id, accion: 'cambió la etapa de', entidad: 'Caso', entidadId: 'VB-2025-014', metadata: { etapa: 'Audiencia' } },
      { actorId: uMB.id, accion: 'cargó 3 documentos en', entidad: 'Caso', entidadId: 'VB-2025-014' },
      { actorId: uPR.id, accion: 'creó el cliente', entidad: 'Cliente', entidadId: clientes.get('c7') },
      { actorId: uMV.id, accion: 'completó la tarea', entidad: 'Tarea', entidadId: 'Agendar reunión' },
      { actorId: uES.id, accion: 'registró una actuación en', entidad: 'Caso', entidadId: 'VB-2025-025' },
    ],
  });

  console.log('\n✔ Seed completo.');
  console.log(`  Contraseña de desarrollo para todos los usuarios activos: ${DEV_PASSWORD}`);
  console.log('  (María José Torres queda con invitación pendiente, sin contraseña.)');
}

main()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
