/*
  Warnings:

  - Added the required column `iniciales` to the `Abogado` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Abogado" ADD COLUMN     "iniciales" TEXT NOT NULL DEFAULT '';

-- Backfill: derive initials from the existing seed data's known names.
UPDATE "Abogado" SET "iniciales" = 'PR' WHERE "nombre" = 'Abg. Paúl Romo T.';
UPDATE "Abogado" SET "iniciales" = 'MB' WHERE "nombre" = 'Dra. María Augusta Barzallo';
UPDATE "Abogado" SET "iniciales" = 'MV' WHERE "nombre" = 'Dra. María Augusta Vignolo';
UPDATE "Abogado" SET "iniciales" = 'ES' WHERE "nombre" = 'Dr. Eugenio Stanculenscu';
UPDATE "Abogado" SET "iniciales" = UPPER(LEFT("nombre", 2)) WHERE "iniciales" = '';

ALTER TABLE "Abogado" ALTER COLUMN "iniciales" DROP DEFAULT;
